create procedure sunday_cls_gctj is
ii       number(5);
ksrq     varchar2(16);
jsrq     varchar2(16);
kssj     varchar2(16);
jssj     varchar2(16);
wid       number(16);
cc       varchar2(16);
gcsj     varchar2(20);
qksrq     varchar2(20);
zxid       NUMBER(2);
wzm      varchar2(20);
tjzm     varchar2(20);
-------读数据
CURSOR read_lint_tt IS
SELECT  id,ddcc,to_char(cfsj,'yyyy-mm-dd hh24:mi')  from tdmsxd2.xd_train_tt where  node='田心' and zqjid='19373' and cfsj >to_date(kssj,'yyyy-mm-dd hh24:mi') 
and cfsj <=to_date(jssj,'yyyy-mm-dd hh24:mi') and xbid not in (4020)  and ddcc not like '5%'; 


CURSOR read_lint_tt_hd IS
SELECT  id,ddcc,to_char(cfsj,'yyyy-mm-dd hh24:mi'),zx+1  from tdmsxd2.xd_train_tt where  node='怀化东'  and cfsj >to_date(kssj,'yyyy-mm-dd hh24:mi') 
and cfsj <=to_date(jssj,'yyyy-mm-dd hh24:mi')  and ddcc not like '5%' and id in 
(select id from xd_trainline  where trainkind >=100 and ddt='HHT'   and b_timestamp > to_date(qksrq,'yyyy-mm-dd hh24:mi')) ; 



CURSOR read_lint_tt_ah IS
SELECT  id,ddcc,to_char(cfsj,'yyyy-mm-dd hh24:mi')  from tdmsxd2.xd_train_tt where  node='安化'  and cfsj >to_date(kssj,'yyyy-mm-dd hh24:mi') 
and cfsj <=to_date(jssj,'yyyy-mm-dd hh24:mi')  and ddcc not like '5%' and id in 
(select id from xd_trainline  where trainkind >=100 and ddt='HK2T'   and b_timestamp > to_date(qksrq,'yyyy-mm-dd hh24:mi')) ; 


CURSOR read_lint_tt_zjjb IS
SELECT  id,ddcc,to_char(cfsj,'yyyy-mm-dd hh24:mi'),zx+1  from tdmsxd2.xd_train_tt where  node='张家界北'  and cfsj >to_date(kssj,'yyyy-mm-dd hh24:mi') 
and cfsj <=to_date(jssj,'yyyy-mm-dd hh24:mi')  and ddcc not like '5%' and id in 
(select id from xd_trainline  where trainkind >=100 and ddt='JL1T'   and b_timestamp > to_date(qksrq,'yyyy-mm-dd hh24:mi')) ; 


CURSOR read_lint_tt_ldx IS
SELECT  id,ddcc,to_char(cfsj,'yyyy-mm-dd hh24:mi'),zx+1  from tdmsxd2.xd_train_tt where  node='娄底'  and cfsj >to_date(kssj,'yyyy-mm-dd hh24:mi') 
and cfsj <=to_date(jssj,'yyyy-mm-dd hh24:mi')  and ddcc not like '5%' and (xbid=6136 or  zqjid=6136) and id in 
(select id from xd_trainline  where trainkind >=100 and ddt='HK1T'   and b_timestamp > to_date(qksrq,'yyyy-mm-dd hh24:mi')) ; 

CURSOR read_lint_tt_zb IS
SELECT  id,ddcc,to_char(cfsj,'yyyy-mm-dd hh24:mi'),zx+2,node  from tdmsxd2.xd_train_tt where  node in ('株洲北Ⅲ场','株洲北Ⅵ场')  and cfsj >to_date(kssj,'yyyy-mm-dd hh24:mi') 
and cfsj <=to_date(jssj,'yyyy-mm-dd hh24:mi')  and ddcc not like '5%'  and cfcc not in ('X103','X111') and id in 
(select id from xd_trainline  where trainkind >=100 and ddt='ZZT'   and b_timestamp > to_date(qksrq,'yyyy-mm-dd hh24:mi') and zc_yx<>1 ) ; 

CURSOR read_lint_tt_xtd IS
SELECT  id,ddcc,to_char(cfsj,'yyyy-mm-dd hh24:mi'),zx+1  from tdmsxd2.xd_train_tt where  node in ('湘潭东')  and cfsj >to_date(kssj,'yyyy-mm-dd hh24:mi') 
and cfsj <=to_date(jssj,'yyyy-mm-dd hh24:mi')  and ddcc not like '5%' and zx=0 and cfcc not like '45%' and cfcc not in ('X103','X111') and id in 
(select id from xd_trainline  where trainkind >=100 and ddt='HK1T'   and b_timestamp > to_date(qksrq,'yyyy-mm-dd hh24:mi') and zr_sf=1 ) ; 



begin
    select to_char(sysdate -3,'yyyy-mm-dd')   into qksrq  from dual;
    select to_char(sysdate -1,'yyyy-mm-dd')   into ksrq  from dual;
    select to_char(sysdate -0 , 'yyyy-mm-dd')   into jsrq  from dual;
    delete from tdmsxd2.dds_cls_gcdata where rq=jsrq;
    delete from tdmsxd2.dds_cls_gcdata2 where rq=jsrq;
    commit;
------第一班统计
    qksrq :=qksrq || ' 00:00';
    kssj :=ksrq || ' 19:00';
    jssj :=jsrq || ' 08:00';

    ii := 0;  
OPEN read_lint_tt;
       LOOP
       FETCH read_lint_tt INTO wid,cc,gcsj;
       EXIT WHEN read_lint_tt%NOTFOUND;    
       ii :=ii + 1;
       insert into tdmsxd2.dds_cls_gcdata values (jsrq,'第一班',wid,cc,gcsj,'田心');
end loop;
commit;
CLOSE read_lint_tt; 


----怀化东
   ii := 0;  
OPEN read_lint_tt_hd;
       LOOP
       FETCH read_lint_tt_hd INTO wid,cc,gcsj,zxid;
       EXIT WHEN read_lint_tt_hd%NOTFOUND;
       
       begin
       SELECT  node into wzm from tdmsxd2.xd_train_tt where  id=wid and zx=zxid ;
       EXCEPTION 
        WHEN OTHERS THEN
          wzm:='';
 ----       ROLLBACK;
       end;
       if wzm='泸阳' then         
          ii :=ii + 1;
          insert into tdmsxd2.dds_cls_gcdata values (jsrq,'第一班',wid,cc,gcsj,'怀化东');
       end if;
end loop;
commit;
CLOSE read_lint_tt_hd; 

-------安化

ii := 0;  
OPEN read_lint_tt_ah;
       LOOP
       FETCH read_lint_tt_ah INTO wid,cc,gcsj;
       EXIT WHEN read_lint_tt_ah%NOTFOUND;    
       ii :=ii + 1;
       insert into tdmsxd2.dds_cls_gcdata values (jsrq,'第一班',wid,cc,gcsj,'安化');
end loop;
commit;
CLOSE read_lint_tt_ah;




----第二班统计
    kssj :=jsrq || ' 08:00';
    jssj :=jsrq || ' 19:00';  
OPEN read_lint_tt;
       LOOP
       FETCH read_lint_tt INTO wid,cc,gcsj;
       EXIT WHEN read_lint_tt%NOTFOUND;    
       ii :=ii + 1;
       insert into tdmsxd2.dds_cls_gcdata values (jsrq,'第二班',wid,cc,gcsj,'田心');
end loop;
   commit;
CLOSE read_lint_tt; 

----怀化东
   ii := 0;  
OPEN read_lint_tt_hd;
       LOOP
       FETCH read_lint_tt_hd INTO wid,cc,gcsj,zxid;
       EXIT WHEN read_lint_tt_hd%NOTFOUND;
       begin
       SELECT  node into wzm from tdmsxd2.xd_train_tt where  id=wid and zx=zxid ;
       EXCEPTION 
        WHEN OTHERS THEN
          wzm:='';
-----        ROLLBACK;
       end;
       if wzm='泸阳' then     
           ii :=ii + 1;
           insert into tdmsxd2.dds_cls_gcdata values (jsrq,'第二班',wid,cc,gcsj,'怀化东');
       end if;
end loop;
commit;
CLOSE read_lint_tt_hd; 



--------安化
 ii := 0;  
OPEN read_lint_tt_ah;
       LOOP
       FETCH read_lint_tt_ah INTO wid,cc,gcsj;
       EXIT WHEN read_lint_tt_ah%NOTFOUND;    
      ii :=ii + 1;
       insert into tdmsxd2.dds_cls_gcdata values (jsrq,'第二班',wid,cc,gcsj,'安化');
end loop;
commit;
CLOSE read_lint_tt_ah; 

---------------2015-11-03一个方向开车及时间18:00----06:00 06:00-18:00
--------------------------株北西线
------第一班统计
    kssj :=ksrq || ' 18:0';
    jssj :=jsrq || ' 06:00';

--    ii := 0;  
--OPEN read_lint_tt;
--       LOOP
--       FETCH read_lint_tt INTO wid,cc,gcsj;
--       EXIT WHEN read_lint_tt%NOTFOUND;    
--       ii :=ii + 1;
--       insert into tdmsxd2.dds_cls_gcdata2 values (jsrq,'第一班',wid,cc,gcsj,'田心');
--end loop;
--commit;
--CLOSE read_lint_tt; 
------株洲北
   ii := 0;  
OPEN read_lint_tt_zb;
       LOOP
       FETCH read_lint_tt_zb INTO wid,cc,gcsj,zxid,tjzm;
       EXIT WHEN read_lint_tt_zb%NOTFOUND;
       begin
       SELECT  node into wzm from tdmsxd2.xd_train_tt where  id=wid and zx=zxid ;
       EXCEPTION 
        WHEN OTHERS THEN
          wzm:='';
----        ROLLBACK;
       end;
       if wzm='十里冲' then    
          ii :=ii + 1;
          insert into tdmsxd2.dds_cls_gcdata2 values (jsrq,'第一班',wid,cc,gcsj,'株洲北西线',tjzm);
       end if;
end loop;
commit;
CLOSE read_lint_tt_zb; 



OPEN read_lint_tt_xtd;
       LOOP
       FETCH read_lint_tt_xtd INTO wid,cc,gcsj,zxid;
       EXIT WHEN read_lint_tt_xtd%NOTFOUND;
       begin
       SELECT  node into wzm from tdmsxd2.xd_train_tt where  id=wid and zx=zxid ;
       EXCEPTION 
        WHEN OTHERS THEN
          wzm:='';
----        ROLLBACK;
       end;
       if wzm='湘潭' then    
          ii :=ii + 1;
          insert into tdmsxd2.dds_cls_gcdata2 values (jsrq,'第一班',wid,cc,gcsj,'株洲北西线','湘潭东');
       end if;
end loop;
commit;
CLOSE read_lint_tt_xtd; 






----怀化东
   ii := 0;  
OPEN read_lint_tt_hd;
       LOOP
       FETCH read_lint_tt_hd INTO wid,cc,gcsj,zxid;
       EXIT WHEN read_lint_tt_hd%NOTFOUND;
       begin
       SELECT  node into wzm from tdmsxd2.xd_train_tt where  id=wid and zx=zxid ;
       EXCEPTION 
        WHEN OTHERS THEN
          wzm:='';
----        ROLLBACK;
       end;
       if wzm='泸阳' then    
          ii :=ii + 1;
          insert into tdmsxd2.dds_cls_gcdata2 values (jsrq,'第一班',wid,cc,gcsj,'怀化东','');
       end if;
end loop;
commit;
CLOSE read_lint_tt_hd; 

-------娄底车站

ii := 0;  
OPEN read_lint_tt_ldx;
       LOOP
       FETCH read_lint_tt_ldx INTO wid,cc,gcsj,zxid;
       EXIT WHEN read_lint_tt_ldx%NOTFOUND;    

       begin
       SELECT  node into wzm from tdmsxd2.xd_train_tt where  id=wid and zx=zxid and zqjid<>19438 ;
       EXCEPTION 
        WHEN OTHERS THEN
          wzm:='';
 ----       ROLLBACK;
       end;
       if wzm='百亩井' or wzm ='娄底东' then 
          ii :=ii + 1;
          if  wzm='百亩井' then 
               insert into tdmsxd2.dds_cls_gcdata2 values (jsrq,'第一班',wid,cc,gcsj,'娄底西线','');
           else
               insert into tdmsxd2.dds_cls_gcdata2 values (jsrq,'第一班',wid,cc,gcsj,'娄底东线','');
           end if;
       end if;
end loop;
commit;
CLOSE read_lint_tt_ldx;
--------张家界北
ii := 0;  
OPEN read_lint_tt_zjjb;
       LOOP
       FETCH read_lint_tt_zjjb INTO wid,cc,gcsj,zxid;
       EXIT WHEN read_lint_tt_zjjb%NOTFOUND;
        begin
       SELECT  node into wzm from tdmsxd2.xd_train_tt where  id=wid and zx=zxid ;
       EXCEPTION 
        WHEN OTHERS THEN
          wzm:='';
 ----       ROLLBACK;
       end;
       if wzm='张家界' then     
           ii :=ii + 1;
           insert into tdmsxd2.dds_cls_gcdata2 values (jsrq,'第一班',wid,cc,gcsj,'张家界北南线','');
       end if;
end loop;
commit;
CLOSE read_lint_tt_zjjb;



----第二班统计
    kssj :=jsrq || ' 06:00';
    jssj :=jsrq || ' 18:00';  
---OPEN read_lint_tt;
---       LOOP
---       FETCH read_lint_tt INTO wid,cc,gcsj;
---       EXIT WHEN read_lint_tt%NOTFOUND;    
---       ii :=ii + 1;
---       insert into tdmsxd2.dds_cls_gcdata2 values (jsrq,'第二班',wid,cc,gcsj,'田心');
---end loop;
---   commit;
----CLOSE read_lint_tt;
-----株洲北 
  ii := 0;  
OPEN read_lint_tt_zb;
       LOOP
       FETCH read_lint_tt_zb INTO wid,cc,gcsj,zxid,tjzm;
       EXIT WHEN read_lint_tt_zb%NOTFOUND;
       begin
       SELECT  node into wzm from tdmsxd2.xd_train_tt where  id=wid and zx=zxid ;
       EXCEPTION 
        WHEN OTHERS THEN
          wzm:='';
----        ROLLBACK;
       end;
       if wzm='十里冲' then    
          ii :=ii + 1;
          insert into tdmsxd2.dds_cls_gcdata2 values (jsrq,'第二班',wid,cc,gcsj,'株洲北西线',tjzm);
       end if;
end loop;
commit;
CLOSE read_lint_tt_zb; 

OPEN read_lint_tt_xtd;
       LOOP
       FETCH read_lint_tt_xtd INTO wid,cc,gcsj,zxid;
       EXIT WHEN read_lint_tt_xtd%NOTFOUND;
       begin
       SELECT  node into wzm from tdmsxd2.xd_train_tt where  id=wid and zx=zxid ;
       EXCEPTION 
        WHEN OTHERS THEN
          wzm:='';
----        ROLLBACK;
       end;
       if wzm='湘潭' then    
          ii :=ii + 1;
          insert into tdmsxd2.dds_cls_gcdata2 values (jsrq,'第二班',wid,cc,gcsj,'株洲北西线','湘潭');
       end if;
end loop;
commit;
CLOSE read_lint_tt_xtd; 



----怀化东
   ii := 0;  
OPEN read_lint_tt_hd;
       LOOP
       FETCH read_lint_tt_hd INTO wid,cc,gcsj,zxid;
       EXIT WHEN read_lint_tt_hd%NOTFOUND; 
       begin
       SELECT  node into wzm from tdmsxd2.xd_train_tt where  id=wid and zx=zxid ;
       EXCEPTION 
        WHEN OTHERS THEN
          wzm:='';
 ----       ROLLBACK;
       end;
       if wzm='泸阳' then    
          ii :=ii + 1;
          insert into tdmsxd2.dds_cls_gcdata2 values (jsrq,'第二班',wid,cc,gcsj,'怀化东','');
       end if ;
end loop;
commit;
CLOSE read_lint_tt_hd; 



--------安化
 ii := 0;  
OPEN read_lint_tt_ah;
       LOOP
       FETCH read_lint_tt_ah INTO wid,cc,gcsj;
       EXIT WHEN read_lint_tt_ah%NOTFOUND;    
       ii :=ii + 1;
       insert into tdmsxd2.dds_cls_gcdata2 values (jsrq,'第二班',wid,cc,gcsj,'安化','');
end loop;
commit;
CLOSE read_lint_tt_ah; 




-------娄底车站

ii := 0;  
OPEN read_lint_tt_ldx;
       LOOP
       FETCH read_lint_tt_ldx INTO wid,cc,gcsj,zxid;
       EXIT WHEN read_lint_tt_ldx%NOTFOUND;    

       begin
       SELECT  node into wzm from tdmsxd2.xd_train_tt where  id=wid and zx=zxid and zqjid<>19438 ;
       EXCEPTION 
        WHEN OTHERS THEN
          wzm:='';
 ----       ROLLBACK;
       end;
       if wzm='百亩井' or wzm ='娄底东' then 
          ii :=ii + 1;
          if  wzm='百亩井' then 
               insert into tdmsxd2.dds_cls_gcdata2 values (jsrq,'第二班',wid,cc,gcsj,'娄底西线','');
           else
               insert into tdmsxd2.dds_cls_gcdata2 values (jsrq,'第二班',wid,cc,gcsj,'娄底东线','');
           end if;
       end if;
end loop;
commit;
CLOSE read_lint_tt_ldx;



--------张家界北
ii := 0;  
OPEN read_lint_tt_zjjb;
       LOOP
       FETCH read_lint_tt_zjjb INTO wid,cc,gcsj,zxid;
       EXIT WHEN read_lint_tt_zjjb%NOTFOUND; 
       begin
       SELECT  node into wzm from tdmsxd2.xd_train_tt where  id=wid and zx=zxid  ;
       EXCEPTION 
        WHEN OTHERS THEN
          wzm:='';
------        ROLLBACK;
       end;
       if wzm='张家界' then    
          ii :=ii + 1;
          insert into tdmsxd2.dds_cls_gcdata2 values (jsrq,'第二班',wid,cc,gcsj,'张家界北南线','');
       end if;
end loop;
commit;
CLOSE read_lint_tt_zjjb;

    
    
end sunday_cls_gctj;
/

