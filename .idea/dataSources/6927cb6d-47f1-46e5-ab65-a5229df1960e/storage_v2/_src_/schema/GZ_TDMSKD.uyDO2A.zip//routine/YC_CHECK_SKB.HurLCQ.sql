create procedure yc_check_skb(plan1  varchar2,plan2  varchar2 ) is
id  varchar2(30);
cc  varchar2(30);
cs  NUMBER(10);
cc1    varchar2(30);
xh1      varchar2(30);
czm1     varchar2(30);
ddsj1    varchar2(30);
cfsj1    varchar2(30);
lx1      varchar2(30);
cc2    varchar2(30);
xh2      varchar2(30);
czm2     varchar2(30);
ddsj2    varchar2(30);
cfsj2    varchar2(30);
lx2      varchar2(30);

tain_id  varchar2(30);
train_no varchar2(30);
aa number(3);
bb number(3);

 CURSOR check_cc  IS  select train_id,train_no from TRAIN_INFO t where plan =plan1   ;  
 CURSOR check_skb IS  select train_no,sta_sort,sta_name,arrive_time,start_time,sta_type from TRAIN_SCHEDULE t where train_id=id order by sta_sort;

begin
 -- plan1:='15年春运节前图';
 -- plan2:='14_1210[运函895]';
  
   OPEN check_cc;
   LOOP
      FETCH check_cc INTO id,cc;
      EXIT WHEN check_cc%NOTFOUND;  
      
        SELECT count(*) into cs FROM TRAIN_INFO  where train_no  =cc and  plan =plan2; 
        if cs<>0 then --如果找到则继续核对时刻数据
          --打开查找时刻表的游标
          OPEN check_skb;
          loop
            FETCH check_skb INTO cc1,xh1,czm1,ddsj1,cfsj1,lx1; 
            EXIT WHEN check_skb%NOTFOUND; 
            /*if cc='2012' then 
               dbms_output.put_line(cc);
            end if; */
            select count(*) into cs from YC_ZMZDB where zm=czm1;  --如果是广铁车站或局界口就进行判断
            if cs<>0 then
              select count(*) into cs from TRAIN_SCHEDULE t where  train_id in (select train_id  from TRAIN_INFO t where plan =plan2 and train_no=cc and sta_name=czm1)   ;
                 if cs<>0 then
                     select train_no,sta_sort,sta_name,arrive_time,start_time,sta_type into cc2,xh2,czm2,ddsj2,cfsj2,lx2 from TRAIN_SCHEDULE t where  train_id in (select train_id  from TRAIN_INFO t where plan =plan2 and train_no=cc and sta_name=czm1) and rownum=1   ;
                     if cc1<>cc2 then 
                        insert into yc_log (plan1,cc1,czm1,plan2,cc2,czm2,log) values(plan1,cc1,czm1,plan2,cc2,czm2,plan1||'中车次为'||cc1||','||plan2||'中车次为'||cc2||','||'车次不一致');
                     end if;
                     if ddsj1<>ddsj2 then 
                        insert into yc_log (plan1,cc1,czm1,plan2,cc2,czm2,log) values(plan1,cc1,czm1,plan2,cc2,czm2,plan1||'中到达时间为'||ddsj1||','||plan2||'中到达时间为'||ddsj2||','||'到达时间不一致');
                     end if;
                     if cfsj1<>cfsj2 then 
                        insert into yc_log (plan1,cc1,czm1,plan2,cc2,czm2,log) values(plan1,cc1,czm1,plan2,cc2,czm2,plan1||'中出发时间为'||cfsj1||','||plan2||'中出发时间为'||cfsj2||','||'出发时间不一致');
                     end if;
                    aa:= length(lx1);
                    bb:=length(lx2);
                    if length(lx1)<>length(lx2) or (lx1 is null and lx2 is not null) or (lx1 is not null and lx2 is  null) then   --如果标志字段长度不一致，直接插入记录
                        insert into yc_log (plan1,cc1,czm1,bz1,plan2,cc2,czm2,bz2,log) values(plan1,cc1,czm1,lx1,plan2,cc2,czm2,lx2,plan1||'中标志为'||lx1||','||plan2||'中标志为'||lx2||','||'标志不一致');
                     else   --如果长度一致，有可以是顺序不同，则要判断
                        if length(lx1)<>0 and  length(lx2)<>0 then 
                          
                          for i in 1..length(lx2) loop  
                               if instr(lx1,substr(lx2,i,1))=0 then --如果标志2不在标志1里面，则插入记录
                                  insert into yc_log (plan1,cc1,czm1,bz1,plan2,cc2,czm2,bz2,log) values(plan1,cc1,czm1,lx1,plan2,cc2,czm2,lx2,plan1||'中标志为'||lx1||','||plan2||'中标志为'||lx2||','||'标志不一致');
                               end if;
                          end loop;
                        end if;
                     end if;
                    
               else
                     insert into yc_log (plan1,cc1,czm1,bz1,log) values(plan1,cc1,czm1,lx1,'方案2中无此站数据。');
               end if;
               commit;
            end if;
          end loop; 
          close check_skb;
        
      
        else
         insert into yc_log (plan1,cc1,log) values(plan1,cc,'方案2中找不到数据。');
         commit;
         --如果找到则继续核对时刻数据
        end if;
      
    
   end loop; 
   close check_cc;
end yc_check_skb;
/

