create procedure PRO_YXSJ_LCYXMX is
  /*本存储过程用于从T/D结合数据库xd_train_tt表中采集客调车次字典库YXSJ_LJZD_CC表中所维护的列车在路局范围内的"发/接"和"交/到"的串线数据，
  取数完成之后调用另一个存储过程 PRO_YXSJ_LCYXMX_JS，计算增晚和赶点时间，根据列车ID填写调度台，根据站名映射填写显示站名*/

  v_has1  number(1) := 0; /*临时变量，取数时用*/
  v_index number(1); /*数组内变量，用以计数*/
  v_count number(1);
  v_tmp   varchar(10); /*临时日期，用以判断是否已经取数*/
  tmp_zm  YXSJ_LJZD_CC.SF_ZM%type; /*临时站名，取数时用*/

  v_sfid   yxsj_xd_traintt.id%type; /*列车始发ID，用以匹配XD_DDT表中的ID，到始发数据是来源于哪个行调台*/
  v_jrid   yxsj_xd_traintt.id%type; /*列车接入ID，用以匹配XD_DDT表中的ID，到接入数据是来源于哪个行调台*/
  v_jcid   yxsj_xd_traintt.id%type; /*列车交出ID，用以匹配XD_DDT表中的ID，到交出数据是来源于哪个行调台*/
  v_zdid   yxsj_xd_traintt.id%type; /*列车终到ID，用以匹配XD_DDT表中的ID，到终到数据是来源于哪个行调台*/
  v_cfsj   yxsj_xd_traintt.cfsj%type; /*实际出发时间，对应于yxsj_xd_traintt表中的实际出发时间*/
  v_ddsj   yxsj_xd_traintt.ddsj%type; /*实际到达时间，对应于yxsj_xd_traintt表中的实际到达时间*/
  v_tdcfsj yxsj_xd_traintt.tdcfsj%type; /*图定出发时间，对应于yxsj_xd_traintt表中的图定出发时间*/
  v_tdddsj yxsj_xd_traintt.tdddsj%type; /*图定到达时间，对应于yxsj_xd_traintt表中的图定到达时间*/

  v_sfwd yxsj_ljlcyxmx.sf_wd%type; /*始发晚点时间，填写至YXSJ_LJZD_CC表*/

  v_jrtd yxsj_ljlcyxmx.jr_td%type; /*接入图定时间，填写至YXSJ_LJZD_CC表*/
  v_jrsj yxsj_ljlcyxmx.jr_sj%type; /*接入实际时间，填写至YXSJ_LJZD_CC表*/
  v_jrwd yxsj_ljlcyxmx.jr_wd%type; /*接入晚点时间，填写至YXSJ_LJZD_CC表*/

  v_jctd yxsj_ljlcyxmx.jc_td%type; /*交出图定时间，填写至YXSJ_LJZD_CC表*/
  v_jcsj yxsj_ljlcyxmx.jc_sj%type; /*接出实际时间，填写至YXSJ_LJZD_CC表*/
  v_jcwd yxsj_ljlcyxmx.jc_wd%type; /*交出晚点时间，填写至YXSJ_LJZD_CC表*/

  v_zdtd yxsj_ljlcyxmx.zd_td%type; /*终到图定时间，填写至YXSJ_LJZD_CC表*/
  v_zdsj yxsj_ljlcyxmx.zd_sj%type; /*终到实际时间，填写至YXSJ_LJZD_CC表*/
  v_zdwd yxsj_ljlcyxmx.zd_wd%type; /*终到晚点时间，填写至YXSJ_LJZD_CC表*/

  v_tdjcrq varchar(10); /*图定交出日期，根据图定交出时间截出的日期*/
  v_tdzdrq varchar(10); /*图定终到日期，根据图定终到时间截出的日期*/

  v_sfrq yxsj_ljlcyxmx.sfrq%type; /*图定始发日期，由图定交出日期减去交出天数 或者 图定终到日期减去终到天数得到*/
  v_jrrq yxsj_ljlcyxmx.jr_sj%type; /*图定接入日期，由图定始发日期加上接入天数得到*/

  v_jcflag number(1); /*交出标志，用以判断是否具备插数的条件*/
  v_jrflag number(1); /*接入标志，用以判断是否具备插数的条件*/

  /*定义数组交出ID、交出图定、交出实际、交出晚点---start*/
  TYPE jctd_array IS TABLE OF date INDEX BY BINARY_INTEGER;
  jctd jctd_array;
  TYPE jcsj_array IS TABLE OF date INDEX BY BINARY_INTEGER;
  jcsj jcsj_array;
  TYPE jcwd_array IS TABLE OF number(6, 2) INDEX BY BINARY_INTEGER;
  jcwd jcwd_array;
  TYPE jcid_array IS TABLE OF number(10) INDEX BY BINARY_INTEGER;
  jcid jcid_array;
  /*定义数组交出ID、交出图定、交出实际、交出晚点---end*/

  /*定义游标1——d: 遍历车次字典表YXSJ_LJZD_CC ---start*/
  cursor d is
    select LJ_JC,
           LJDM,
           LCLX,
           LCLX_XH,
           CC,
           QCC,
           LJ_XH,
           YXFS,
           SF_ZM,
           JR_ZM,
           JR_TS,
           JC_ZM,
           JC_TS,
           ZD_ZM,
           ZD_TS
      from YXSJ_LJZD_CC;
  d_rec d%rowtype;
  /*定义游标1——d: 遍历车次字典表YXSJ_LJZD_CC ---end*/

  /*定义游标2——select_dd: 终到游标---start*/
  /*以终到站名和全车次为参数，取出当天18点区段内，该车次在该终到站报点的数据，没报点时记录数为0，一个台报点时记录为1，遇有两天晚点在一个18点区段内时记录数再加1，
  这里的语句中使用了和取数结果 yxsj_ljlcyxmx 表中比较日期，当天已取过则不再取，所以多次执行本存储过程时不会重复取，另外遇有两个行调台同时报同一天的数据时，只取第一条数据。
  这里返回数据集，按照图定到达时间倒排序*/
  cursor select_dd(v_node varchar, v_qcc varchar) is
    select id,
           ddsj,
           tdddsj,
           trim(to_char((trunc((ddsj - tdddsj) * 24) +
                        ((ddsj - tdddsj) * 24 -
                        trunc((ddsj - tdddsj) * 24)) * 60 / 100),
                        '999.99')) zd_wd
      from yxsj_xd_traintt
     where instr('-' || v_qcc, '-' || ddcc || '-') > 0
       and ddsj >=
           to_date(to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd HH24:MI:SS') - 0.25
       and ddsj <=
           to_date(to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd HH24:MI:SS') + 0.75
       and trim(node) = trim(v_node)
       and to_char(tdddsj, 'yyyymmdd') not in
           (select to_char(zd_td, 'yyyymmdd')
              from yxsj_ljlcyxmx
             where to_char(tbrq, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')
               and instr('-' || qcc, '-' || yxsj_xd_traintt.ddcc || '-') > 0
               and trim(zd_zm) = trim(v_node)) and rownum<2
     order by tdddsj;
  dd_rec select_dd%rowtype;
  /*定义游标2——select_dd: 终到游标---end*/

  /*定义游标3——select_jc1: 交出游标（交出口为本局管辖）---start*/
  /*以交出站名和全车次为参数，取出当天18点区段内，该车次在该交出站报点的数据，没报点时记录数为0，一个台报点时记录为1，遇有两天晚点在一个18点区段内时记录数再加1，
  这里的语句中使用了和取数结果 yxsj_ljlcyxmx 表中比较日期，当天已取过则不再取，所以多次执行本存储过程时不会重复取，另外遇有两个行调台同时报同一天的数据时，只取第一条数据。
  这里返回数据集，按照图定到达时间倒排序，本局管辖的分界口，交出取出发时间*/
  cursor select_jc1(v_node varchar, v_qcc varchar) is
    select id,
           cfsj,
           tdcfsj,
           trim(to_char((trunc((cfsj - tdcfsj) * 24) +
                        ((cfsj - tdcfsj) * 24 -
                        trunc((cfsj - tdcfsj) * 24)) * 60 / 100),
                        '999.99')) jc_wd
      from yxsj_xd_traintt
     where instr('-' || v_qcc, '-' || cfcc || '-') > 0
       and cfsj >
           to_date(to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd HH24:MI:SS') - 0.25
       and cfsj <=
           to_date(to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd HH24:MI:SS') + 0.75
       and trim(node) = trim(v_node)
       and to_char(tdcfsj, 'yyyymmdd') not in
           (select to_char(jc_td, 'yyyymmdd')
              from yxsj_ljlcyxmx
             where to_char(tbrq, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')
               and instr('-' || qcc, '-' || yxsj_xd_traintt.cfcc || '-') > 0
               and trim(jc_zm) = trim(v_node)) and rownum<2
     order by tdcfsj;
  jc1_rec select_jc1%rowtype;
  /*定义游标3——select_jc1: 交出游标（交出口为本局管辖）---end*/

  /*定义游标4——select_jc2: 交出游标（交出口为邻局管辖）---start*/
  /*以交出站名和全车次为参数，取出当天18点区段内，该车次在该交出站报点的数据，没报点时记录数为0，一个台报点时记录为1遇有两天晚点在一个18点区段内时记录数再加1，
  这里的语句中使用了和取数结果 yxsj_ljlcyxmx 表中比较日期，当天已取过则不再取，所以多次执行本存储过程时不会重复取，另外遇有两个行调台同时报同一天的数据时，只取第一条数据。
  这里返回数据集，按照图定到达时间倒排序，邻局管辖的分界口，交出取到达时间*/
  cursor select_jc2(v_node varchar, v_qcc varchar) is
    select id,
           ddsj,
           tdddsj,
           trim(to_char((trunc((ddsj - tdddsj) * 24) +
                        ((ddsj - tdddsj) * 24 -
                        trunc((ddsj - tdddsj) * 24)) * 60 / 100),
                        '999.99')) zd_wd
      from yxsj_xd_traintt
     where instr('-' || v_qcc, '-' || ddcc || '-') > 0
       and ddsj >=
           to_date(to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd HH24:MI:SS') - 0.25
       and ddsj <=
           to_date(to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd HH24:MI:SS') + 0.75
       and trim(node) = trim(v_node)
       and to_char(tdddsj, 'yyyymmdd') not in
           (select to_char(jc_td, 'yyyymmdd')
              from yxsj_ljlcyxmx
             where to_char(tbrq, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')
               and instr('-' || qcc, '-' || yxsj_xd_traintt.ddcc || '-') > 0
               and trim(jc_zm) = trim(v_node)) and rownum<2
     order by tdddsj;
  jc2_rec select_jc2%rowtype;
  /*定义游标4——select_jc2: 交出游标（交出口为邻局管辖）---end*/
  errormessage exception;

  /*开始取数*/
begin
  
 /*删除临时表yxsj_xd_traintt里的数据---start*/
  execute immediate 'truncate table yxsj_xd_traintt';
  /*删除临时表yxsj_xd_traintt里的数据---end*/

  /*从xd_train_tt表取出最近4天的数插入临时表yxsj_xd_traintt---start*/
  insert into yxsj_xd_traintt
    select ID, node, ddsj, cfsj, ddcc, cfcc, tdddsj, tdcfsj
      from xd_train_tt
     where (dfd_falg = 3 or (node = '茂名西' and (dfd_falg=1 or dfd_falg=2)))
       and tdddsj >
           to_date(to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd HH24:MI:SS') - 4;
  /*从xd_train_tt表取出最近4天的数插入临时表yxsj_xd_traintt---end*/

  open d;
  /*第一步：循环遍历车次字典表YXSJ_LJZD_CC*/
  loop
    fetch d
      into d_rec;
    exit when d%notfound;

    if (d_rec.yxfs = '始发终到') or (d_rec.yxfs = '接入终到') then
      tmp_zm := d_rec.zd_zm; /*如果该车属于终到列车，取终到站名，填入临时站名tmp_zm*/
    else
      if (d_rec.yxfs = '始发交出') or (d_rec.yxfs = '接入交出') then
        tmp_zm := d_rec.jc_zm; /*如果该车属于交出列车，取交出站名，填入临时站名tmp_zm*/
      end if;
    end if;

    /*类型1-----始发终到*/
    if (d_rec.yxfs = '始发终到') then
      /*1.1 开始取终到站的信息*/
      v_tmp := '2000-01-01';
      open select_dd(tmp_zm, d_rec.qcc); /*这里将遍历车次字典表YXSJ_LJZD_CC得到的一行记录中的终到站名和全车次作为参数，传入游标2（终到游标）中，返回0行到多行数据集*/
      /*循环遍历返回的数据集*/
      loop
        <<go_sfzd>>
        fetch select_dd
          into dd_rec;
        exit when select_dd%notfound; /*这里说明返回数据集记录数为0，即终到站在该18点区段内没有报点，则跳出循环*/
        if (v_tmp = to_char(dd_rec.tdddsj, 'yyyy-mm-dd')) then
          /*continue;  /*这里说明该记录已取过，则跳出循环*/
          goto go_sfzd;
        else
          /*这里说明该记录未取过，开始取数*/
          v_tdzdrq := to_char(dd_rec.tdddsj, 'yyyy-mm-dd');
          v_sfrq   := to_date(v_tdzdrq, 'yyyy-mm-dd') - d_rec.zd_ts; /*根据终到日期，减去终到天数，得到图定始发日期*/
          v_tdddsj := dd_rec.tdddsj;
          v_ddsj   := dd_rec.ddsj;
          v_zdwd   := dd_rec.zd_wd;
          v_zdid   := dd_rec.id;

          /*1.2 开始取该车次在始发日期时，在始发站的各项数据*/
          v_cfsj := null;
          if not v_sfrq is null then
            begin
              select id,
                     tdcfsj,
                     cfsj,
                     trim(to_char((trunc((cfsj - tdcfsj) * 24) +
                                  ((cfsj - tdcfsj) * 24 -
                                  trunc((cfsj - tdcfsj) * 24)) * 60 / 100),
                                  '999.99')) sf_wd
                into v_sfid, v_tdcfsj, v_cfsj, v_sfwd
                from yxsj_xd_traintt
               where instr('-' || d_rec.qcc, '-' || ddcc || '-') > 0
                 and trim(node) = trim(d_rec.SF_ZM)
                 and to_char(tdcfsj, 'yyyy-mm-dd') =
                     to_char(v_sfrq, 'yyyy-mm-dd')
                 and rownum < 2; /*得到该车次在图定始发日期时，在始发站的图定出发时间、实际出发时间、出发晚点时间、始发ID，这里取rownum<2，即有多个行调台报点时只取第一条*/
            exception
              when no_data_found then
                null;
            end;
          end if;
          /*1.3 开始向YXSJ_LJLCYXMX表插入整条串线后的记录*/
          if not v_cfsj is null then
            insert into yxsj_ljlcyxmx
              (lcyxmx_id,
               tbrq,
               lj_jc,
               ljdm,
               lclx,
               lclx_xh,
               cc,
               qcc,
               lj_xh,
               yxfs,
               sf_zm,
               zd_zm,
               zd_ts,
               zd_td,
               zd_sj,
               zd_wd,
               zd_trainid,
               sfrq,
               sf_td,
               sf_sj,
               sf_wd,
               sf_trainid)
            values
              (SEQ_YXSJ_LJLCYXMX.nextval,
               sysdate,
               d_rec.lj_jc,
               d_rec.ljdm,
               d_rec.lclx,
               d_rec.lclx_xh,
               d_rec.cc,
               d_rec.qcc,
               d_rec.lj_xh,
               d_rec.yxfs,
               d_rec.sf_zm,
               d_rec.zd_zm,
               d_rec.zd_ts,
               v_tdddsj,
               v_ddsj,
               v_zdwd,
               v_zdid,
               v_sfrq,
               v_tdcfsj,
               v_cfsj,
               v_sfwd,
               v_sfid);
          end if;
          v_tmp := to_char(dd_rec.tdddsj, 'yyyy-mm-dd'); /*将日期填入v_tmp，以供比较下一条数据集的日期*/
        end if;
      end loop;
      close select_dd;
    end if;

    /*类型2-----接入终到*/
    if (d_rec.yxfs = '接入终到') then
      /*2.1 开始取终到站的信息*/
      v_tmp := '2000-01-01';
      open select_dd(tmp_zm, d_rec.qcc); /*这里将遍历车次字典表YXSJ_LJZD_CC得到的一行记录中的终到站名和全车次作为参数，传入游标2（终到游标）中，返回0行到多行数据集*/
      /*循环遍历返回的数据集*/
      loop
        <<go_jrzd>>
        fetch select_dd
          into dd_rec;
        exit when select_dd%notfound; /*这里说明返回数据集记录数为0，即终到站在该18点区段内没有报点，则跳出循环*/
        if (v_tmp = to_char(dd_rec.tdddsj, 'yyyy-mm-dd')) then
          /*continue;  /*这里说明该记录已取过，则跳出循环*/
          goto go_jrzd;
        else
          /*这里说明该记录未取过，开始取数*/
          v_zdtd   := dd_rec.tdddsj;
          v_zdsj   := dd_rec.ddsj;
          v_zdwd   := dd_rec.zd_wd;
          v_zdid   := dd_rec.id;
          v_tdzdrq := to_char(dd_rec.tdddsj, 'yyyy-mm-dd');
          v_sfrq   := to_date(v_tdzdrq, 'yyyy-mm-dd') - d_rec.zd_ts; /*根据图定终到日期，减去终到天数，得到图定始发日期*/
          v_jrrq   := v_sfrq + d_rec.jr_ts; /*根据图定始发日期，加上接入天数，得到图定接入日期*/
          v_jrflag := 0;

          if not v_jrrq is null then
            /*2.2 开始取该车次在图定接入日期时，在接入站的各项数据*/

            /*判断接入站是否为本局管辖，本局管则接入取到达时间，邻局管则接入取出发时间*/
            v_has1 := 0;

            /*2.2.1 当接入站为本局管辖时*/
            select count(*)
              into v_has1
              from v_yxsj_ljzdfjk1
             where trim(fjk_name) = trim(d_rec.jr_zm);
            if (v_has1 > 0) then
              v_ddsj := null;
              begin
                select id, tdcfsj, tdddsj, cfsj, ddsj
                  into v_jrid, v_tdcfsj, v_tdddsj, v_cfsj, v_ddsj
                  from yxsj_xd_traintt
                 where instr('-' || d_rec.qcc, '-' || ddcc || '-') > 0
                   and trim(node) = trim(d_rec.jr_zm)
                   and to_char(tdddsj, 'yyyy-mm-dd') =
                       to_char(v_jrrq, 'yyyy-mm-dd')
                   and rownum < 2; /*得到该车次在图定接入日期时，在接入站的图定出发时间、实际出发时间、图定到达时间、实际到达时间、接入ID*/
              exception
                when no_data_found then
                  null;
              end;
              if not v_ddsj is null then
                v_jrtd   := v_tdddsj; /*接入图定时间，取图定到达时间*/
                v_jrsj   := v_ddsj; /*接入实际时间，取实际到达时间*/
                v_jrwd   := to_number(trim(to_char((trunc((v_ddsj -
                                                          v_tdddsj) * 24) +
                                                   ((v_ddsj - v_tdddsj) * 24 -
                                                   trunc((v_ddsj -
                                                           v_tdddsj) * 24)) * 60 / 100),
                                                   '999.99')),
                                      '999.99'); /*接入晚点时间，取实际到达时间减去图定到达时间的值*/
                v_jrflag := 1; /*设置接入标记值为1，即满足取接入站数据的条件*/
              end if;
            end if;

            /*2.2.2 当接入站为邻局管辖时*/
            v_has1 := 0;
            select count(*)
              into v_has1
              from v_yxsj_ljzdfjk2
             where trim(fjk_name) = trim(d_rec.jr_zm);
            if (v_has1 > 0) then
              v_cfsj := null;
              begin
                select id, tdcfsj, tdddsj, cfsj, ddsj
                  into v_jrid, v_tdcfsj, v_tdddsj, v_cfsj, v_ddsj
                  from yxsj_xd_traintt
                 where instr('-' || d_rec.qcc, '-' || ddcc || '-') > 0
                   and trim(node) = trim(d_rec.jr_zm)
                   and to_char(tdcfsj, 'yyyy-mm-dd') =
                       to_char(v_jrrq, 'yyyy-mm-dd')
                   and rownum < 2; /*得到该车次在图定接入日期时，在接入站的图定出发时间、实际出发时间、图定到达时间、实际到达时间、接入ID*/
              exception
                when no_data_found then
                  null;
              end;
              if not v_cfsj is null then
                v_jrtd   := v_tdcfsj; /*接入图定时间，取图定出发时间*/
                v_jrsj   := v_cfsj; /*接入实际时间，取实际出发时间*/
                v_jrwd   := to_number(trim(to_char((trunc((v_cfsj -
                                                          v_tdcfsj) * 24) +
                                                   ((v_cfsj - v_tdcfsj) * 24 -
                                                   trunc((v_cfsj -
                                                           v_tdcfsj) * 24)) * 60 / 100),
                                                   '999.99')),
                                      '999.99'); /*接入晚点时间，取实际出发时间减去图定出发时间的值*/
                v_jrflag := 1; /*设置接入标记值为1，即满足取接入站数据的条件*/
              end if;
            end if;
          end if;

          /*2.3 开始向YXSJ_LJLCYXMX表插入整条串线后的记录*/
          if (v_jrflag = 1) then
            insert into yxsj_ljlcyxmx
              (lcyxmx_id,
               tbrq,
               lj_jc,
               ljdm,
               lclx,
               lclx_xh,
               cc,
               qcc,
               lj_xh,
               yxfs,
               jr_zm,
               jr_Ts,
               zd_zm,
               zd_ts,
               zd_td,
               zd_sj,
               zd_wd,
               sfrq,
               jr_td,
               jr_sj,
               jr_wd,
               zd_trainid,
               jr_trainid)
            values
              (SEQ_YXSJ_LJLCYXMX.nextval,
               sysdate,
               d_rec.lj_jc,
               d_rec.ljdm,
               d_rec.lclx,
               d_rec.lclx_xh,
               d_rec.cc,
               d_rec.qcc,
               d_rec.lj_xh,
               d_rec.yxfs,
               d_rec.jr_zm,
               d_rec.jr_ts,
               d_rec.zd_zm,
               d_rec.zd_ts,
               v_zdtd,
               v_zdsj,
               v_zdwd,
               v_sfrq,
               v_jrtd,
               v_jrsj,
               v_jrwd,
               v_zdid,
               v_jrid);
          end if;
          v_tmp := to_char(dd_rec.tdddsj, 'yyyy-mm-dd'); /*将日期填入v_tmp，以供比较下一条数据集的日期*/
        end if;
      end loop;
      close select_dd;
    end if;

    /*类型3-----始发交出*/
    if (d_rec.yxfs = '始发交出') then
      /*3.1 交出站为本局管辖时*/
      /*判断交出站是否为本局管辖，本局管则交出取出发时间，邻局管则交出取到达时间*/
      v_has1 := 0;
      select count(*)
        into v_has1
        from v_yxsj_ljzdfjk1
       where trim(fjk_name) = trim(d_rec.jc_zm);
      if (v_has1 > 0) then
        /*说明交出站为本局管辖*/

        /*3.1.1 开始取该车次在交出日期时，在交出站的各项数据*/
        v_tmp := '2000-01-01';
        open select_jc1(tmp_zm, d_rec.qcc); /*这里将遍历车次字典表YXSJ_LJZD_CC得到的一行记录中的交出站名和全车次作为参数，传入游标3（交出游标本局管）中，返回0行到多行数据集*/
        loop
          <<go_sfjc1>>
          fetch select_jc1
            into jc1_rec;
          exit when select_jc1%notfound;
          /*这里说明返回数据集记录数为0，即交出站在该18点区段内没有报点，则跳出循环*/
          if (v_tmp = to_char(jc1_rec.tdcfsj, 'yyyy-mm-dd')) then
            /*continue; /*这里说明该记录已取过，则跳出循环*/
            goto go_sfjc1;
          else
            /*这里说明该记录未取过，开始取数*/
            v_jcid   := jc1_rec.id;
            v_tdcfsj := jc1_rec.tdcfsj;
            v_cfsj   := jc1_rec.cfsj;
            v_jctd   := v_tdcfsj; /*交出图定时间，取图定出发时间*/
            v_jcsj   := v_cfsj; /*交出实际时间，取实际出发时间*/
            v_jcwd   := to_number(trim(to_char((trunc((v_cfsj - v_tdcfsj) * 24) +
                                               ((v_cfsj - v_tdcfsj) * 24 -
                                               trunc((v_cfsj - v_tdcfsj) * 24)) * 60 / 100),
                                               '999.99')),
                                  '999.99'); /*交出晚点时间，取实际出发时间减去图定出发时间的值*/
            v_tdjcrq := to_char(v_tdcfsj, 'yyyy-mm-dd'); /*图定交出日期，根据图定交出时间截出的日期*/
            v_sfrq   := to_date(v_tdjcrq, 'yyyy-mm-dd') - d_rec.jc_ts; /*根据图定交出日期，减去交出天数，得到图定始发日期*/

            /*3.1.2 开始取该车次在始发日期时，在始发站的各项数据*/
            v_cfsj := null;
            if not v_sfrq is null then
              begin
                select id,
                       tdcfsj,
                       cfsj,
                       trim(to_char((trunc((cfsj - tdcfsj) * 24) +
                                    ((cfsj - tdcfsj) * 24 -
                                    trunc((cfsj - tdcfsj) * 24)) * 60 / 100),
                                    '999.99')) sf_wd
                  into v_sfid, v_tdcfsj, v_cfsj, v_sfwd
                  from yxsj_xd_traintt
                 where instr('-' || d_rec.qcc, '-' || ddcc || '-') > 0
                   and trim(node) = trim(d_rec.sf_zm)
                   and to_char(tdcfsj, 'yyyy-mm-dd') =
                       to_char(v_sfrq, 'yyyy-mm-dd')
                   and rownum < 2; /*得到该车次在图定始发日期时，在始发站的图定出发时间、实际出发时间、出发晚点时间、始发ID*/
              exception
                when no_data_found then
                  null;
              end;
            end if;
            /*3.1.3 开始向YXSJ_LJLCYXMX表插入整条串线后的记录*/
            if not v_cfsj is null then
              insert into yxsj_ljlcyxmx
                (lcyxmx_id,
                 tbrq,
                 lj_jc,
                 ljdm,
                 lclx,
                 lclx_xh,
                 cc,
                 qcc,
                 lj_xh,
                 yxfs,
                 sf_zm,
                 sf_td,
                 sf_sj,
                 sf_wd,
                 Jc_zm,
                 jc_ts,
                 sfrq,
                 jc_td,
                 jc_sj,
                 jc_wd,
                 sf_trainid,
                 jc_trainid)
              values
                (SEQ_YXSJ_LJLCYXMX.nextval,
                 sysdate,
                 d_rec.lj_jc,
                 d_rec.ljdm,
                 d_rec.lclx,
                 d_rec.lclx_xh,
                 d_rec.cc,
                 d_rec.qcc,
                 d_rec.lj_xh,
                 d_rec.yxfs,
                 d_rec.sf_zm,
                 v_tdcfsj,
                 v_cfsj,
                 v_sfwd,
                 d_rec.jc_zm,
                 d_rec.jc_ts,
                 v_sfrq,
                 v_jctd,
                 v_jcsj,
                 v_jcwd,
                 v_sfid,
                 v_jcid);
            end if;
            v_tmp := to_char(jc1_rec.tdcfsj, 'yyyy-mm-dd'); /*将日期填入v_tmp，以供比较下一条数据集的日期*/
          end if;
        end loop;
        close select_jc1;
      end if;

      /*3.2 交出站为邻局管辖时*/
      v_has1 := 0;
      select count(*)
        into v_has1
        from v_yxsj_ljzdfjk2
       where trim(fjk_name) = trim(d_rec.jc_zm);
      if (v_has1 > 0) then
        /*说明交出站为邻局管辖*/

        /*3.2.1 开始取该车次在交出日期时，在交出站的各项数据*/
        v_tmp := '2000-01-01';
        open select_jc2(tmp_zm, d_rec.qcc); /*这里将遍历车次字典表YXSJ_LJZD_CC得到的一行记录中的交出站名和全车次作为参数，传入游标3（交出游标邻局管）中，返回0行到多行数据集*/
        loop
          <<go_sfjc2>>
          fetch select_jc2
            into jc2_rec;
          exit when select_jc2%notfound;
          /*这里说明返回数据集记录数为0，即交出站在该18点区段内没有报点，则跳出循环*/
          if (v_tmp = to_char(jc2_rec.tdddsj, 'yyyy-mm-dd')) then
            /*continue; /*这里说明该记录已取过，则跳出循环*/
            goto go_sfjc2;
          else
            /*这里说明该记录未取过，开始取数*/
            v_jcid   := jc2_rec.id;
            v_tdddsj := jc2_rec.tdddsj;
            v_ddsj   := jc2_rec.ddsj;
            v_jctd   := v_tdddsj; /*交出图定时间，取图定到达时间*/
            v_jcsj   := v_ddsj; /*交出实际时间，取实际到达时间*/
            v_jcwd   := to_number(trim(to_char((trunc((v_ddsj - v_tdddsj) * 24) +
                                               ((v_ddsj - v_tdddsj) * 24 -
                                               trunc((v_ddsj - v_tdddsj) * 24)) * 60 / 100),
                                               '999.99')),
                                  '999.99'); /*交出晚点时间，取实际到达时间减去图定到达时间的值*/
            v_tdjcrq := to_char(v_tdddsj, 'yyyy-mm-dd'); /*图定交出日期，根据图定交出时间截出的日期*/
            v_sfrq   := to_date(v_tdjcrq, 'yyyy-mm-dd') - d_rec.jc_ts; /*根据图定交出日期，减去交出天数，得到图定始发日期*/

            /*3.2.2 开始取该车次在始发日期时，在始发站的各项数据*/
            v_cfsj := null;
            if not v_sfrq is null then
              begin
                select id,
                       tdcfsj,
                       cfsj,
                       trim(to_char((trunc((cfsj - tdcfsj) * 24) +
                                    ((cfsj - tdcfsj) * 24 -
                                    trunc((cfsj - tdcfsj) * 24)) * 60 / 100),
                                    '999.99')) sf_wd
                  into v_sfid, v_tdcfsj, v_cfsj, v_sfwd
                  from yxsj_xd_traintt
                 where instr('-' || d_rec.qcc, '-' || ddcc || '-') > 0
                   and trim(node) = trim(d_rec.sf_zm)
                   and to_char(tdcfsj, 'yyyy-mm-dd') =
                       to_char(v_sfrq, 'yyyy-mm-dd')
                   and rownum < 2; /*得到该车次在图定始发日期时，在始发站的图定出发时间、实际出发时间、出发晚点时间、始发ID*/
              exception
                when no_data_found then
                  null;
              end;
            end if;
            /*3.2.3 开始向YXSJ_LJLCYXMX表插入整条串线后的记录*/
            if not v_cfsj is null then
              insert into yxsj_ljlcyxmx
                (lcyxmx_id,
                 tbrq,
                 lj_jc,
                 ljdm,
                 lclx,
                 lclx_xh,
                 cc,
                 qcc,
                 lj_xh,
                 yxfs,
                 sf_zm,
                 sf_td,
                 sf_sj,
                 sf_wd,
                 Jc_zm,
                 jc_ts,
                 sfrq,
                 jc_td,
                 jc_sj,
                 jc_wd,
                 sf_trainid,
                 jc_trainid)
              values
                (SEQ_YXSJ_LJLCYXMX.nextval,
                 sysdate,
                 d_rec.lj_jc,
                 d_rec.ljdm,
                 d_rec.lclx,
                 d_rec.lclx_xh,
                 d_rec.cc,
                 d_rec.qcc,
                 d_rec.lj_xh,
                 d_rec.yxfs,
                 d_rec.sf_zm,
                 v_tdcfsj,
                 v_cfsj,
                 v_sfwd,
                 d_rec.jc_zm,
                 d_rec.jc_ts,
                 v_sfrq,
                 v_jctd,
                 v_jcsj,
                 v_jcwd,
                 v_sfid,
                 v_jcid);
            end if;
            v_tmp := to_char(jc2_rec.tdddsj, 'yyyy-mm-dd'); /*将日期填入v_tmp，以供比较下一条数据集的日期*/
          end if;
        end loop;
        close select_jc2;
      end if;
    end if;

    /*类型4-----接入交出*/
    if (d_rec.yxfs = '接入交出') then
      v_jcflag := 1;
      v_count  := 0;
      /*4.1 开始取该车次在图定交出日期时，在交出站的各项数据*/
      /*4.1.1 交出站为本局管辖，交出取出发时间*/
      v_has1 := 0;
      select count(*)
        into v_has1
        from v_yxsj_ljzdfjk1
       where trim(fjk_name) = trim(d_rec.jc_zm);
      if (v_has1 > 0) then
        /*说明交出站为本局管辖*/
        v_tmp := '2000-01-01';
        open select_jc1(tmp_zm, d_rec.qcc); /*这里将遍历车次字典表YXSJ_LJZD_CC得到的一行记录中的交出站名和全车次作为参数，传入游标3（交出游标本局管）中，返回0行到多行数据集*/
        v_index := 1;
        loop
          <<go_jrjc1>>
          fetch select_jc1
            into jc1_rec;
          exit when select_jc1%notfound;
          /*这里说明返回数据集记录数为0，即终到站在该18点区段内没有报点，则跳出循环*/
          if (v_tmp = to_char(jc1_rec.tdcfsj, 'yyyy-mm-dd')) then
            /*continue; /*这里说明该记录已取过，则跳出循环*/
            v_jcflag := 1;
            goto go_jrjc1;
          else
            /*这里说明该记录未取过，开始取数*/
            v_jcflag := 2; /*设置交出标记的值为2，即满足取交出状态的数据*/
            v_tdcfsj := jc1_rec.tdcfsj;
            v_cfsj := jc1_rec.cfsj;
            jcid(v_index) := jc1_rec.id;
            jctd(v_index) := v_tdcfsj; /*交出图定时间，取图定出发时间*/
            jcsj(v_index) := v_cfsj; /*交出实际时间，取实际出发时间*/
            jcwd(v_index) := to_number(trim(to_char((trunc((v_cfsj -
                                                           v_tdcfsj) * 24) +
                                                    ((v_cfsj - v_tdcfsj) * 24 -
                                                    trunc((v_cfsj -
                                                            v_tdcfsj) * 24)) * 60 / 100),
                                                    '999.99')),
                                       '999.99'); /*交出晚点时间，取实际出发时间减去图定出发时间的值*/
            v_count := v_index;
            v_index := v_index + 1;
            v_tmp := to_char(jc1_rec.tdcfsj, 'yyyy-mm-dd'); /*将日期填入v_tmp，以供比较下一条数据集的日期*/

          end if;
        end loop;
        close select_jc1;
      end if;

      /*4.1.2 交出站为邻局管辖时，交出取到达时间*/
      v_has1 := 0;
      select count(*)
        into v_has1
        from v_yxsj_ljzdfjk2
       where trim(fjk_name) = trim(d_rec.jc_zm);
      if (v_has1 > 0) then
        /*说明交出站为邻局管辖*/
        v_tmp := '2000-01-01';
        open select_jc2(tmp_zm, d_rec.qcc); /*这里将遍历车次字典表YXSJ_LJZD_CC得到的一行记录中的交出站名和全车次作为参数，传入游标4（交出游标邻局管）中，返回0行到多行数据集*/
        v_index := 1;
        loop
          <<go_jrjc2>>
          fetch select_jc2
            into jc2_rec;
          exit when select_jc2%notfound;
          /*这里说明返回数据集记录数为0，即交出站在该18点区段内没有报点，则跳出循环*/
          if (v_tmp = to_char(jc2_rec.tdddsj, 'yyyy-mm-dd')) then
            /*continue; /*这里说明该记录已取过，则跳出循环*/
            v_jcflag := 1;
            goto go_jrjc2;
          else
            /*这里说明该记录未取过，开始取数*/
            v_jcflag := 2; /*设置交出标记的值为2，即满足取交出状态的数据*/
            v_tdddsj := jc2_rec.tdddsj;
            v_ddsj := jc2_rec.ddsj;
            jcid(v_index) := jc2_rec.id;
            jctd(v_index) := v_tdddsj; /*交出图定时间，取图定到达时间*/
            jcsj(v_index) := v_ddsj; /*交出实际时间，取实际到达时间*/
            jcwd(v_index) := to_number(trim(to_char((trunc((v_ddsj -
                                                           v_tdddsj) * 24) +
                                                    ((v_ddsj - v_tdddsj) * 24 -
                                                    trunc((v_ddsj -
                                                            v_tdddsj) * 24)) * 60 / 100),
                                                    '999.99')),
                                       '999.99'); /*交出晚点时间，取实际到达时间减去图定到达时间的值*/
            v_count := v_index;
            v_index := v_index + 1;
            v_tmp := to_char(jc2_rec.tdddsj, 'yyyy-mm-dd'); /*将日期填入v_tmp，以供比较下一条数据集的日期*/

          end if;
        end loop;
        close select_jc2;
      end if;

      /*4.2 开始取该车次在接入日期时，在接入站的各项数据*/
      if (v_jcflag = 2) then
        /* dbms_output.put_line(v_count);*/
        FOR i IN 1 .. v_count LOOP
          v_tdjcrq := to_char(jctd(i), 'yyyy-mm-dd');
          v_sfrq   := to_date(v_tdjcrq, 'yyyy-mm-dd') - d_rec.jc_ts; /*根据图定交出日期，减去交出天数，得到图定始发日期*/
          v_jrrq   := v_sfrq + d_rec.jr_ts; /*根据图定始发日期，加上接入天数，得到图定接入日期*/
          v_jcid   := jcid(i);
          v_jrflag := 0;

          if not v_jrrq is null then
            /*4.2.1 接入站为本局管辖时，接入取到达时间*/
            v_has1 := 0;
            select count(*)
              into v_has1
              from v_yxsj_ljzdfjk1
             where trim(fjk_name) = trim(d_rec.jr_zm);

            if (v_has1 > 0) then
              /*说明接入站为本局管辖*/
              v_ddsj := null;
              begin
                select id, tdcfsj, cfsj, tdddsj, ddsj
                  into v_jrid, v_tdcfsj, v_cfsj, v_tdddsj, v_ddsj
                  from yxsj_xd_traintt
                 where instr('-' || d_rec.qcc, '-' || ddcc || '-') > 0
                   and trim(node) = trim(d_rec.jr_zm)
                   and to_char(tdddsj, 'yyyy-mm-dd') =
                       to_char(v_jrrq, 'yyyy-mm-dd')
                   and rownum < 2; /*得到该车次在图定接入日期时，在接入站的图定出发时间、实际出发时间、图定到达时间、实际到达时间、接入ID*/
              exception
                when no_data_found then
                  null;
              end;
              if not v_ddsj is null then
                v_jrflag := 1; /*设置接入标记的值为1，即满足取接入状态的数据*/
                v_jrtd   := v_tdddsj; /*接入图定时间，取图定到达时间*/
                v_jrsj   := v_ddsj; /*接入实际时间，取实际到达时间*/
                v_jrwd   := to_number(trim(to_char((trunc((v_ddsj -
                                                          v_tdddsj) * 24) +
                                                   ((v_ddsj - v_tdddsj) * 24 -
                                                   trunc((v_ddsj -
                                                           v_tdddsj) * 24)) * 60 / 100),
                                                   '999.99')),
                                      '999.99'); /*接入晚点时间，取实际到达时间减去图定到达时间的值*/
              end if;
            end if;

            /*4.2.2 接入站为邻局管辖时，接入取出发时间*/
            v_has1 := 0;
            select count(*)
              into v_has1
              from v_yxsj_ljzdfjk2
             where trim(fjk_name) = trim(d_rec.jr_zm);
            if (v_has1 > 0) then
              /*说明接入站为邻局管辖*/
              v_cfsj := null;
              begin
                select id, tdcfsj, cfsj, tdddsj, ddsj
                  into v_jrid, v_tdcfsj, v_cfsj, v_tdddsj, v_ddsj
                  from yxsj_xd_traintt
                 where instr('-' || d_rec.qcc, '-' || ddcc || '-') > 0
                   and trim(node) = trim(d_rec.jr_zm)
                   and to_char(tdcfsj, 'yyyy-mm-dd') =
                       to_char(v_jrrq, 'yyyy-mm-dd')
                   and rownum < 2; /*得到该车次在图定接入日期时，在接入站的图定出发时间、实际出发时间、图定到达时间、实际到达时间、接入ID*/
              exception
                when no_data_found then
                  null;
              end;
              if not v_cfsj is null then
                v_jrflag := 1; /*设置接入标记的值为1，即满足取接入状态的数据*/
                v_jrtd   := v_tdcfsj; /*接入图定时间，取图定出发时间*/
                v_jrsj   := v_cfsj; /*接入实际时间，取实际出发时间*/
                v_jrwd   := to_number(trim(to_char((trunc((v_cfsj -
                                                          v_tdcfsj) * 24) +
                                                   ((v_cfsj - v_tdcfsj) * 24 -
                                                   trunc((v_cfsj -
                                                           v_tdcfsj) * 24)) * 60 / 100),
                                                   '999.99')),
                                      '999.99'); /*接入晚点时间，取实际出发时间减去图定出发时间的值*/
              end if;
            end if;
          end if;

          /*4.3 开始向YXSJ_LJLCYXMX表插入整条串线后的记录*/
          if (v_jrflag = 1) then
            insert into yxsj_ljlcyxmx
              (lcyxmx_id,
               tbrq,
               lj_jc,
               ljdm,
               lclx,
               lclx_xh,
               cc,
               qcc,
               lj_xh,
               yxfs,
               jr_zm,
               jr_Ts,
               Jc_zm,
               jc_ts,
               sfrq,
               jr_td,
               jr_sj,
               jr_wd,
               jc_td,
               jc_sj,
               jc_wd,
               jr_trainid,
               jc_trainid)
            values
              (SEQ_YXSJ_LJLCYXMX.nextval,
               sysdate,
               d_rec.lj_jc,
               d_rec.ljdm,
               d_rec.lclx,
               d_rec.lclx_xh,
               d_rec.cc,
               d_rec.qcc,
               d_rec.lj_xh,
               d_rec.yxfs,
               d_rec.jr_zm,
               d_rec.jr_ts,
               d_rec.jc_zm,
               d_rec.jc_ts,
               v_sfrq,
               v_jrtd,
               v_jrsj,
               v_jrwd,
               jctd(i),
               jcsj(i),
               jcwd(i),
               v_jrid,
               v_jcid);
          end if;
        end loop;
      end if;
    end if;

    commit;
  end loop;
  close d;

  /*调用另一个存储过程 PRO_YXSJ_LCYXMX_JS，计算增晚和赶点时间，根据列车ID填写调度台，根据站名映射填写显示站名*/
  PRO_YXSJ_LCYXMX_JS;

  /*删除临时表yxsj_xd_traintt里的数据---start*/
  execute immediate 'truncate table yxsj_xd_traintt';
  /*删除临时表yxsj_xd_traintt里的数据---end*/

  /*向表 YXSJ_QSBS_SJ 中填写取数时间---start*/
  insert into YXSJ_QSBS_SJ
  values
    (SEQ_YXSJ_QSBS_SJ.nextval,
     (select lj_jc from yxsj_ljzd_jm),
     (select ljdm from yxsj_ljzd_jm),
     '按列车取数',
     sysdate,
     Trunc(sysdate));
  commit;
  /*向表 YXSJ_QSBS_SJ 中填写取数时间---end*/

  /* 异常处理,提示错误信息*/
exception
  when errormessage then
    dbms_output.put_line('没找到');

end PRO_YXSJ_LCYXMX;
/

