create PROCEDURE "CHECK_CHAOZHOU" (
  p_mlrq in sgml.rq%TYPE,
  p_mlh in sgml.mlh%TYPE,
  cmd_begin in number,
  cmd_end in number,
  p_rtnstring out long,
  v_successful out varchar2) is
  /*定义游标*/
  /*
  '20991231'代表另有通知时至令的终止日期
  */
  cursor c_cgkdl is select distinct rq,mlh,mlxh,qsrq,zzrq,gcz,gczm,cc,sgwz,
                           zy,cs,ls,yt,scz,sczm,zcz,zczm,qtlh,lhwz,fscz,fsczm,dwcz1,
                           dwczm1,dwcz2,dwczm2,grbz,zrxh,action,action_date from sgml
                           where  cc not like '00%' and cc not like 'L%' and cc not like 'A%'and cc not like 'Y%' and ((to_number(mlh)>=cmd_begin and to_number(mlh)<=cmd_end) or (to_number(mlh)>=8201 and to_number(mlh)<=8299))
                                   and to_char(rq,'YYYYMMDD')||mlh||decode(length(to_char(mlxh)),2,to_char(mlxh),0||to_char(mlxh))||decode(length(to_char(zrxh)),2,to_char(zrxh),0||to_char(zrxh)) not in(select distinct to_char(rq,'YYYYMMDD')||mlh||decode(length(to_char(mlxh)),2,to_char(mlxh),0||to_char(mlxh))||decode(length(to_char(zrxh)),2,to_char(zrxh),0||to_char(zrxh)) from sgml where action=-1)
                                   and (
                                   ((rq=p_mlrq and mlh=p_mlh)
                                         --or (
                                         --(to_char(qsrq + 6,'YYYYMMDD') >=to_char(sysdate,'YYYYMMDD')
                                          --and zzrq is null)
                                         --or
                                         --(zzrq is not null
                                         --and to_char(zzrq,'YYYYMMDD')!='20991231'
                                         --and to_number(to_char(zzrq + 8,'YYYYMMDD')) >=to_number(to_char(sysdate,'YYYYMMDD'))
                                         --)
                                         --)
                                             )
                                        or to_char(zzrq,'YYYYMMDD')='20991231'
                                        or (action>0 and to_char(action_date,'YYYYMMDD')=to_char(p_mlrq,'YYYYMMDD'))
                                     )
                                        order by rq,mlh,mlxh,zrxh;
  cursor c_cancel is select distinct rq,mlh,mlxh,zrxh
                   from sgml
                   where ((to_number(mlh)>=cmd_begin and to_number(mlh)<=cmd_end) or (to_number(mlh)>=8201 and to_number(mlh)<=8299))
                        and action=-1 and to_char(action_date,'YYYYMMDD')=to_char(p_mlrq,'YYYYMMDD')
                   order by rq,mlh,mlxh,zrxh;
  /*定义局部变量*/
  vb_grbz boolean;
  vb_yzcd boolean;
  vb_yllh boolean;
  li_cdzs number(2);
  li_jgts number(4);
  ls_fzm varchar2(3);
  ls_hfzm varchar2(20);
  ls_dzm varchar2(3);
  ls_hdzm varchar2(20);
  ls_fcc varchar2(10);
  li_fts number(2);
  li_ini_zs number(2);
  li_max_zs number(2);
  li_zs number(2);
  ls_gcz_no varchar2(3);
  li_gcz_day number(3);
  ls_zdz_no varchar2(3);
  li_zdz_day number(3);
  ls_fcc_fcrq varchar2(8);
  ls_zdz_gczm varchar2(10);
  ls_zdz_gcz_no varchar2(2);
  ls_fcrq varchar2(8);
  ls_fscz_no varchar2(2);
  ls_scz_no varchar2(2);
  vb_rtn_check_result boolean;
  vb_fcc_rtn_check_result boolean;
  ls_ksrq varchar2(8);
  /*返回用字符串*/
  rtnstring long:='';
  /*判断用变量*/
  li_num number(3):=0;
  /*常规命令使用的变量*/
  --
  v_mlrq varchar2(8);
  v_qsrq varchar2(8);
  v_zzrq varchar2(8);
  vv_qsrq varchar2(8);
  v_action_date varchar2(8);
  --
  v_action sgml.action%type;
  v_cgkdl c_cgkdl%rowtype;
  v_mlh sgml.mlh%type;
  v_mlxh sgml.mlxh%type;
  v_gcz sgml.gcz%type;
  v_gczm sgml.gczm%type;
  v_cc sgml.cc%type;
  v_sgwz sgml.sgwz%type;
  v_zy sgml.zy%type;
  v_cs sgml.cs%type;
  v_ls sgml.ls%type;
  v_yt sgml.yt%type;
  v_scz sgml.scz%type;
  v_sczm sgml.sczm%type;
  v_zcz sgml.zcz%type;
  v_zczm sgml.zczm%type;
  v_qtlh sgml.qtlh%type;
  v_lhwz sgml.lhwz%type;
  v_fscz sgml.fscz%type;
  v_fsczm sgml.fsczm%type;
  v_dwcz1 sgml.dwcz1%type;
  v_dwczm1 sgml.dwczm1%type;
  v_dwcz2 sgml.dwcz2%type;
  v_dwczm2 sgml.dwczm2%type;
  v_grbz sgml.grbz%type;
  v_zrxh sgml.zrxh%type;
  v_mlhm varchar2(20);
  --客票八位车次
  v_train_id train_schedule.train_kpid%type;
  --客票八位车次
  --事务成功标志
  b_successful boolean;
  --事务成功标志
  --取消令
  v_cancel c_cancel%rowtype;
  v_cancel_mlrq varchar2(8);
  v_cancel_mlh sgml.mlh%type;
  v_cancel_mlxh sgml.mlxh%type;
  v_cancel_zrxh sgml.zrxh%type;
  --取消令
BEGIN
  p_rtnstring:='';
  b_successful:=true;
  v_successful:='';
  open c_cancel;
  loop
   fetch c_cancel into v_cancel;
   exit when c_cancel%notfound;
   v_cancel_mlrq:=to_char(v_cancel.rq,'YYYYMMDD');
   v_cancel_mlh:=v_cancel.mlh;
   v_cancel_mlxh:=v_cancel.mlxh;
   v_cancel_zrxh:=v_cancel.zrxh;
   delete from k_qdzsb
          where mlrq=v_cancel_mlrq and mlh=v_cancel_mlh and mlxh=v_cancel_mlxh and zrxh=v_cancel_zrxh;
  end loop;
  close c_cancel;
  /*清除当天命令产生的轴位信息*/
  delete from k_qdzsb where mlrq=to_char(p_mlrq,'YYYYMMDD') and mlh=p_mlh;
  commit;
  /*清除当天命令产生的轴位信息*/
  open c_cgkdl;
  loop
    exit when c_cgkdl%notfound;
    fetch c_cgkdl into v_cgkdl;
    /*初始化变量*/
    vb_grbz := false;
    vb_yzcd := false;
    vb_yllh := false;
    li_cdzs := 0;
    li_jgts := 0;
    ls_fzm:='';
    ls_hfzm:='';
    ls_dzm:='';
    ls_hdzm:='';
    ls_fcc:='';
    li_fts:=0;
    li_ini_zs:=0;
    li_max_zs:=0;
    li_zs:=0;
    ls_gcz_no:='';
    li_gcz_day:=0;
    ls_zdz_no :='';
    li_zdz_day:=0;
    ls_fcc_fcrq:='';
    ls_zdz_gczm:='';
    ls_zdz_gcz_no := '';
    ls_fcrq:='';
    ls_fscz_no:='';
    ls_scz_no:='';
    vb_rtn_check_result:=false;
    vb_fcc_rtn_check_result:=false;
    ls_ksrq:='';
    /*初始化变量结束*/
    v_action:=v_cgkdl.action;
    v_action_date:=to_char(v_cgkdl.action_date,'YYYYMMDD');
    v_mlrq:=to_char(v_cgkdl.rq,'YYYYMMDD');
    v_mlh:=v_cgkdl.mlh;
    v_mlxh:=v_cgkdl.mlxh;
     if v_mlh='82058' then
      li_num:=9;
    end if;
    v_qsrq:=to_char(v_cgkdl.qsrq,'YYYYMMDD');
    vv_qsrq:=v_qsrq;
    v_zzrq:=nvl(to_char(v_cgkdl.zzrq,'YYYYMMDD'),to_char(v_cgkdl.qsrq,'YYYYMMDD'));
    v_gcz:=nvl(v_cgkdl.gcz,' ');
    v_gczm:=nvl(v_cgkdl.gczm,' ');
    v_cc:=v_cgkdl.cc;
    v_sgwz:=nvl(v_cgkdl.sgwz,' ');
    v_zy:=nvl(v_cgkdl.zy,' ');
    v_cs:=nvl(v_cgkdl.cs,' ');
    v_ls:=nvl(v_cgkdl.ls,0);
    v_yt:=v_cgkdl.yt;
    v_scz:=nvl(v_cgkdl.scz,' ');
    v_sczm:=nvl(v_cgkdl.sczm,' ');
    v_zcz:=nvl(v_cgkdl.zcz,' ');
    v_zczm:=nvl(v_cgkdl.zczm,' ');
    v_qtlh:=nvl(v_cgkdl.qtlh,' ');
    v_lhwz:=nvl(v_cgkdl.lhwz, ' ');
    v_fscz:=nvl(v_cgkdl.fscz,' ');
    v_fsczm:=nvl(v_cgkdl.fsczm,' ');
    v_dwcz1:=nvl(v_cgkdl.dwcz1,' ');
    v_dwczm1:=nvl(v_cgkdl.dwczm1,' ');
    v_dwcz2:=nvl(v_cgkdl.dwcz2,' ');
    v_dwczm2:=nvl(v_cgkdl.dwczm2,' ');
    v_grbz:=nvl(v_cgkdl.grbz,' ');
    v_zrxh:=v_cgkdl.zrxh;
    /*对用途是存站、充组的命令进行 处理开始（隔日标志为D，表示针对到达车次的命令）*/
    if v_yt = '存站' or v_yt = '充组' then
       goto continue;
    end if;
    /*对用途是存站、充组的命令进行 处理结束（隔日标志为D，表示针对到达车次的命令）*/
    if length(to_char(v_mlxh)) = 1 then
       v_mlhm:=v_mlh||'-0'||to_char(v_mlxh)||'('||substr(v_mlrq,5,2)||')';
    else
       v_mlhm:=v_mlh||'-'||to_char(v_mlxh)||'('||substr(v_mlrq,5,2)||')';
    end if;
    --
    v_train_id := gettrainid(v_cc,vv_qsrq);
    if v_train_id = 'Not1' then
          p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_schedule表中无对应的信息!'||' '||chr(10)||'<br>';
          goto continue;
    elsif v_train_id = 'Not2' then
          p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_schedule表中无对应的信息!'||' '||chr(10)||'<br>';
          goto continue;
    end if;
    --
    --找最新得命令
    select count(*)-1 into li_num from sgml
       where to_char(rq,'YYYYMMDD')=v_mlrq and mlh=v_mlh and mlxh=v_mlxh and zrxh=v_zrxh;
    if li_num>0 then
       if v_action!=li_num then
          --p_rtnstring:=p_rtnstring||v_mlhm||'令'||'action:'||to_char(v_action)||' '||chr(10)||'<br>';
          goto continue;
       end if;
    end if;
    --如不是最新得，不作处理
    if v_zzrq = '20991231' then
       if v_qsrq > to_char(sysdate,'yyyymmdd') then
          v_zzrq := to_char(to_date(v_qsrq,'yyyymmdd') + 8, 'yyyymmdd');
       else
          ls_ksrq:=to_char(sysdate - 3,'YYYYMMDD');
          if to_number(ls_ksrq)>=to_number(v_qsrq) then
             v_qsrq:=ls_ksrq;
          end if;
          v_zzrq := to_char(sysdate + 8, 'yyyymmdd');
       end if;
    end if;
    if v_grbz!=' ' then
       if upper(substr(v_grbz,1,1)) = 'Y' then
          vb_grbz := true;
       elsif upper(substr(v_grbz,1,1)) = 'A' then
          vb_yzcd := true;
       end if;
    end if;
    if vb_yzcd then
       --v_train_id := gettrainid(v_cc,vv_qsrq);
       /*
       if v_train_id = 'Not1' then
          p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_info表中无对应的信息!'||' '||chr(10)||'<br>';
          goto continue;
       elsif v_train_id = 'Not2' then
          p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_info表中无对应的信息!'||' '||chr(10)||'<br>';
          goto continue;
       else
          select nvl(groups,0)-1 into li_cdzs from train_info
             where train_kpid=v_train_id;
       end if;
       */
       select nvl(groups,0)-1 into li_cdzs from train_info
             where train_kpid=v_train_id;
    end if;
    li_jgts := to_date(v_zzrq,'YYYYMMDD')- to_date(v_qsrq,'YYYYMMDD');
    /*删除旧的车次轴位信息*/
    if v_zzrq='20991231' then
       --delete from k_qdzsb where mlrq=v_mlrq and mlh=v_mlh and to_number(mlxh)=v_mlxh and zrxh=v_zrxh
       --                          and to_number(jcrq)>=to_number(v_qsrq);
       delete from k_qdzsb where mlrq=v_mlrq and mlh=v_mlh and to_number(mlxh)=v_mlxh and zrxh=v_zrxh;
    else
       delete from k_qdzsb where mlrq=v_mlrq and mlh=v_mlh and to_number(mlxh)=v_mlxh and zrxh=v_zrxh;
    end if;
    --v_train_id := gettrainid(v_cc,vv_qsrq);
    /*
    if v_train_id = 'Not1' then
       p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_info表中无对应的信息!'||' '||chr(10)||'<br>';
       goto continue;
    elsif v_train_id = 'Not2' then
       p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_info表中无对应的信息!'||' '||chr(10)||'<br>';
       goto continue;
    else
       select begin_sta_code,begin_sta_name,end_sta_code,end_sta_name,back_train_kpid,back_days-1,nvl(begin_axes,0),nvl(most_axes,0),nvl(groups,0) into ls_fzm,ls_hfzm,ls_dzm,ls_hdzm,ls_fcc,li_fts,
              li_ini_zs,li_max_zs,li_zs from train_info
          where train_kpid=v_train_id;
    end if;
    */
    select begin_sta_code,begin_sta_name,end_sta_code,end_sta_name,back_train_kpid,back_days-1,nvl(begin_axes,0),nvl(most_axes,0),nvl(groups,0) into ls_fzm,ls_hfzm,ls_dzm,ls_hdzm,ls_fcc,li_fts,
              li_ini_zs,li_max_zs,li_zs from train_info
          where train_kpid=v_train_id;
    if v_gcz != ' ' then
       if v_zy != ' ' then
          --v_train_id := gettrainid(v_cc,vv_qsrq);
          select count(*) into li_num from train_schedule
             where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(v_gczm));
          if li_num=0 then
             p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次无对应的时刻表!'||' '||chr(10)||'<br>';
             goto continue;
          elsif li_num>1 then
             p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次有一个以上的'||v_gczm||'营业站!'||' '||chr(10)||'<br>';
             goto continue;
          elsif li_num=1 then
             select run_days,sta_sort into li_gcz_day,ls_gcz_no from train_schedule
                where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(v_gczm));
          end if;
          if v_qtlh!=' ' then
             if v_qtlh='原列利回' or v_qtlh='原列空送' or v_qtlh='一往返' or v_qtlh='原列欠车' or v_qtlh='原列充组' then
                select count(*) into li_num from train_schedule
                  where train_kpid=v_train_id and trim(sta_name)=trim(ls_hdzm);
                if li_num=0 then
                  p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次无对应的时刻表!'||' '||chr(10)||'<br>';
                  goto continue;
                elsif li_num>1 then
                  p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次有一个以上的'||ls_hdzm||'营业站!'||' '||chr(10)||'<br>';
                  goto continue;
                elsif li_num=1 then
                  select sta_sort,run_days into ls_zdz_no,li_zdz_day from train_schedule
                   where train_kpid=v_train_id and trim(sta_name)=trim(ls_hdzm);
                end if;
                ls_fcc_fcrq := to_char(to_date(v_qsrq,'YYYYMMDD') + (li_zdz_day - li_gcz_day + li_fts),'YYYYMMDD');
                if v_qtlh='原列利回' or v_qtlh='原列空送' or v_qtlh='原列欠车' or v_qtlh='原列充组'  then
                   if v_fscz!=' ' then
                      ls_zdz_gczm:=v_fsczm;
                   end if;
                end if;--v_qtlh='' or v_qtlh=''
                if v_qtlh='一往返' then
                   ls_zdz_gczm:= v_gczm;
                end if;
                select count(*) into li_num from train_schedule
                  where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(ls_zdz_gczm));
                if li_num=0 then
                  p_rtnstring:=p_rtnstring||v_mlhm||'令'||gettraincode(ls_fcc)||'次无对应的时刻表!'||' '||chr(10)||'<br>';
                  goto continue;
               elsif li_num>1 then
                  p_rtnstring:=p_rtnstring||v_mlhm||'令'||gettraincode(ls_fcc)||'次中有一个以上的'||ls_zdz_gczm||'营业站!'||' '||chr(10)||'<br>';
                  goto continue;
               elsif li_num=1 then
                  select sta_sort into ls_zdz_gcz_no from train_schedule
                     where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(ls_zdz_gczm));
               end if;
             end if;--v_qtlh='' or v_qtlh='' or v_qtlh=''
          end if;--v_qtlh!=' '
          ls_fcrq := to_char(to_date(v_qsrq,'YYYYMMDD') - li_gcz_day,'YYYYMMDD');
          if v_zy='挂' then
             if v_scz != ' ' then
                if v_qtlh!=' ' then
                   if v_qtlh='原列利回' or v_qtlh='原列空送' or v_qtlh='原列欠车' or v_qtlh='原列充组'  then
                      if trim(v_scz)=trim(ls_dzm) then
                         vb_yllh:=true;
                         if v_fscz != ' ' then
                            select count(*) into li_num from train_schedule
                              where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(v_fsczm));
                            if li_num=0 then
                               p_rtnstring:=p_rtnstring||v_mlhm||'令'||gettraincode(ls_fcc)||'次无对应的时刻表!'||' '||chr(10)||'<br>';
                               goto continue;
                            elsif li_num>1 then
                               p_rtnstring:=p_rtnstring||v_mlhm||'令'||gettraincode(ls_fcc)||'次中有一个以上的'||v_fsczm||'营业站!'||' '||chr(10)||'<br>';
                               goto continue;
                            elsif li_num=1 then
                               select sta_sort into ls_fscz_no from train_schedule
                                 where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(v_fsczm));
                            end if;
                         else
                            p_rtnstring:=p_rtnstring||v_mlhm||'号原列利回(空送)令返甩车站为空!无法检查!'||chr(10)||'<br>';
                            goto continue;
                         end if;
                      else
                         p_rtnstring:=p_rtnstring||v_mlhm||'号原列利回(空送)令甩车站'||v_sczm||'不是终点站!'||chr(10)||'<br>';
                         goto continue;
                      end if;
                   end if;--v_qtlh='' or v_qtlh=''
                end if;--v_qtlh!=' '
                if vb_yllh then
                   rtnstring:='';
                   vb_rtn_check_result:=check_result(ls_fcrq,v_train_id,ls_gcz_no,ls_zdz_no,v_mlrq,v_mlh,
                                                     v_mlxh,v_zrxh,li_ini_zs,li_max_zs,li_jgts,
                                                     vb_grbz,vb_yzcd,li_cdzs,v_qsrq,v_action,v_action_date,rtnstring);
                   p_rtnstring:=p_rtnstring||rtnstring;
                   if not(vb_rtn_check_result) then
                      goto continue;
                   end if;
                   rtnstring:='';
                   vb_fcc_rtn_check_result:=check_result(ls_fcc_fcrq,ls_fcc,'01',ls_fscz_no,v_mlrq,v_mlh,
                                                     to_char(v_mlxh),v_zrxh,li_ini_zs,li_max_zs,
                                                     li_jgts,vb_grbz,vb_yzcd,li_cdzs,v_qsrq,v_action,v_action_date,rtnstring);
                   p_rtnstring:=p_rtnstring||rtnstring;
                   if not(vb_fcc_rtn_check_result) then
                      goto continue;
                   end if;
                else
                   select count(*) into li_num from train_schedule
                    where train_kpid=v_train_id and trim(sta_name)=trim(v_sczm);
                   if li_num=0 then
                      p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次无对应的时刻表!'||' '||chr(10)||'<br>';
                      goto continue;
                   elsif li_num>1 then
                      p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次中有一个以上的'||v_sczm||'营业站!'||' '||chr(10)||'<br>';
                      goto continue;
                   elsif li_num=1 then
                      select sta_sort into ls_scz_no from train_schedule
                       where train_kpid=v_train_id and trim(sta_name)=trim(v_sczm);
                   end if;
                   rtnstring:='';
                   vb_rtn_check_result:=check_result(ls_fcrq,v_train_id,ls_gcz_no,ls_scz_no,v_mlrq,v_mlh,
                                                     to_char(v_mlxh),v_zrxh,li_ini_zs,li_max_zs,
                                                     li_jgts,vb_grbz,vb_yzcd,li_cdzs,v_qsrq,v_action,v_action_date,rtnstring);
                   p_rtnstring:=p_rtnstring||rtnstring;
                   if not(vb_rtn_check_result) then
                      goto continue;
                   end if;
                end if;--vb_yllh
             end if;--v_scz!=' '
             if v_qtlh!=' ' and v_qtlh='一往返' then
                rtnstring:='';
                vb_rtn_check_result:=check_result(ls_fcrq,v_train_id,ls_gcz_no,ls_zdz_no,v_mlrq,v_mlh,
                                                     to_char(v_mlxh),v_zrxh,li_ini_zs,li_max_zs,
                                                     li_jgts,vb_grbz,vb_yzcd,li_cdzs,v_qsrq,v_action,v_action_date,rtnstring);
                p_rtnstring:=p_rtnstring||rtnstring;
                if not(vb_rtn_check_result) then
                   goto continue;
                end if;
                rtnstring:='';
                vb_fcc_rtn_check_result:=check_result(ls_fcc_fcrq,ls_fcc,'01',ls_zdz_gcz_no,v_mlrq,v_mlh,
                                                     to_char(v_mlxh),v_zrxh,li_ini_zs,li_max_zs,
                                                     li_jgts,vb_grbz,vb_yzcd,li_cdzs,v_qsrq,v_action,v_action_date,rtnstring);
                p_rtnstring:=p_rtnstring||rtnstring;
                if not(vb_fcc_rtn_check_result) then
                   goto continue;
                end if;
             end if;--v_qtlh!=' ' and v_qtlh=''
          end if;--v_zy='挂'
          if v_zy='甩' then
             if v_scz!=' ' then
                select count(*) into li_num from train_schedule
                    where train_kpid=v_train_id and trim(sta_name)=trim(v_sczm);
                   if li_num=0 then
                      p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次无对应的时刻表!'||' '||chr(10)||'<br>';
                      goto continue;
                   elsif li_num>1 then
                      p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次中有一个以上的'||v_sczm||'营业站!'||' '||chr(10)||'<br>';
                      goto continue;
                   elsif li_num=1 then
                      select sta_sort into ls_scz_no from train_schedule
                       where train_kpid=v_train_id and trim(sta_name)=trim(v_sczm);
                   end if;
                rtnstring:='';
                vb_rtn_check_result:=check_result(ls_fcrq,v_train_id,ls_gcz_no,ls_scz_no,v_mlrq,v_mlh,
                                                     to_char(v_mlxh),v_zrxh,li_ini_zs,li_max_zs,
                                                     li_jgts,vb_grbz,vb_yzcd,li_cdzs,v_qsrq,v_action,v_action_date,rtnstring);
                p_rtnstring:=p_rtnstring||rtnstring;
                if not(vb_rtn_check_result) then
                   goto continue;
                end if;
             end if;--v_scz!=' '
             if v_qtlh!=' ' then
                if v_qtlh='原列利回' or v_qtlh='原列空送' or v_qtlh='原列欠车' or v_qtlh='原列充组'  then
                   rtnstring:='';
                   vb_fcc_rtn_check_result:=check_result(ls_fcc_fcrq,ls_fcc,'01',ls_zdz_gcz_no,v_mlrq,v_mlh,
                                                        to_char(v_mlxh),v_zrxh,li_ini_zs,li_max_zs,
                                                        li_jgts,vb_grbz,vb_yzcd,li_cdzs,v_qsrq,v_action,v_action_date,rtnstring);
                   p_rtnstring:=p_rtnstring||rtnstring;
                   if not(vb_fcc_rtn_check_result) then
                      goto continue;
                   end if;
                end if;--
             end if;--v_qtlh!=' '
             if v_qtlh!=' ' and v_qtlh='一往返' then
                rtnstring:='';
                vb_rtn_check_result:=check_result(ls_fcrq,v_train_id,ls_gcz_no,ls_zdz_no,v_mlrq,v_mlh,
                                                     to_char(v_mlxh),v_zrxh,li_ini_zs,li_max_zs,
                                                     li_jgts,vb_grbz,vb_yzcd,li_cdzs,v_qsrq,v_action,v_action_date,rtnstring);
                p_rtnstring:=p_rtnstring||rtnstring;
                if not(vb_rtn_check_result) then
                   goto continue;
                end if;
                rtnstring:='';
                vb_fcc_rtn_check_result:=check_result(ls_fcc_fcrq,ls_fcc,'01',ls_zdz_gcz_no,v_mlrq,v_mlh,
                                                     to_char(v_mlxh),v_zrxh,li_ini_zs,li_max_zs,
                                                     li_jgts,vb_grbz,vb_yzcd,li_cdzs,v_qsrq,v_action,v_action_date,rtnstring);
                p_rtnstring:=p_rtnstring||rtnstring;
                if not(vb_fcc_rtn_check_result) then
                   goto continue;
                end if;
             end if;
          end if;--v_zy='甩'
       else
          p_rtnstring:=p_rtnstring||v_mlhm||'令作业不能为空!'||chr(10)||'<br>';
          goto continue;
       end if;--v_zy!=' '
    end if;--v_gcz!=' '
    --p_rtnstring:=p_rtnstring||'令：'||v_mlhm||'！'||chr(10);
    <<continue>>
    li_num:=0;--废语句
  end loop;
  <<break>>
  close c_cgkdl;
  if b_successful then
     p_rtnstring:=p_rtnstring||'超轴检查结束！'||chr(10)||'<br>';
     v_successful:='true';
     commit;
  else
     p_rtnstring:=p_rtnstring||'超轴检查失败！'||chr(10)||'<br>';
     v_successful:='false';
     rollback;
  end if;
  /*exception
    when others then
      p_rtnstring:=p_rtnstring||v_mlhm||'号命令'||v_cc||'次'||' have errors!'||chr(10);*/
END check_chaozhou;
/

