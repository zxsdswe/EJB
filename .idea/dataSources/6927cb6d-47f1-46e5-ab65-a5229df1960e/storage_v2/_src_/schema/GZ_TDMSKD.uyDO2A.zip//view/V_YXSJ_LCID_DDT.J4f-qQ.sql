create view V_YXSJ_LCID_DDT as
  select id,ddt,tm
  from xd_trainline,xd_ddt
   where xd_trainline.ddt=xd_ddt.dm
/

