create FUNCTION TRAIN_COPY1 return boolean Is
  train_id_local Number;
  Result boolean;
Begin
--2009年1月3日 陈历泉
Begin
for c in (select train_id,plan from train_copy)  loop
  select train_id_s.NEXTVAL  Into train_id_local from dual;
Insert Into train_info 
SELECT train_id_local, a.train_kpid, a.train_no, a.train_code,
       a.subbureau_code, a.run_cycle, a.run_rule, a.begin_sta_code,
       a.begin_sta_name, a.end_sta_code, a.end_sta_name,
       a.back_train_kpid, a.back_train_no, a.back_days, a.pass_burs,
       a.pass_subburs, a.begin_axes, a.most_axes, a.groups, c.plan,
       a.base_id, a.route_id, a.start_date, a.stop_date, a.train_type,
       a.note
  FROM train_info a where train_id=c.train_id;

Insert Into train_schedule  
SELECT a.start_date, a.stop_date, train_id_local, a.train_kpid, a.train_no,
       a.sta_sort, a.sta_name, a.sta_code, a.subbur_code, a.bureau_code,
       a.arrive_time, a.start_time, a.arrive_train, a.start_train,
       a.sta_type, a.sta_type2, a.run_days
  FROM train_schedule a  Where a.train_id=c.train_id;
  commit;
end loop;
Result:=True;
EXCEPTION
  WHEN OTHERS THEN 
  rollback;
  COMMIT;
  Result:=False;
End;
  return(Result);
end train_copy1;
/

