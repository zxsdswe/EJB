create PACKAGE COPY_DATA
  IS
   procedure  copy_hk(kyfa_name varchar2,jbt_id  number) ;
   FUNCTION UPDATE_STA(kyfa_name varchar2)     RETURN BOOLEAN;
   FUNCTION GET_STATION (v_train_id NUMBER, v_sta_sort NUMBER)
   RETURN VARCHAR2;
   procedure  copy_sk(kyfa_src varchar2,kyfa_tar varchar2) ;

END; -- Package spec
/

