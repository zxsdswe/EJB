create view V_YXSJ_LJZDFJK2 as
  select "FJK_ID","FJK_NAME","FJK_XH","LJ","SSLJ"
    from yxsj_ljzd_fjk
   where lj!=sslj
/

