create package set_continuous is

  -- Author  : ADMINISTRATOR
  -- Created : 2015-02-05 09:45:27
  -- Purpose : 
  
  -- Public function and procedure declarations
  function mainrun (cc0 In  Varchar2,cc1 In  Varchar2) return integer;--
  Procedure set_ids(cc0 In Varchar2,cc1 In  Varchar2) ;

end set_continuous;
/

