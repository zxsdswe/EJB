create FUNCTION "GETTRAINID" (p_sta_train_id
    in train_schedule.start_train%TYPE,p_qsrq in varchar2) return
    varchar2 is
  Result varchar2(8);
  cursor c_schedule is select distinct a.train_kpid,a.train_id from (select train_kpid,train_id,row_number() over(order by train_id desc) rn from train_info where train_kpid not Like '*%' And p_qsrq between start_date and stop_date and (train_no = p_sta_train_id or ltrim(substr(train_kpid,3,4),'0') = nvl(substr(p_sta_train_id,1,instr(p_sta_train_id,'/') - 1),p_sta_train_id) or concat(substr(train_no,0,instr(train_no,'/')-1-length(substr(train_no,instr(train_no,'/',-1)+1))),substr(train_no,instr(train_no,'/',-1)+1)) = p_sta_train_id )) a where a.rn<3 order by a.train_id desc;
  v_l_train_id train_schedule.train_id%TYPE;
  v_train_id train_schedule.train_kpid%TYPE;
  v_subbureau_code train_info.subbureau_code%type;
  v_count number(10);
  v_run_cycle train_info.run_cycle%type;
  v_start_date train_info.start_date%type;
  v_run_rule train_info.run_rule%type;
  v_min_jgts number(2);
begin
  open c_schedule;
  result := 'Not1';
  loop
    fetch c_schedule into v_train_id,v_l_train_id;
    exit when c_schedule%notfound;
    result := 'Not2';
    select start_date,run_cycle,run_rule into v_start_date,v_run_cycle,v_run_rule from train_info
      where train_kpid=v_train_id;
    v_min_jgts:= mod(abs(to_date(p_qsrq,'YYYYMMDD')-to_date(v_start_date,'YYYYMMDD')),v_run_cycle);
    v_count := bitand(v_run_rule,power(2,v_min_jgts));
    if v_count!=0 then
      result:=v_train_id;
       goto break;
    end if;
  end loop;
  <<break>>
  close c_schedule;
  return(trim(Result));
  exception
  When others then
     return(trim(Result));
end GetTrainId;
/

