create function backup_common_data
(cmdBackupPointDate in varchar2)
return boolean
is
begin
--
delete from users_log where log_time<(sysdate-(30*3));
commit;
--广局以外不适用
delete from dic_takeon_corp;
insert into dic_takeon_corp(corp_code,corp_name)
  select bureau_code,bureau_name from b_bureau
    union select bureau_code||subbureau_code,subbureau_short_name from b_subbureau where bureau_code='Q' and subbureau_code not in ('60','62','63','64')
    union select takeon_corp_code,takeon_corp_shortname from lk_takeon_corp;
commit;
--微机室统计用数据链路无效导致dds_lk_rbjh无效
--delete from dds_lk_rbjh where rq>=to_char(sysdate,'yyyymmdd');
--insert into dds_lk_rbjh(rq,zm,jrlk,jclk)
--  select rq,zm,nvl(jr1b,0)+nvl(jr2b,0),nvl(jc1b,0)+nvl(jc2b,0) from count_ljklktj where rq>=to_char(sysdate,'yyyymmdd')
--    and zm in (select zm from dic_ljkb where instr(flag,'3')>0 or zm in ('株洲'));
--commit;
--
delete from cmd_head where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from cmd_tran where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
--
delete from cmd_cancle where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from cmd_other where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from cmd_change where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
----
delete from cmd_changelogs where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from cmd_log where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
--
delete from sgml where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
delete from sgcl where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
delete from sgcl_change where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
delete from cmd_combine where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
----
delete from cmd_sgml where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
delete from cmd_sgml_content where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
delete from cmd_sgcl where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
delete from sgcl_changed where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
delete from sgcl_claim where claim_id in (select claim_id from sgml_claim where to_char(rq,'yyyymmdd')<cmdBackupPointDate);
delete from sgml_changed where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
delete from sgml_claim where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
delete from sgml_claim_head where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
delete from sgml_lz_sign where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
delete from sgml_other_claim where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
delete from sg_action where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
delete from claim_sign where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
----
delete from cmd_combine_claim where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
--
delete from crh_cmd where cmd_date<cmdBackupPointDate;
delete from Add_lkcmd where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from stop_lkcmd where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from change_compile where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from change_details where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from nowcmd_lktrain_dir where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from lkcmd_schedule where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from lkcmd_compile where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from change_lkcmd_schedule where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from lkcmd_track where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
--
delete from Map_Stop where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from Map_Resume where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from Map_Change where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
--
delete from return_cmd where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from bypass_cmd where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
--
delete from cmd_ticket where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from ticket_distribute where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
--
delete from cmd_fjxb where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
delete from cmd_ljxb where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
--
delete from react_add_lkcmd where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from react_bypass_cmd where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from react_cmd_change where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from react_return_cmd where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from react_stop_lkcmd where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
--
delete from sjbm_cmd_head where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from sjbm_cmd_tran where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from sjbm_cmd_cancle where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from sjbm_cmd_other where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from sjbm_cmd_change where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
----
delete from sjbm_sgml where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
delete from sjbm_sgcl where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
delete from sjbm_cmd_combine where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
----
delete from sjbm_add_lkcmd where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from sjbm_stop_lkcmd where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from sjbm_change_compile where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from sjbm_lkcmd_schedule where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from sjbm_lkcmd_compile where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from sjbm_change_lkcmd_schedule where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
----
delete from sjbm_map_stop where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from sjbm_map_resume where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from sjbm_map_change where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
----
delete from sjbm_return_cmd where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from sjbm_bypass_cmd where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
----
delete from sjbm_cmd_ticket where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
delete from sjbm_ticket_distribute where to_char(cmd_date,'yyyymmdd')<cmdBackupPointDate;
----
delete from sjbm_cmd_ljxb where to_char(rq,'yyyymmdd')<cmdBackupPointDate;
commit;
--
return true;
end backup_common_data;


/

