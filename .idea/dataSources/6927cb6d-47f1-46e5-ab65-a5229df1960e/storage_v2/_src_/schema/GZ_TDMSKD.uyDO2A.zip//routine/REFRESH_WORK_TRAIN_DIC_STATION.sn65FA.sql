create PROCEDURE        "REFRESH_WORK_TRAIN_DIC_STATION" AS
BEGIN
  delete from work_train_begin_end_station;
  insert into work_train_begin_end_station(train_id,train_no,train_code,sta_name,sta_sort,ARRIVE_TIME,START_TIME)
  select a.train_id,a.train_no,a.train_code,b.sta_name,b.sta_sort,b.ARRIVE_TIME,b.START_TIME from train_info a,train_schedule b
  --where a.plan in ('07-113图客') and a.train_id=b.train_id and
  where a.train_id in (select train_id from run_line where run_date>=to_char(sysdate-3,'yyyymmdd')) and a.train_id=b.train_id and
  (b.sta_sort=(select min(c.sta_sort) from train_schedule c where a.train_id=c.train_id)
  or b.sta_sort=(select max(c.sta_sort) from train_schedule c where a.train_id=c.train_id))
  order by a.train_id,b.sta_sort;
  commit;
--
  delete from work_train_begin_end_small;
  insert into work_train_begin_end_small(train_id,train_no,train_code,beg_sta_name,end_sta_name)
  select a.train_id,a.train_no,a.train_code,a.sta_name,b.sta_name from work_train_begin_end_station a,work_train_begin_end_station b
  where a.train_id=b.train_id and a.sta_sort<b.sta_sort order by a.train_id;
  commit;
--
  delete from work_train_in_out_station;
  insert into work_train_in_out_station(train_id,train_no,train_code,sta_name,sta_sort,ARRIVE_TIME,START_TIME)
  select a.train_id,a.train_no,a.train_code,b.sta_name,b.sta_sort,b.ARRIVE_TIME,b.START_TIME from train_info a,train_schedule b
  --where a.plan in ('07-113图客') and a.train_id=b.train_id and
  where a.train_id in (select train_id from run_line where run_date>=to_char(sysdate-3,'yyyymmdd')) and a.train_id=b.train_id and
  b.sta_sort=(select min(c.sta_sort) from train_schedule c where a.train_id=c.train_id and instr(c.sta_type,'4')>0)
  order by a.train_id,b.sta_sort;
  insert into work_train_in_out_station(train_id,train_no,train_code,sta_name,sta_sort,ARRIVE_TIME,START_TIME)
  select a.train_id,a.train_no,a.train_code,b.sta_name,b.sta_sort+1,b.ARRIVE_TIME,b.START_TIME from train_info a,train_schedule b
  --where a.plan in ('07-113图客') and a.train_id=b.train_id and
  where a.train_id in (select train_id from run_line where run_date>=to_char(sysdate-3,'yyyymmdd')) and a.train_id=b.train_id and
  b.sta_sort=(select max(c.sta_sort) from train_schedule c where a.train_id=c.train_id and instr(c.sta_type,'4')>0)
  order by a.train_id,b.sta_sort;
  commit;
--
  delete from work_train_in_out_small;
  insert into work_train_in_out_small(train_id,train_no,train_code,in_sta_name,out_sta_name)
  select a.train_id,a.train_no,a.train_code,a.sta_name,b.sta_name from work_train_in_out_station a,work_train_in_out_station b
  where a.train_id=b.train_id and a.sta_sort<b.sta_sort order by a.train_id;
  commit;
--
  delete from work_train_dic_station;
  insert into work_train_dic_station(train_id,train_no,train_code,beg_sta_name,end_sta_name)
  select a.train_id,a.train_no,a.train_code,a.beg_sta_name,a.end_sta_name from work_train_begin_end_small a order by a.train_id;
  update work_train_dic_station a set a.in_sta_name=(select b.in_sta_name from work_train_in_out_small b where a.train_id=b.train_id),
   a.out_sta_name=(select b.out_sta_name from work_train_in_out_small b where a.train_id=b.train_id)
   where a.train_id=(select b.train_id from work_train_in_out_small b where a.train_id=b.train_id);
  commit;
--
END;
/

