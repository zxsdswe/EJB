create FUNCTION SPLIT_CC
  ( CC IN VARCHAR2 )
  RETURN  varchar2 IS 

 trains varchar2(255);
 str1 varchar2(255);
 headStr varchar2(255);
 indexin number(2);
 tempCc varchar2(255);
BEGIN 
    indexin := INSTR(CC,'/',1,1);
    if indexin > 0 then
        headStr := substr(cc, 1,indexin - 1);
        if INSTR(CC, '/', indexin + 1, 1) < 1 then
            str1 := substr(cc, indexin + 1, length(CC));
            headStr := substr(cc, 1, length(headStr) - length(str1));
        else
            str1 := substr(cc, indexin + 1, INSTR(CC, '/', indexin + 1, 1) - indexin - 1);
            headStr := substr(cc, 1, length(headStr) - length(str1));
        end if;
        tempCc := subStr(CC, length(headStr) + 1);
        indexin := 0;
        str1 := '';
        loop
            if INSTR(tempCc, '/', indexin + 1, 1) <= 0 then 
                str1 := substr(tempCc, indexin + 1, length(tempCc));
                str1 := concat(headStr, str1);
            else
                str1 := substr(tempCc, indexin + 1, INSTR(tempCc, '/', indexin + 1, 1) - indexin - 1);
                str1 := concat(headStr, str1);
            end if;
            trains := concat(trains,str1||'、');
            indexin := INSTR(tempCc,'/',indexin + 1,1);
            exit when indexin = 0;
        end loop;
    end if;

    RETURN trains   ;
END;
/

