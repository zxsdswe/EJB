create procedure sunday_rbjh_fjk(dnum  in number) is
rqstr    varchar2(8);
runid    number(10);
zmid     number(10);
rid      number(10);
id       number(10);
qid      number(10);
sfddid   number(10);
hkid     number(10);
bid      varchar2(10);
hid      varchar2(10);
sfbz     varchar2(10);
runcc    varchar2(16);
lcc      varchar2(5);
tjn      varchar2(16);
zm       varchar2(16);
gsj      varchar2(16);
grq      varchar2(16);
hrq      varchar2(20);
str_sfz  varchar2(20);
str_dzd  varchar2(20);
sta_sj   varchar2(20);
end_sj   varchar2(20);
sta_d    varchar2(20);
end_d    varchar2(20);
nfjkz    varchar2(20);
yzzm     varchar2(20);
qcc      varchar2(16);
ii       number(5);
DAY1     varchar2(16);
DAY2     varchar2(16);
yzid     number(4);
pxh      number(4);
tkid     number(5);
kct1     number(5);
kcl1     number(5);
kch1    number(5);
kct2    number(5);
kcl2    number(5);
kch2    number(5);
kct3    number(5);
kcl3    number(5);
kch3    number(5);
kct4    number(5);
kcl4    number(5);
kch4    number(5);
kct5    number(5);
kcl5    number(5);
kch5    number(5);
wno     varchar2(16);
lc      number(5);
lklx    varchar2(10);
lkcc    varchar2(16);
trainkind varchar2(20);
cclong  number(5);
fid     number(5);
ccline  varchar2(16);
-------dbms-jobs--134
------读出发车次
--CURSOR read_run_line IS
--SELECT  runline_id,cc,sfz,zdz
--    FROM run_line a, run_point b
--   WHERE a.ID = b.runline_id
--     AND TRUNC (TO_DATE (go_date || go_time, 'yyyymmddhh24mi') + 0.25 - 1 / 1440) = TRUNC (SYSDATE +dnum)
--     AND b.xh = 1
--     AND (cc NOT LIKE '0%')  AND (cc NOT LIKE 'X%') AND (cc NOT LIKE 'DJ%')
--     AND (cc NOT LIKE '8%')  AND (STOPFLAg = 1)
 --    and station_name in (select station_name from b_station where bureau_code='Q')  ORDER BY cc  ; 
CURSOR read_run_line IS
SELECT  id,cc,sfz,zdz,train_kind    FROM run_line 
   WHERE id in (select  runline_id from run_point where go_date||go_time>sta_sj and  go_date||go_time <= end_sj 
        and station_name in (select station_name from b_station where bureau_code='Q' and station_name<>'九龙')  and xh=1 )
       AND (cc NOT LIKE 'X%')  AND (cc NOT LIKE '57%') and (cc NOT LIKE '55%')  and (cc NOT LIKE 'C68%') AND (cc NOT LIKE '0D%') AND (cc NOT LIKE '011%')  AND (cc NOT LIKE 'G%') AND (cc NOT LIKE '0G%')
     AND (cc NOT LIKE '8%')  AND (STOPFLAg = 1) and nvl(multipro_flag,'dgz')<>'H'; 
------读终到车次
CURSOR read_run_line_zd IS
SELECT  id,cc,sfz,zdz,train_kind    FROM run_line 
   WHERE  id in (select  runline_id from run_point where arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj 
        and station_name in (select station_name from b_station where bureau_code='Q')  and arr_time<>'-100')
        AND (cc NOT LIKE 'X%')   AND (cc NOT LIKE '57%') and (cc NOT LIKE '55%') and (cc NOT LIKE 'C68%') AND (cc NOT LIKE '0D%')  AND (cc NOT LIKE '011%') AND (cc NOT LIKE 'G%') AND (cc NOT LIKE '0G%')
        AND (cc NOT LIKE '8%')  AND (STOPFLAg = 1)  and nvl(multipro_flag,'dgz')<>'H'; 
-------读分界口车次数据
CURSOR read_run_point_fjk IS
SELECT  runline_id,station_name,arr_date||arr_time,go_date||go_time,xh    FROM run_point 
   WHERE  runline_id in (select  id from run_line where STOPFLAG = 1 
           AND cc NOT LIKE 'X%'   AND cc NOT LIKE '8%' and cc not like '5701%'  and nvl(multipro_flag,'d')<>'H'  and cc not like '5710%')
   and ((arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj) or 
        (go_date||go_time>sta_sj and  go_date||go_time <= end_sj))   
   and station_name in ( '蒲圻','西斋','秀山','大龙','牙屯堡','滩头湾','定南','茂名西','琥市','塘口','楠木塘','永州','珠玑巷','睦村','灯芯桥','黔江渝怀场') ; 
   
 ------读深圳口车次数据
CURSOR read_run_point_sz IS
SELECT  runline_id,station_name,arr_date||arr_time,go_date||go_time,xh    FROM run_point 
   WHERE  runline_id in (select  id from run_line where STOPFLAG = 1 
           AND cc NOT LIKE 'X%' AND cc NOT LIKE '%D%'   AND cc NOT LIKE '8%')
   and arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj  and arr_time<>'-100' 
   and station_name in ( '深圳') ;
   
   
 ------读丝茅冲车次数据
CURSOR read_run_point_skq IS
SELECT  runline_id,station_name,arr_date||arr_time,go_date||go_time,xh    FROM run_point 
   WHERE  runline_id in (select  id from run_line where STOPFLAG = 1 
           AND cc NOT LIKE 'X%'    AND cc NOT LIKE '8%'  and nvl(multipro_flag,'d')<>'H')
   and arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj  and arr_time<>'-100' 
   and station_name in ( '丝茅冲')   ;    
   
-------读分界口车次数据_株洲口
CURSOR read_run_point_zzk IS
SELECT  runline_id,station_name,arr_date||arr_time,go_date||go_time,xh    FROM run_point 
  WHERE  runline_id in (select  id from run_line where STOPFLAG = 1 
          AND  cc NOT LIKE 'X%' AND cc NOT LIKE '%DJ%'   AND cc NOT LIKE '8%' and nvl(multipro_flag,'d')<>'H')
   and ((arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj) or 
       (go_date||go_time>sta_sj and  go_date||go_time <= end_sj)) and arr_time<>'-100'   
   and station_name in ( '株洲') ; 
-------读坪石口车次数据
CURSOR read_run_point_psk IS
SELECT  runline_id,station_name,arr_date||arr_time,go_date||go_time,xh    FROM run_point 
   WHERE  runline_id in (select  id from run_line where STOPFLAG = 1 
          AND  cc NOT LIKE 'X%' AND cc NOT LIKE '%DJ%'   AND cc NOT LIKE '8%' and  cc NOT LIKE '576%' and nvl(multipro_flag,'d')<>'H') 
   and ((arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj) or 
        (go_date||go_time>sta_sj and  go_date||go_time <= end_sj))  and arr_time<>'-100' 
   and (station_name ='坪石北' ) ; 
-----读出发车次分析数据----
CURSOR read_dds_start_kc_data IS
SELECT  distinct(station)    FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz order by station; 
--------过程开始
begin
    select to_char(sysdate + dnum,'yyyymmdd') into rqstr  from dual;
    select to_char(sysdate + dnum -1,'yyyymmdd') into sta_sj  from dual;
--    rqstr :='20150206';
--    sta_sj:='20150205';


    DAY1   :=sta_sj;
    DAY2   :=rqstr;
    sta_d  :=sta_sj;
    end_d  :=end_sj;
    sta_sj :=sta_sj||'1800';
    end_sj :=rqstr||'1800'; 
    delete from dds_start_kc_data where rq = rqstr;
    delete from dds_start_kc_tj where rq = rqstr;
    delete from dds_start_kc_tj_zlw where rq = rqstr;
    commit;
    
    rid := 0;
  OPEN read_run_line;
       LOOP
       FETCH read_run_line INTO runid,runcc,str_sfz,str_dzd,trainkind;
       EXIT WHEN read_run_line%NOTFOUND;
 ---      select count(*) into id  from run_line where cc=rqstr;
       if runcc='K6639' then 
           runcc:=runcc;
       end if;
       select station_name,go_date,go_time into zm,grq,gsj  from run_point where runline_id=runid and xh=1;
       hrq:=grq||gsj;
       rid := rid + 1;
       lcc := substr(runcc,1,1);
       select count(*) into sfddid from dds_start_kc_data_qj where (end_station = zm AND start_station=str_dzd) or (end_station = str_dzd AND start_station=zm);
        if (sfddid>0 and lcc ='0') or runcc ='57001' or runcc ='57002'  THEN 
           str_dzd:='不写';
        ELSE
-------2011-01-11增加       
          lkcc:=substr(runcc,1,1);
          lklx:='图客';
          if lkcc ='A' or lkcc= '0' or lkcc = 'L' or lkcc = 'Y' then
           lklx:='临客';
           end if;
            fid :=INSTR(runcc,'/',1,1);
            ccline:=runcc;
           if fid> 0 then
              ccline:=substr(runcc,1,fid - 1); 
           end if;
           cclong:=length(ccline);
           if cclong>= 5  then  
              lkcc:=ccline;
              if  (lkcc >='Z4001' and lkcc<='Z4998') or (lkcc >='Z9001' and lkcc<='Z9998') or (lkcc >='D9001' and lkcc<='D9998') or (lkcc >='T3001' and lkcc<='T3998')  or (lkcc >'T4001' and lkcc<='T4998') or (lkcc >'K4001' and lkcc<='K4998') or (lkcc >'K5001' and lkcc<='K6998') or (lkcc >'C9000' and lkcc<='C9998') then
                   lklx:='临客';
              end if;
           end if;
 -------2015-01-01增加 
             qcc:=runcc;
           if fid > 0 then 
              qcc:=substr(runcc,1,fid - 1);
           end if;
           if qcc >='3001' and qcc<='3998' and length(qcc)=4 then 
              lklx:='临客';
           end if;
           fid :=INSTR(trainkind,'LK',1,1);
           if fid > 0 then 
                 lklx:='临客';
            end if;
           
 -------2011-01-11增加 
           if (zm ='三亚' and  (str_dzd='海口东' or str_dzd='海口')) or (zm='海口' and str_dzd='三亚')  or 
                   (zm='三亚' and str_dzd='三亚') or  str_dzd='永州东' or zm='永州东'  
                   or  (str_dzd='笋岗' and  zm='深圳') or (str_dzd='深圳' and  zm='笋岗') 
                   or   (str_dzd='笋岗' and  zm='深圳东') or (str_dzd='深圳东' and  zm='笋岗') or zm='霞凝'  or str_dzd='霞凝'  then 
 ----广珠线不写库
            
            fid:=0;
           else       
           insert into dds_start_kc_data(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,'始发',rid,runid,zm,runcc,hrq,zm,str_dzd,lklx,trainkind);
           end if;
         END IF;
      commit;
      end loop;
      CLOSE read_run_line;
 -------终到数据统计-------  
 rid := 0;   
OPEN read_run_line_zd;
       LOOP
       FETCH read_run_line_zd INTO runid,runcc,str_sfz,str_dzd,trainkind;
       EXIT WHEN read_run_line_zd%NOTFOUND;
        select station_name,arr_date,arr_time into zm,grq,gsj  from run_point where runline_id=runid and xh in (
        select max(xh) from run_point where runline_id = runid );
        if runcc ='K9164' then
          hrq:='测试';
        end if;
        select count(*) into id from b_station where station_name = zm AND bureau_code='Q' and station_name<>'九龙';
        select station_name into str_sfz from run_point where runline_id = runid and xh=1;
        
        hrq:=grq||gsj;
        if id > 0 and hrq >sta_sj and hrq <= end_sj then 
            rid := rid + 1;
 --------dds_start_kc_data_qj在不在统计区段内的数
          lcc := substr(runcc,1,1);
          select count(*) into sfddid from dds_start_kc_data_qj where (end_station = zm AND start_station=str_sfz) or (end_station = str_sfz AND start_station=zm);
             if (sfddid>0 and lcc ='0') or runcc ='57001' or runcc ='57002' THEN 
                str_sfz:='不写';
              else
-------2011-01-11增加临客分析       
          lkcc:=substr(runcc,1,1);
          lklx:='图客';
          if lkcc ='A' or lkcc= '0' or lkcc = 'L' or lkcc = 'Y' then
           lklx:='临客';
           end if;
           fid :=INSTR(runcc,'/',1,1);
            ccline:=runcc;
           if fid> 0 then
              ccline:=substr(runcc,1,fid - 1); 
           end if;
           cclong:=length(ccline);

           if cclong>= 5  then  
              lkcc:=ccline;
              if  (lkcc >='Z4001' and lkcc<='Z4998') or (lkcc >='Z9001' and lkcc<='Z9998') or (lkcc >='D9001' and lkcc<='D9998') or (lkcc >='T3001' and lkcc<='T3998')  or (lkcc >'T4001' and lkcc<='T4998') or (lkcc >'K4001' and lkcc<='K4998') or (lkcc >'K5001' and lkcc<='K6998') or (lkcc >'C9000' and lkcc<='C9998') then
                   lklx:='临客';
              end if;
           end if;
 -------2015-01-01增加 
           qcc:=runcc;
           if fid > 0 then 
              qcc:=substr(runcc,1,fid - 1);
           end if;
           if qcc >='3001' and qcc<='3998' and length(qcc)=4 then 
              lklx:='临客';
           end if;
             fid :=INSTR(trainkind,'LK',1,1);
            if fid > 0 then 
               lklx:='临客';
             end if;
 -------2011-01-11增加  
                if (zm ='三亚' and   (str_sfz='海口东'   or  str_sfz='海口' or  str_sfz='三亚动车所')) or (zm='海口' and str_sfz='三亚') or (zm='三亚' and str_sfz='三亚') or  str_sfz='永州东' or zm='永州东'  or  str_sfz='笋岗' or zm='笋岗'  or zm='霞凝'  or str_sfz='霞凝' then 
                ----广珠线不写库
                   if substr(runcc,1,1)='K' then 
                     insert into dds_start_kc_data(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,'终到',rid,runid,zm,runcc,hrq,str_sfz,zm,lklx,trainkind);
                   end if; 
                  fid:=0;
                 else       
                 insert into dds_start_kc_data(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,'终到',rid,runid,zm,runcc,hrq,str_sfz,zm,lklx,trainkind);
                 end if;
             end if;
        end if;
      commit; 
  end loop;
  CLOSE read_run_line_zd;
  -------交出接入统计
  rid := 0;   
OPEN read_run_point_fjk;
       LOOP
       FETCH read_run_point_fjk INTO runid,zm,sta_d,end_d,id;
       EXIT WHEN read_run_point_fjk%NOTFOUND;
        select cc,sfz,zdz,train_kind into runcc,str_sfz,str_dzd,trainkind  from run_line where id=runid ;
         tkid:=id;
         pxh:=id;
         id :=id + 1;
         lc:=0;
         yzid:=tkid;
       select count(*)  into lc from run_point  where runline_id = runid and xh = id;
    --   if runcc ='K162' or runcc='K161' or zm='永州' then
     --    lc := lc; 
      --- end if;
       
       if zm='永州' or zm='蒲圻'  or zm='西斋'  or zm='秀山'  or zm='大龙' or  zm='牙屯堡' or zm='黔江渝怀场' then 
            lkcc:=substr(runcc,1,1);
            if lkcc='G' or  lkcc='C' then 
                lc:=0;
            end if;
       end if;
       
   if lc > 0 then ------有一个站
        select station_name  into nfjkz from run_point  where runline_id = runid and xh = id;
        select count(*) into id from b_station where station_name = nfjkz AND bureau_code='Q' and station_name<>'九龙';
       ------结束时间
        hrq:=end_d;
         
        select station_name  into str_sfz from run_point  where runline_id = runid and xh = 1;
        select station_name  into str_dzd from run_point  where runline_id = runid and xh in (select max(xh) from run_point where runline_id = runid);
          
          if id > 0 then 
             nfjkz :='接入';
             else
             nfjkz :='交出';
          end if;
  ------------塘口的特殊处理方法          
          if  zm='塘口' then 
              if tkid > 7 then
                   nfjkz :='接入';
               else
                   nfjkz :='交出';
               end if;
               if str_dzd ='徐闻' or str_dzd='海口' or str_dzd='三亚' then 
                    nfjkz:='接入';
               else
                    nfjkz:='交出';
               end if;
          end if;
------------永州的特殊处理方法          
          if  zm='永州' then 
            select count(*)  into tkid from run_point  where runline_id = runid and station_name in ('楠木塘','滩头湾');
              if tkid > 0 then
                   nfjkz :='通过';
               end if;
          end if;

           if  nfjkz ='接入'  then  
              if  (ZM  = '滩头湾' or  ZM = '株洲' or  ZM = '琥市' or  ZM = '楠木塘' or  ZM = '楠木塘' or  ZM = '珠玑巷') then
                   hrq:=sta_d;
                else
                   hrq:=end_d;
                end if;
           end if;
          if  nfjkz ='交出'  then  
              if  (ZM  = '滩头湾' or  ZM = '株洲' or  ZM = '琥市' or  ZM = '楠木塘' or  ZM = '楠木塘' or  ZM = '珠玑巷') then
                  hrq:=end_d;
                else
                  hrq:=sta_d;
                end if;
           end if;
         if  hrq >sta_sj and hrq <= end_sj then
               rid := rid + 1;
 -------2011-01-11增加临客分析 
 --         if runcc='T77' or runcc='K25'  or runcc='K26' then
 --            lklx:='图客';
 --         end if;      
          lkcc:=substr(runcc,1,1);
          lklx:='图客';
          if lkcc ='A' or lkcc= '0' or lkcc = 'L' or lkcc = 'Y' then
           lklx:='临客';
          end if;
            fid :=INSTR(runcc,'/',1,1);
            ccline:=runcc;
           if fid> 0 then
              ccline:=substr(runcc,1,fid - 1); 
           end if;
           cclong:=length(ccline);
           if cclong>= 5  then  
              lkcc:=ccline;
              if  (lkcc >='Z4001' and lkcc<='Z4998') or (lkcc >='Z9001' and lkcc<='Z9998') or (lkcc >='T3001' and lkcc<='T3998')  or (lkcc >'T4001' and lkcc<='T4998') or (lkcc >'K4001' and lkcc<='K4998') or (lkcc >'K5001' and lkcc<='K6998')  or (lkcc >'C9000' and lkcc<='C9998') then
                   lklx:='临客';
              end if;
           end if;
           qcc:=runcc;
           if fid > 0 then 
              qcc:=substr(runcc,1,fid - 1);
           end if;
           if qcc >='3001' and qcc<='3998' and length(qcc)=4 then 
              lklx:='临客';
           end if;
           fid :=INSTR(trainkind,'LK',1,1);
           if fid > 0 then 
                 lklx:='临客';
            end if;
 -------2014-01-17增加 
         if  zm='塘口' then
             select count(*)  into tkid from run_point  where runline_id = runid and station_name in ('茂名西');
             if tkid < 1 then
                select count(*)  into tkid from run_point  where runline_id = runid and station_name in ('茂名'); 
                if tkid > 0 then
                   select xh into tkid from run_point where runline_id = runid and station_name in ('茂名');
                   if pxh> tkid then 
                      yzzm :='交出';
                   else
                      yzzm :='接入';
                    end if;
                insert into dds_start_kc_data(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,yzzm,rid,runid,'塘口北',runcc,hrq,str_sfz,str_dzd,lklx,trainkind);
             end if;
             end if;
          end if;
            if zm ='永州' then            
               if nfjkz='接入' and str_sfz='永州' then 
                 nfjkz:='始发1';
               end if;
               if nfjkz='交出' and str_dzd='永州' then
                  nfjkz:='终到1' ;
                end if;
                if (nfjkz='接入' ) or (nfjkz='交出' ) then
                      tkid:=yzid - 1;
                      yzid:=yzid + 1;
                  select count(*) into yzid from b_station where  bureau_code<>'Q' and station_name in( select station_name from run_point  where runline_id = runid and xh=yzid);
                  select count(*) into tkid from b_station where  bureau_code<>'Q' and station_name in( select station_name from run_point  where runline_id = runid and xh=tkid);
                  if yzid=0 and tkid=0 then 
                     nfjkz:='永州内' ;
                  end if; 
               end if;
                
             end if; 
          
             insert into dds_start_kc_data(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,nfjkz,rid,runid,zm,runcc,hrq,str_sfz,str_dzd,lklx,trainkind);
   
       end if;
       commit;
    else
     ------2015-02-25没有一下个站
          if zm='秀山' then 
              select station_name  into str_sfz from run_point  where runline_id = runid and xh = 1;
              select station_name  into str_dzd from run_point  where runline_id = runid and xh in (select max(xh) from run_point where runline_id = runid);
             nfjkz:='交出';
             lklx:='临客';
             insert into dds_start_kc_data(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,nfjkz,rid,runid,zm,runcc,hrq,str_sfz,str_dzd,lklx,trainkind);
          end if; 
  end if;
    commit;
  end loop;
  
  CLOSE read_run_point_fjk;
  
  
  
-------深圳口交出接入统计
  rid := 0;   
OPEN read_run_point_sz;
       LOOP
       FETCH read_run_point_sz INTO runid,zm,sta_d,end_d,id;
       EXIT WHEN read_run_point_sz%NOTFOUND;
        select cc,sfz,zdz,train_kind into runcc,str_sfz,str_dzd,trainkind  from run_line where id=runid ;
        select max(xh) into id from run_point  where runline_id = runid;
 ------ id :=id + 1;-----下一个车站-----最后一个站
        select station_name  into nfjkz from run_point  where runline_id = runid and xh = id;
        if nfjkz='九龙' THEN 
        hrq:=end_d;
        select station_name  into str_sfz from run_point  where runline_id = runid and xh = 1;
        select station_name  into str_dzd from run_point  where runline_id = runid and xh in (select max(xh) from run_point where runline_id = runid);
             nfjkz :='交出';
             hrq:=end_d;
           if  hrq >sta_sj and hrq <= end_sj then
               rid := rid + 1;
 -------2011-01-11增加临客分析       
          lkcc:=substr(runcc,1,1);
          lklx:='图客';
          if lkcc ='A' or lkcc= '0' or lkcc = 'L' or lkcc = 'Y' then
           lklx:='临客';
           end if;
           fid :=INSTR(runcc,'/',1,1);
            ccline:=runcc;
           if fid> 0 then
              ccline:=substr(runcc,1,fid - 1); 
           end if;
           cclong:=length(ccline);

           if cclong>= 5  then  
              lkcc:=ccline;
              if  (lkcc >='Z4001' and lkcc<='Z4998') or (lkcc >='Z9001' and lkcc<='Z9998') or (lkcc >='T3001' and lkcc<='T3998')  or (lkcc >'T4001' and lkcc<='T4998') or (lkcc >'K4001' and lkcc<='K4998') or (lkcc >'K5001' and lkcc<='K6998') or (lkcc >'C9000' and lkcc<='C9998') then
                   lklx:='临客';
              end if;
           end if;
 -------2015-01-01增加
           qcc:=runcc; 
           if fid > 0 then 
              qcc:=substr(runcc,1,fid - 1);
           end if;
           if qcc >='3001' and qcc<='3998' and length(qcc)=4 then 
              lklx:='临客';
           end if;
             fid :=INSTR(trainkind,'LK',1,1);
           if fid > 0 then 
                 lklx:='临客';
            end if;
             insert into dds_start_kc_data(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,nfjkz,rid,runid,zm,runcc,hrq,str_sfz,str_dzd,lklx,trainkind);
        end if;
        end if;
      commit; 
  end loop;
  CLOSE read_run_point_sz;
  
  
  
  
  
  -------2016-12-06丝茅冲交出接入统计
  rid := 0;   
OPEN read_run_point_skq;
       LOOP
       FETCH read_run_point_skq INTO runid,zm,sta_d,end_d,id;
       EXIT WHEN read_run_point_skq%NOTFOUND;
        select cc,sfz,zdz,train_kind into runcc,str_sfz,str_dzd,trainkind  from run_line where id=runid ;
-----   select xh + 1 into id from run_point  where runline_id = runid and station_name='丝茅冲';
        id :=id + 1;-----下一个车站-----最后一个站
        select station_name  into nfjkz from run_point  where runline_id = runid and xh = id;
        
        select count(*) into hkid from xd_node_skq where node=nfjkz;
        if hkid=0 then
           nfjkz :='交出';
         else
           nfjkz :='接入';
        end if;
        hrq:=end_d;
        select station_name  into str_sfz from run_point  where runline_id = runid and xh = 1;
        select station_name  into str_dzd from run_point  where runline_id = runid and xh in (select max(xh) from run_point where runline_id = runid);
             hrq:=end_d;
        if  hrq >sta_sj and hrq <= end_sj then
               rid := rid + 1;
 -------2011-01-11增加临客分析       
          lkcc:=substr(runcc,1,1);
          lklx:='图客';
          if lkcc ='A' or lkcc= '0' or lkcc = 'L' or lkcc = 'Y' then
           lklx:='临客';
           end if;
           fid :=INSTR(runcc,'/',1,1);
            ccline:=runcc;
           if fid> 0 then
              ccline:=substr(runcc,1,fid - 1); 
           end if;
           cclong:=length(ccline);

           if cclong>= 5  then  
              lkcc:=ccline;
              if  (lkcc >='Z4001' and lkcc<='Z4998') or (lkcc >='Z9001' and lkcc<='Z9998') or (lkcc >='T3001' and lkcc<='T3998')  or (lkcc >'T4001' and lkcc<='T4998') or (lkcc >'K4001' and lkcc<='K4998') or (lkcc >'K5001' and lkcc<='K6998')  or (lkcc >'C9000' and lkcc<='C9998') then
                   lklx:='临客';
              end if;
           end if;
 -------2015-01-01增加
           qcc:=runcc; 
           if fid > 0 then 
              qcc:=substr(runcc,1,fid - 1);
           end if;
           if qcc >='3001' and qcc<='3998' and length(qcc)=4 then 
              lklx:='临客';
           end if;
             fid :=INSTR(trainkind,'LK',1,1);
           if fid > 0 then 
                 lklx:='临客';
            end if;
             insert into dds_start_kc_data(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,nfjkz,rid,runid,zm,runcc,hrq,str_sfz,str_dzd,lklx,trainkind);
        end if;

      commit; 
  end loop;
  CLOSE read_run_point_skq;
  
  
  
  
  
  
------管内株洲口的统计方法  

rid := 0;   
  OPEN read_run_point_zzk;
      LOOP
       FETCH read_run_point_zzk INTO runid,zm,sta_d,end_d,id;
       EXIT WHEN read_run_point_zzk%NOTFOUND;
        select cc,sfz,zdz,train_kind into runcc,str_sfz,str_dzd,trainkind  from run_line where id=runid ;
         if runcc ='K4156/7' then
            lkcc:='调试'; 
        end if;
         qid :=id;
         id :=id + 1;----下一站
         hid :='';
         bid :='';
         tjn := 'y';
         begin
        select station_name  into nfjkz from run_point  where runline_id = runid and xh = id;
        EXCEPTION 
        WHEN OTHERS THEN 
            id :=id - 1;
           select station_name  into nfjkz from run_point  where runline_id = runid and xh = id;
           tjn :='y';----不统计，是株洲站终止
 ----      ROLLBACK;
       end;
        hid :='下一站';
        begin
        select bureau_code into hid from b_station_gnzzk where station_name = nfjkz  and station_name<>'九龙';
        EXCEPTION 
        WHEN OTHERS THEN 
           hid :='下一站';
        END;
        -----没有下一个站
         if qid > 1 then   
              qid :=qid - 1;----前一站
         end if;
        select station_name  into nfjkz from run_point  where runline_id = runid and xh = qid;
        bid:='前一站';
        begin
        select bureau_code into bid from b_station_gnzzk where station_name = nfjkz  and station_name<>'九龙';
        EXCEPTION 
        WHEN OTHERS THEN 
           bid :='前一站';
        END;
        if (bid='前一站' or bid =null) AND (hid='下一站' or hid=null) then 
           tjn:='n';
        end if;
        hrq:=end_d;
    if tjn ='y' then     
        select station_name  into str_sfz from run_point  where runline_id = runid and xh = 1;
        select station_name  into str_dzd from run_point  where runline_id = runid and xh in (select max(xh) from run_point where runline_id = runid);
            if bid<>'前一站' AND hid='下一站' then 
            nfjkz :='交出';
             else
             nfjkz :='接入';
            end if;
           if  nfjkz ='交出'  then  
                   hrq:=sta_d;
                else
                   hrq:=end_d;
           end if;
         
           if  hrq >sta_sj and hrq <= end_sj then
                 rid := rid + 1;
                 begin
 -------2011-01-11增加临客分析       
          lkcc:=substr(runcc,1,1);
          lklx:='图客';
          if lkcc ='A' or lkcc= '0' or lkcc = 'L' or lkcc = 'Y' then
           lklx:='临客';
           end if;
            fid :=INSTR(runcc,'/',1,1);
            ccline:=runcc;
           if fid> 0 then
              ccline:=substr(runcc,1,fid - 1); 
           end if;
           cclong:=length(ccline);
           if cclong>= 5  then  
              lkcc:=ccline;  
              lkcc:=substr(runcc,1,5);
              if  (lkcc >='Z4001' and lkcc<='Z4998') or (lkcc >='Z9001' and lkcc<='Z9998') or (lkcc >='T3001' and lkcc<='T3998')  or (lkcc >'T4001' and lkcc<='T4998') or (lkcc >'K4001' and lkcc<='K4998') or (lkcc >'K5001' and lkcc<='K6998') or (lkcc >'C9000' and lkcc<='C9998') then
                   lklx:='临客';
              end if;
           end if;
 -------2015-01-01增加 
              qcc:=runcc;
           if fid > 0 then 
              qcc:=substr(runcc,1,fid - 1);
           end if;
           if qcc >='3001' and qcc<='3998' and length(qcc)=4 then 
              lklx:='临客';
           end if;
                fid :=INSTR(trainkind,'LK',1,1);
           if fid > 0 then 
                 lklx:='临客';
            end if;
 -------2011-01-11增加 
                insert into dds_start_kc_data(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,nfjkz,rid,runid,'管内株洲',runcc,hrq,str_sfz,str_dzd,lklx,trainkind);
                EXCEPTION 
            WHEN OTHERS THEN 
               ROLLBACK;
             END;
           end if;
    end if;
      commit; 
  end loop;
  CLOSE read_run_point_zzk;    
  

  
  
 -----统计坪石口数---- 
 rid := 0;   
OPEN read_run_point_psk;
       LOOP
       FETCH read_run_point_psk INTO runid,zm,sta_d,end_d,id;
       EXIT WHEN read_run_point_psk%NOTFOUND;
        select cc,sfz,zdz,train_kind into runcc,str_sfz,str_dzd,trainkind  from run_line where id=runid ;
   ---         if runcc ='T97' THEN 
   ---             nfjkz :='交出';
   ----          END IF;
         id :=id + 1;
        select station_name  into nfjkz from run_point  where runline_id = runid and xh = id;--下一站
        select count(*) into id from b_station where station_name = nfjkz AND bureau_code='Q' and ((subbureau_code in ('63','68','65') and station_name<>'九龙') or station_name='广州西');
         if id > 0 then -----下行
            hrq:=sta_d;
            nfjkz :='交出';
         else
            hrq:=end_d;
            nfjkz :='接入';
         end if;
        if  hrq >sta_sj and hrq <= end_sj then ------时间范围内
        select station_name  into str_sfz from run_point  where runline_id = runid and xh = 1;--始发站
        select station_name  into str_dzd from run_point  where runline_id = runid and xh in (select max(xh) from run_point where runline_id = runid);
             rid := rid + 1;
              begin
 -------2011-01-11增加临客分析       
          lkcc:=substr(runcc,1,1);
          lklx:='图客';
          if lkcc ='A' or lkcc= '0' or lkcc = 'L' or lkcc = 'Y' then
           lklx:='临客';
           end if;
            fid :=INSTR(runcc,'/',1,1);
            ccline:=runcc;
           if fid> 0 then
              ccline:=substr(runcc,1,fid - 1); 
           end if;
           cclong:=length(ccline);

           if cclong>= 5  then  
              lkcc:=ccline;  
              lkcc:=substr(runcc,1,5);
              if  (lkcc >='Z4001' and lkcc<='Z4998') or (lkcc >='Z9001' and lkcc<='Z9998') or (lkcc >='T3001' and lkcc<='T3998')  or (lkcc >'T4001' and lkcc<='T4998') or (lkcc >'K4001' and lkcc<='K4998') or (lkcc >'K5001' and lkcc<='K6998') or (lkcc >'C9000' and lkcc<='C9998') then
                   lklx:='临客';
              end if;
           end if;
 -------2015-01-01增加 
           qcc:=runcc;
           if fid > 0 then 
              qcc:=substr(runcc,1,fid - 1);
           end if;
           if qcc >='3001' and qcc<='3998' and length(qcc)=4 then 
              lklx:='临客';
           end if;
           fid :=INSTR(trainkind,'LK',1,1);
           if fid > 0 then 
                 lklx:='临客';
            end if;
 -------2011-01-11增加              
              
             insert into dds_start_kc_data(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,nfjkz,rid,runid,zm,runcc,hrq,str_sfz,str_dzd,lklx,trainkind);
             EXCEPTION 
            WHEN OTHERS THEN 
               ROLLBACK;
             END;
        end if;
      commit; 
  end loop;
  CLOSE read_run_point_psk; 
  update dds_start_kc_data set station='邵阳' where  rq = rqstr and station='邵阳站娄邵场';
  
----统计出发情况分析-----
 delete from dds_start_kc_tj where rq = rqstr;
 COMMIT;
 
ii := 0;
loop 
ii := ii+ 1;
if ii = 1 then 
 sfbz:='始发';
end if;
if ii = 2 then 
 sfbz:='终到';
end if;
if ii = 3 then 
 sfbz:='接入';
end if;
if ii = 4 then 
 sfbz:='交出';
end if;
EXIT WHEN ii > 4 ;
rid := 0;  
kct1 :=0;
kcl1  :=0;
kch1  :=0;
kct2  :=0;
kcl2  :=0;
kch2   :=0;
kct3  :=0;
kcl3   :=0;
kch3   :=0;
kct4  :=0;
kcl4   :=0;
kch4   :=0;
kct5   :=0;
kcl5   :=0;
kch5  :=0;

OPEN read_dds_start_kc_data;
       LOOP
       FETCH read_dds_start_kc_data INTO ZM;
       EXIT WHEN read_dds_start_kc_data%NOTFOUND;
       ----第一阶段
       sta_sj := DAY1||'1800' ;
       end_sj := DAY2||'0000';
        SELECT  count(cc) into kct1 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx ='图客' and      tsj >sta_sj and tsj <= end_sj;
        SELECT  count(cc) into kcl1 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx ='临客' and   tsj >sta_sj and tsj <= end_sj ;
           kch1:=kct1+kcl1; 
       -----第二阶段
        sta_sj := DAY2||'0000' ;
        end_sj := DAY2||'0600';
        SELECT  count(cc) into kct2 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx ='图客' and     tsj >sta_sj and tsj <=end_sj;
        SELECT  count(cc) into kcl2 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                        lx ='临客' AND   tsj >sta_sj and tsj <=end_sj;
           kch2:=kct2+kcl2;    
       ------第三阶段
       sta_sj := DAY2||'0600' ;
       end_sj := DAY2||'1200';
        SELECT  count(cc) into kct3 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                     lx ='图客' AND        tsj >sta_sj and tsj <=end_sj;
        SELECT  count(cc) into kcl3 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                        lx ='临客' AND    tsj >sta_sj and tsj <=end_sj;
           kch3:=kct3+kcl3;     
         ---第四阶段
         sta_sj := DAY2||'1200' ;
         end_sj := DAY2||'1800';
        SELECT  count(cc) into kct4 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx ='图客' AND    tsj >sta_sj and tsj <=end_sj;
        SELECT  count(cc) into kcl4 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx ='临客' AND  tsj >sta_sj and tsj <=end_sj;
         kch4:=kct4+kcl4; 
         kct5:=kct1+kct2+kct3+kct4;
         kcl5:=kcl1+kcl2+kcl3+kcl4;
         kch5:=kch1+kch2+kch3+kch4;              
             rid := rid + 1;
             insert into dds_start_kc_tj values (rqstr,sfbz,rid,zm,kct1,kcl1,kch1,kct2,kcl2,kch2,kct3,kcl3,kch3,kct4,kcl4,kch4,kct5,kcl5,kch5,1);
        
      commit; 
  end loop;
CLOSE read_dds_start_kc_data;
end loop;

----统计出发情况分析(按调度所统计)-----
delete from dds_start_kc_tj_zlw where rq = rqstr;
COMMIT;
 
ii := 0;
loop 
ii := ii+ 1;
if ii = 1 then 
 sfbz:='始发';
end if;
if ii = 2 then 
 sfbz:='终到';
end if;
if ii = 3 then 
 sfbz:='接入';
end if;
if ii = 4 then 
 sfbz:='交出';
end if;
EXIT WHEN ii > 4 ;
rid := 0;  
kct1 :=0;
kct2 :=0;
kct3 :=0;
kct4 :=0;
kct5 :=0;
 
OPEN read_dds_start_kc_data;
       LOOP
       FETCH read_dds_start_kc_data INTO ZM;
       EXIT WHEN read_dds_start_kc_data%NOTFOUND;
       sta_sj := DAY1||'1800' ;
       end_sj := DAY2||'1800';
       
       ----图定客车
        SELECT  count(cc) into kct1 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx='图客' and   tsj >sta_sj and tsj <= end_sj;
        -----临客-----
        
        SELECT  count(cc) into kct2 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                        lx='临客' and  cc not like '0%' and  tsj >sta_sj and tsj <= end_sj ;
          ------车底----------  
                    
         SELECT  count(cc) into kct3 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                         lx='临客'  and  cc  like '0%'  and   tsj >sta_sj and tsj <= end_sj ;              
                     
             kct4:=kct1+kct2+kct3;         
             rid := rid + 1;
             insert into dds_start_kc_tj_zlw values (rqstr,sfbz,rid,zm,kct1,kct2,kct3,kct4,kct5);
        
      commit; 
  end loop;
CLOSE read_dds_start_kc_data;
end loop;
delete from  DDS_START_KCGT_TIME where tren='普速铁路';
insert into  DDS_START_KCGT_TIME select '普速铁路',to_char(sysdate ,'yyyy-mm-dd hh24:mi')   from dual;


commit;
end sunday_rbjh_fjk;
/

