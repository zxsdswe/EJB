create procedure PRO_YXSJ_ZHSJ is
  /*本存储过程用于转换2天前得历史数据到历史表*/
begin
  /*将 yxsj_ljlcyxmx 表中3天以前的数据转入历史表 yxsj_ljlcyxmx_his 中---start*/
  delete yxsj_ljlcyxmx_his
   where to_char(tbrq,'yyyymmdd') = to_char(sysdate -2, 'yyyymmdd');

  insert into yxsj_ljlcyxmx_his
    (select *
       from yxsj_ljlcyxmx
      where to_char(tbrq,'yyyymmdd') = to_char(sysdate -2, 'yyyymmdd'));

  delete yxsj_ljlcyxmx
   where to_char(tbrq,'yyyymmdd') = to_char(sysdate -2, 'yyyymmdd');

  commit;
  /*将 yxsj_ljlcyxmx 表中3天以前的数据转入历史表 yxsj_ljlcyxmx_his 中---end*/

  /*将 yxsj_sfzd_fjk 表中3天以前的数据转入历史表 yxsj_sfzd_fjk_his 中---start*/
  delete yxsj_sfzd_fjk_his
   where to_char(tbrq,'yyyymmdd') = to_char(sysdate -2, 'yyyymmdd');

  insert into yxsj_sfzd_fjk_his
    (select *
       from yxsj_sfzd_fjk
      where to_char(tbrq,'yyyymmdd') = to_char(sysdate -2, 'yyyymmdd'));

  delete yxsj_sfzd_fjk
   where to_char(tbrq,'yyyymmdd') = to_char(sysdate -2, 'yyyymmdd');

  commit;
  /*将 yxsj_sfzd_fjk 表中3天以前的数据转入历史表 yxsj_sfzd_fjk_his 中---end*/

end PRO_YXSJ_ZHSJ;
/

