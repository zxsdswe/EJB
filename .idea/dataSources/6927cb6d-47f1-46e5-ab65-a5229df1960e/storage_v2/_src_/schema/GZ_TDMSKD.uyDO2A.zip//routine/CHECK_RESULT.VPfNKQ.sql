create FUNCTION        "CHECK_RESULT" (
  p_fcrq in k_qdzsb.fcrq%type,
  p_cc in k_qdzsb.cc%type,
  p_gczx in k_qdzsb.gczx%type,
  p_sczx in k_qdzsb.sczx%type,
  p_mlrq in k_qdzsb.mlrq%type,
  p_mlh in k_qdzsb.mlh%TYPE,
  p_mlxh in k_qdzsb.mlxh%type,
  p_zrxh in k_qdzsb.zrxh%type,
  p_ini_zs in number,
  p_max_zs in number,
  p_jgts in number,
  p_grbz in boolean,
  p_yzcd in boolean,
  p_cdzs in number,
  p_jcrq in varchar2,
  p_action in number,
  p_action_date in varchar2,
  p_rtnstring out long)
  return boolean IS
  /*定义游标*/
  cursor c_qdzsb(pc_fcrq k_qdzsb.fcrq%type)
                 is select mlrq,mlh,mlxh,zrxh,action,action_date from k_qdzsb
                    where fcrq=pc_fcrq and cc=p_cc
                    order by mlrq,mlh,to_number(mlxh),zrxh;
  cursor c_temp1 is select xh,mlrq,mlh,mlxh,zrxh,action,to_char(action_date,'YYYYMMDD') from k_temp1_qdzsb
                    order by xh;
  /*判断用变量*/
  li_num number(3):=0;
  /*循环变量*/
  li_count number(4):=0;--while 用
  li_ml_index number(4):=0;--命令索引
  li_qd_index number(2):=0;--区段索引
  li_max number(3):=0;--记录要检查的命令总数
  li_j number(2):=0;--for用循环变量
  li_m number(2):=0;--for for 用循环变量
  ls_m_gczx varchar2(3);
  ls_m_sczx varchar2(3);
  li_m_cur_zs number(2):=0;
  /*定义局部变量*/
  num_cur_zs number(2);num_cur_zs2 number(2);num_qdzs number(2);
  begin_index number(2);end_index number(2);
  li_xh number(2);ls_mlrq varchar2(8);ls_mlh varchar2(6);ls_mlxh varchar2(3);li_zrxh number(2); li_action number(1);ls_action_date varchar2(8);
  li_ls number(2);ls_zy varchar2(4);
  ls_first_gczx varchar2(3);ls_first_sczx varchar2(3);
  li_cur_zs number(2):=0;
  ls_s_gczx varchar2(3);ls_s_sczx varchar2(3);ls_gczx varchar2(3);ls_sczx varchar2(3);
  /*常规命令使用的变量*/
  v_mlrq k_qdzsb.mlrq%type;
  v_mlh k_qdzsb.mlh%type;
  v_mlxh k_qdzsb.mlxh%type;
  v_zrxh k_qdzsb.zrxh%type;
  v_action k_qdzsb.action%type;
  v_action_date k_qdzsb.action_date%type;
  v_mlhm varchar2(20);
BEGIN
  delete from k_temp1_qdzsb;
  delete from k_temp2_qdzsb;
  commit;
  li_count:=0;
  while li_count<=p_jgts loop
     /*初始化变量*/
     li_max:=0;
     li_num:=0;
     num_cur_zs:=0;
     num_cur_zs2:=0;
     num_qdzs:=0;
     begin_index:=0;
     end_index:=0;
     li_xh:=0;
     ls_mlrq:='';
     ls_mlh:='';
     ls_mlxh:='';
     li_zrxh:=0;
     ls_first_gczx:='';
     ls_first_sczx:='';
     li_qd_index:=0;
     /*初始化变量结束*/
     /*将正在检查的轴位入库*/
     insert into k_qdzsb(fcrq,cc,gczx,sczx,cur_zs,mlrq,mlh,mlxh,zrxh,jcrq,action,action_date)
                 values(to_char(to_date(p_fcrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                        p_cc,
                        p_gczx,
                        p_sczx,
                        '0',
                        p_mlrq,
                        p_mlh,
                        p_mlxh,
                        p_zrxh,
                        to_char(to_date(p_jcrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                        p_action,
                        to_date(p_action_date,'YYYYMMDD')
                       );
     commit;
     /*轴位入库结束*/
     open c_qdzsb(to_char(to_date(p_fcrq,'YYYYMMDD') + li_count,'YYYYMMDD'));
     li_ml_index:=0;
     loop
       fetch c_qdzsb into v_mlrq,v_mlh,v_mlxh,v_zrxh,v_action,v_action_date;
       exit when c_qdzsb%notfound;
       insert into k_temp1_qdzsb(xh,mlrq,mlh,mlxh,zrxh,action,action_date)
                     values(li_ml_index,
                            v_mlrq,
                            v_mlh,
                            v_mlxh,
                            v_zrxh,
                            v_action,
                            v_action_date
                           );
       li_ml_index:=li_ml_index + 1;
     end loop;--c_qdzsb
     close c_qdzsb;
     commit;
     select max(xh) into li_max from k_temp1_qdzsb;
     if c_temp1%ISOPEN then
        close c_temp1;
     end if;
     open c_temp1;
     loop
        li_ls:=0;
        ls_zy:='';
        fetch c_temp1 into li_xh,ls_mlrq,ls_mlh,ls_mlxh,li_zrxh,li_action,ls_action_date;
        exit when c_temp1%notfound;
        if length(ls_mlxh) = 1 then
           v_mlhm:=ls_mlh||'-0'||ls_mlxh||'('||substr(ls_mlrq,5,2)||')';
        else
           v_mlhm:=ls_mlh||'-'||ls_mlxh||'('||substr(ls_mlrq,5,2)||')';
        end if;
        select count(*) into li_num from sgml
         where to_char(rq,'YYYYMMDD') =ls_mlrq and mlh=ls_mlh and mlxh=to_number(ls_mlxh) and zrxh=li_zrxh and action=li_action and to_char(action_date,'YYYYMMDD')=ls_action_date;
        if li_num=0 then
           p_rtnstring:=p_rtnstring||v_mlhm||'令无命令信息,无法检查!'||chr(10)||'<br>';
           goto continue;
        elsif li_num>1 then
           p_rtnstring:=p_rtnstring||v_mlhm||'令命令信息有多余记录!'||chr(10)||'<br>';
           goto continue;
        elsif li_num=1 then
           select ls,zy into li_ls,ls_zy from sgml
            where to_char(rq,'YYYYMMDD') =ls_mlrq and mlh=ls_mlh and mlxh=to_number(ls_mlxh) and zrxh=li_zrxh and action=li_action and to_char(action_date,'YYYYMMDD')=ls_action_date;
        end if;
        if ls_zy='甩' then
           li_ls:=li_ls*(-1);
        end if;
        if li_xh=0 then
           end_index:=end_index+1;
           num_cur_zs:=p_ini_zs + li_ls;
           select distinct gczx,sczx into ls_first_gczx,ls_first_sczx from k_qdzsb
             where mlrq=ls_mlrq and mlh=ls_mlh and mlxh=ls_mlxh and zrxh=li_zrxh and action=li_action and to_char(action_date,'YYYYMMDD')=ls_action_date
                   and fcrq=to_char(to_date(p_fcrq,'YYYYMMDD') + li_count,'YYYYMMDD') and cc=p_cc;
           insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_first_gczx,ls_first_sczx,num_cur_zs);
           commit;
           li_qd_index:=li_qd_index + 1;
           if num_cur_zs > p_max_zs and li_xh = li_max then
              p_rtnstring:=p_rtnstring||v_mlhm||'令'||to_char(to_date(p_fcrq,'YYYYMMDD') + li_count,'YYYYMMDD')||'开'||gettraincode(p_cc)
                           ||'次'||getStationName(p_cc,ls_first_gczx)||'和'||getStationName(p_cc,ls_first_sczx)
                           ||'间超轴!现:'||to_char(num_cur_zs)||chr(10)||'<br>';
           end if;
        else
          select gczx,sczx into ls_s_gczx,ls_s_sczx from k_qdzsb
            where mlrq=ls_mlrq and mlh=ls_mlh and mlxh=ls_mlxh and zrxh=li_zrxh and action=li_action and to_char(action_date,'YYYYMMDD')=ls_action_date
                and fcrq=to_char(to_date(p_fcrq,'YYYYMMDD') + li_count,'YYYYMMDD') and cc=p_cc;
          for li_j in begin_index..end_index - 1 loop
              num_cur_zs:=0;
              num_cur_zs2:=0;
              select gczx,sczx,cur_zs into ls_gczx,ls_sczx,li_cur_zs from k_temp2_qdzsb
                where xh=li_j;
              /*具体检查超轴情况*/
              --区段比较
              --(1)区段不交叉
              if to_number(ls_s_gczx)>=to_number(ls_sczx) then
                 num_cur_zs:=p_ini_zs + li_ls;
                 if num_cur_zs>p_max_zs and li_xh=li_max then
                    p_rtnstring:=p_rtnstring||v_mlhm||'令'||to_char(to_date(p_fcrq,'YYYYMMDD') + li_count,'YYYYMMDD')||'开'||gettraincode(p_cc)
                           ||'次'||getStationName(p_cc,ls_s_gczx)||'和'||getStationName(p_cc,ls_s_sczx)
                           ||'间超轴!现:'||to_char(num_cur_zs)||chr(10)||'<br>';
                 end if;
                 insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_gczx,ls_sczx,li_cur_zs);
                 li_qd_index:=li_qd_index + 1;
                 if li_j = end_index - 1 then
                    insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_s_gczx,ls_s_sczx,num_cur_zs);
                    li_qd_index:=li_qd_index + 1;
                 end if;
                 commit;
              end if;--ls_s_gczx>=ls_sczx
              --(2)区段不交叉
              if to_number(ls_s_sczx)<=to_number(ls_gczx) then
                 num_cur_zs := p_ini_zs + li_ls;
                 if num_cur_zs>p_max_zs and li_xh = li_max then
                    p_rtnstring:=p_rtnstring||v_mlhm||'令'||to_char(to_date(p_fcrq,'YYYYMMDD') + li_count,'YYYYMMDD')||'开'||gettraincode(p_cc)
                           ||'次'||getStationName(p_cc,ls_s_gczx)||'和'||getStationName(p_cc,ls_s_sczx)
                           ||'间超轴!现:'||to_char(num_cur_zs)||chr(10)||'<br>';
                 end if;
                 insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_gczx,ls_sczx,li_cur_zs);
                 li_qd_index:=li_qd_index + 1;
                 if li_j = end_index - 1 then
                    insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_s_gczx,ls_s_sczx,num_cur_zs);
                    li_qd_index:=li_qd_index + 1;
                 end if;
                 commit;
              end if;--ls_s_sczx<=ls_gczx
              --区段交叉
              if to_number(ls_s_gczx)>=to_number(ls_gczx) and to_number(ls_s_gczx)<=to_number(ls_sczx) then
                 if to_number(ls_s_sczx)>=to_number(ls_gczx) and to_number(ls_s_sczx)<=to_number(ls_sczx) then
                    num_cur_zs:=li_cur_zs + li_ls;
                    if num_cur_zs>p_max_zs and li_xh=li_max then
                       p_rtnstring:=p_rtnstring||v_mlhm||'令'||to_char(to_date(p_fcrq,'YYYYMMDD') + li_count,'YYYYMMDD')||'开'||gettraincode(p_cc)
                           ||'次'||getStationName(p_cc,ls_s_gczx)||'和'||getStationName(p_cc,ls_s_sczx)
                           ||'间超轴!现:'||to_char(num_cur_zs)||chr(10)||'<br>';
                    end if;
                    if to_number(ls_s_gczx)=to_number(ls_gczx) and to_number(ls_s_sczx)=to_number(ls_sczx) then
                       insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_gczx,ls_sczx,num_cur_zs);
                       li_qd_index:=li_qd_index + 1;
                    end if;--a
                    if to_number(ls_s_gczx)=to_number(ls_gczx) and to_number(ls_s_sczx)!=to_number(ls_sczx) then
                       insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_gczx,ls_s_sczx,num_cur_zs);
                       li_qd_index:=li_qd_index + 1;
                       insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_s_sczx,ls_sczx,li_cur_zs);
                       li_qd_index:=li_qd_index + 1;
                    end if;--b
                    if to_number(ls_s_gczx)!=to_number(ls_gczx) and to_number(ls_s_sczx)=to_number(ls_sczx) then
                       insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_gczx,ls_s_gczx,li_cur_zs);
                       li_qd_index:=li_qd_index + 1;
                       insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_s_gczx,ls_sczx,num_cur_zs);
                       li_qd_index:=li_qd_index + 1;
                    end if;--c
                    for li_m in li_j + 1..end_index-1 loop
                       select gczx,sczx,cur_zs into ls_m_gczx,ls_m_sczx,li_m_cur_zs from k_temp2_qdzsb where xh=li_m;
                       insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_m_gczx,ls_m_sczx,li_cur_zs);
                       li_qd_index:=li_qd_index + 1;
                    end loop;--for li_m
                    commit;
                    goto for_break;
                 end if;--(3)
                 if to_number(ls_s_sczx)>to_number(ls_sczx) then
                    num_cur_zs := li_cur_zs + li_ls;
                    num_cur_zs2 := p_ini_zs + li_ls;
                    if num_cur_zs > p_max_zs and li_xh=li_max then
                       p_rtnstring:=p_rtnstring||v_mlhm||'令'||to_char(to_date(p_fcrq,'YYYYMMDD') + li_count,'YYYYMMDD')||'开'||gettraincode(p_cc)
                           ||'次'||getStationName(p_cc,ls_s_gczx)||'和'||getStationName(p_cc,ls_sczx)
                           ||'间超轴!现:'||to_char(num_cur_zs)||chr(10)||'<br>';
                    end if;
                    if li_j = end_index-1 then
                       if num_cur_zs2 > p_max_zs and li_xh=li_max then
                          p_rtnstring:=p_rtnstring||v_mlhm||'令'||to_char(to_date(p_fcrq,'YYYYMMDD') + li_count,'YYYYMMDD')||'开'||gettraincode(p_cc)
                           ||'次'||getStationName(p_cc,ls_sczx)||'和'||getStationName(p_cc,ls_s_sczx)
                           ||'间超轴!现:'||to_char(num_cur_zs2)||chr(10)||'<br>';
                       end if;
                    end if;
                    if to_number(ls_s_gczx)=to_number(ls_gczx) then
                       insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_gczx,ls_sczx,num_cur_zs);
                       li_qd_index:=li_qd_index + 1;
                       if li_j = end_index -1 then
                          insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_sczx,ls_s_sczx,num_cur_zs2);
                          li_qd_index:=li_qd_index + 1;
                       else
                          ls_s_gczx:=ls_sczx;
                       end if;
                    else
                       insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_gczx,ls_s_gczx,li_cur_zs);
                       li_qd_index:=li_qd_index + 1;
                       insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_s_gczx,ls_sczx,num_cur_zs);
                       li_qd_index:=li_qd_index + 1;
                       if li_j=end_index -1 then
                          insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_sczx,ls_s_sczx,num_cur_zs2);
                          li_qd_index:=li_qd_index + 1;
                       else
                          ls_s_gczx:= ls_sczx;
                       end if;
                    end if;
                    commit;
                 end if;--(4)
              end if;
              if to_number(ls_s_gczx)<to_number(ls_gczx) and to_number(ls_s_sczx)>to_number(ls_gczx) and to_number(ls_s_sczx)<=to_number(ls_sczx) then
                 num_cur_zs:=li_cur_zs + li_ls;
                 num_cur_zs2:=p_ini_zs + li_ls;
                 if num_cur_zs>p_max_zs and li_xh = li_max then
                    p_rtnstring:=p_rtnstring||v_mlhm||'令'||to_char(to_date(p_fcrq,'YYYYMMDD') + li_count,'YYYYMMDD')||'开'||gettraincode(p_cc)
                           ||'次'||getStationName(p_cc,ls_gczx)||'和'||getStationName(p_cc,ls_s_sczx)
                           ||'间超轴!现:'||to_char(num_cur_zs)||chr(10)||'<br>';
                 end if;
                 if num_cur_zs2>p_max_zs and li_xh = li_max then
                   p_rtnstring:=p_rtnstring||v_mlhm||'令'||to_char(to_date(p_fcrq,'YYYYMMDD') + li_count,'YYYYMMDD')||'开'||gettraincode(p_cc)
                           ||'次'||getStationName(p_cc,ls_s_gczx)||'和'||getStationName(p_cc,ls_gczx)
                           ||'间超轴!现:'||to_char(num_cur_zs2)||chr(10)||'<br>';
                 end if;
                 if to_number(ls_s_sczx)=to_number(ls_sczx) then
                    insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_s_gczx,ls_gczx,num_cur_zs2);
                    li_qd_index:=li_qd_index + 1;
                    insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_gczx,ls_sczx,num_cur_zs);
                    li_qd_index:=li_qd_index + 1;
                 else
                    insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_s_gczx,ls_gczx,num_cur_zs2);
                    li_qd_index:=li_qd_index + 1;
                    insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_gczx,ls_s_sczx,num_cur_zs);
                    li_qd_index:=li_qd_index + 1;
                    insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_s_sczx,ls_sczx,li_cur_zs);
                    li_qd_index:=li_qd_index + 1;
                 end if;
                 for li_m in li_j + 1 ..end_index -1 loop
                    select gczx,sczx,cur_zs into ls_m_gczx,ls_m_sczx,li_m_cur_zs from k_temp2_qdzsb where xh=li_m;
                    insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_m_gczx,ls_m_sczx,li_m_cur_zs);
                    li_qd_index:=li_qd_index + 1;
                 end loop;--for li_m
                 commit;
                 goto for_break;
              end if;--(5)
              if to_number(ls_s_gczx)<to_number(ls_gczx) and to_number(ls_s_sczx)>to_number(ls_sczx) then
                 num_cur_zs:=li_cur_zs + li_ls;
                 num_cur_zs2:=p_ini_zs + li_ls;
                 if num_cur_zs > p_max_zs and li_xh = li_max then
                    p_rtnstring:=p_rtnstring||v_mlhm||'令'||to_char(to_date(p_fcrq,'YYYYMMDD') + li_count,'YYYYMMDD')||'开'||gettraincode(p_cc)
                           ||'次'||getStationName(p_cc,ls_gczx)||'和'||getStationName(p_cc,ls_sczx)
                           ||'间超轴!现:'||to_char(num_cur_zs)||chr(10)||'<br>';
                 end if;
                 insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_s_gczx,ls_gczx,num_cur_zs2);
                 li_qd_index:=li_qd_index + 1;
                 insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_gczx,ls_sczx,num_cur_zs);
                 li_qd_index:=li_qd_index + 1;
                 if li_j = end_index -1 then
                    insert into k_temp2_qdzsb(xh,gczx,sczx,cur_zs) values(li_qd_index,ls_sczx,ls_s_sczx,num_cur_zs2);
                    li_qd_index:=li_qd_index + 1;
                 else
                    ls_s_gczx:=ls_sczx;
                 end if;
                 commit;
              end if;--(6)
              /*检查超轴情况结束*/
          end loop;--for
          <<for_break>>
          begin_index:=end_index;
          select count(*) into end_index from k_temp2_qdzsb;
        end if;--li_xh=0
     end loop;--c_temp1
     close c_temp1;
     commit;
     if p_grbz then
        li_count:=li_count + 1;
     end if;
     if p_yzcd then
        li_count:=li_count + p_cdzs;
     end if;
     <<continue>>
     li_count:=li_count+ 1;
     /*清理临时表数据*/
     delete from k_temp1_qdzsb;
     delete from k_temp2_qdzsb;
     /*清理临时表数据结束*/
  end loop;
  <<break>>
  delete from k_temp1_qdzsb;
  delete from k_temp2_qdzsb;
  commit;
  return true;
  --exception
   -- when others then
   --  p_rtnstring:=p_rtnstring||v_mlhm||p_cc||'--'||ls_first_gczx||'--'||ls_first_sczx||chr(10)||'<br>';
   --   return true;
END check_result;
/

