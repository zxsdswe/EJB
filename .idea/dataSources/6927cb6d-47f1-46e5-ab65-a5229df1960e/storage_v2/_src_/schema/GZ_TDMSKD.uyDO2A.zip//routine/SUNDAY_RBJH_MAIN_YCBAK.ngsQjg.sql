create procedure sunday_rbjh_main_ycbak is
ii number(2);
begin
   II := -1;
    LOOP
     II := II + 1;
    EXIT WHEN II > 6;
     sunday_rbjh_fjk(ii);
   end loop;
end sunday_rbjh_main_ycbak;
/

