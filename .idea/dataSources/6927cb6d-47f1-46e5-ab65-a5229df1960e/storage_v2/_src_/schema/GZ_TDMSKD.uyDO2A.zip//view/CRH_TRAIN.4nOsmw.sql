create view CRH_TRAIN as
  select train_type,train_sub_type,train_group,note,belong from train_group group by (train_type,train_sub_type,train_group,note,belong) order by train_group
/

