create procedure sunday_rbjh_main is
------134
ii number(2);
begin
   II := -1;
    LOOP
     II := II + 1;
    EXIT WHEN II > 16;
     sunday_rbjh_fjk(ii);
   end loop;
end sunday_rbjh_main;
/

