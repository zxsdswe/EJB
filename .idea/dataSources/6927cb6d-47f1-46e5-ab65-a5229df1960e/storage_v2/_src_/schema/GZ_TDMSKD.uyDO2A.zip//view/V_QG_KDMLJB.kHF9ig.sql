create view V_QG_KDMLJB as
  (select distinct mlrq,rq,mlh,mlxh from k_kdjhb where to_number(mlh)>=81001 and to_number(mlh)<81999) union (select distinct mlrq,rq,mlh,mlxh from k_jjkclcrb where to_number(mlh)>=81001 and to_number(mlh)<81999)
/

