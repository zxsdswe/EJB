create FUNCTION GET_STATION (v_train_id NUMBER, v_sta_sort NUMBER)
   RETURN VARCHAR2
IS
   RESULT   VARCHAR2 (30);
BEGIN
--2009年1月1日 陈历泉 
   SELECT TRIM (sta_name)
     INTO RESULT
     FROM train_schedule
    WHERE train_id = v_train_id AND sta_sort = v_sta_sort;

   RETURN (RESULT);
END;
/

