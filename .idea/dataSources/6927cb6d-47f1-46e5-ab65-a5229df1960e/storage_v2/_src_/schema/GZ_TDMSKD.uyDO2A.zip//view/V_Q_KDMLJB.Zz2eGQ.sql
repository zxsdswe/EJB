create view V_Q_KDMLJB as
  (select distinct mlrq,rq,mlh,mlxh from k_kdjhb where to_number(mlh)>=82001 and to_number(mlh)<82999) union (select distinct mlrq,rq,mlh,mlxh from k_jjkclcrb where to_number(mlh)>=82001 and to_number(mlh)<82999)
/

