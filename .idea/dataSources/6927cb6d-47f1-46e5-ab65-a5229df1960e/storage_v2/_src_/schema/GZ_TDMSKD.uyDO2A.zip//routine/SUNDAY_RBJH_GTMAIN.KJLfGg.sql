create procedure sunday_rbjh_gtmain is
ii number(2);
-------567
begin
   II := -1;
    LOOP
     II := II + 1;
    EXIT WHEN II >14;
     sunday_rbjh_gt(ii);
   end loop;
end sunday_rbjh_gtmain;
/

