create procedure      update_station_unit is
begin
begin
for x in 
(select tsql  from 
(select 'update unit_run_point set station_name=''张家界'' where runline_id='||runline_id||' and station_name='''||station_name||'''' tsql from 
(SELECT runline_id,station_name
  FROM unit_run_point
 WHERE station_name = '大庸'
   AND runline_id IN (
          SELECT ID
            FROM unit_run_line
           WHERE  cc IN
                    ('K267',
                     'K533/6/3',
                     '1217/20',
                     '1219/8',
                     '1474',
                     '2012',
                     '2646',
                     'N566/7',
                     'N569/72',
                     'N590/1',
                     'N582/3',
                     '5379/82/79'
                    ))
UNION ALL
SELECT runline_id,station_name
  FROM unit_run_point
 WHERE station_name = '大庸'
   AND runline_id IN (
          SELECT ID
            FROM unit_run_line
           WHERE cc IN
                    ('1473',
                     '2011',
                     '2645',
                     '5381/0/1',
                     '7265',
                     '7266',
                     '7267',
                     'K268',
                     'K534/5/4',
                     'N568/5',
                     'N571/0',
                     'N584/1',
                     'N592/89'
                    )))
)) loop
begin
  execute immediate x.tsql;
  commit;
exception
WHEN OTHERS THEN
begin
   ROLLBACK;
   dbms_output.put_line('语法错-->'||to_char(x.tsql));
end;
end;
end loop;
EXCEPTION
  WHEN OTHERS THEN 
   dbms_output.put_line('语法错了哦-->');
END;

end update_station_unit;
/

