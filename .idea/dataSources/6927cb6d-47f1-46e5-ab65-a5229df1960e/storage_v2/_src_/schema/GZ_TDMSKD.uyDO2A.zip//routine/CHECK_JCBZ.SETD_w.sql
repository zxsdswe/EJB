create procedure check_jcbz(jbth in varchar2, kyfam in varchar2) is
hjc1 varchar2(30);
hsj1 varchar2(30);
cc  varchar2(30);
czm  varchar2(30);
cc1  varchar2(30);
czm1  varchar2(30);
hjc2 varchar2(30);
hsj2 varchar2(30);
hjc varchar2(30);
hsj varchar2(30);
id varchar2(30);
zx varchar2(30);
CURSOR check_cc  IS  select  base_line_id from dic_base_line  a   where   a.chartid=jbth and (a.train_num1 not like '%G%' or  a.train_num1 not like '%D%' or  a.train_num1 not like '%C%') order by  base_line_id  ;
CURSOR check_bz  IS  select  b.stn,b.node_order,b.sections,b.trainman_sections from dic_base_line_node b where base_line_id=id;

begin
  OPEN check_cc;
   LOOP
      FETCH check_cc INTO id;
      EXIT WHEN check_cc%NOTFOUND;
         OPEN check_bz;
         LOOP
            FETCH check_bz INTO czm,zx,hjc,hsj;
            EXIT WHEN check_bz%NOTFOUND;
             /*  if zx='0' then
                   hjc1:=hjc;
                   hjc2:=hjc;
                   hsj1:=hsj;
                   hsj2:=hsj;
               else
                 if hjc1<>hjc2 then
                   cc1:=czm;

                 end if;
               end if;*/




          end loop;
         close check_bz; --关闭游标
   end loop;
   close check_cc;   --关闭游标
end check_jcbz;
/

