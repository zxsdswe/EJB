create procedure ren_cc(old_cc varchar2,new_cc varchar2) as
begin


UPDATE   unit_run_line SET CC=new_cc,TRAIN_CODE=new_cc where cc=old_cc or train_code=old_cc;
UPDATE   run_line      SET CC=new_cc,TRAIN_CODE=new_cc where cc=old_cc or train_code=old_cc;
UPDATE   train_info    SET train_no=new_cc,train_code=new_cc  where train_no=old_cc or train_code=old_cc ;
UPDATE   train_schedule SET  train_no = new_cc where train_no = old_cc;
COMMIT;
end;
/

