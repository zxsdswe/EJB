create FUNCTION UPDATE_PROVINCE  
   RETURN BOOLEAN
IS
   RESULT   BOOLEAN;
BEGIN
--2009年1月3日 陈历泉
   BEGIN
      FOR c IN (select a.zm,b.station_shortname from zmzdb a, b_station b where a.zm = b.station_name)
      LOOP
         UPDATE zmzdb
            SET province = c.station_shortname
          WHERE zm = c.zm;

         --COMMIT;
      END LOOP;
      
      RESULT := TRUE;
   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         COMMIT;
         RESULT := FALSE;
   END;

   RETURN (RESULT);
END;
/

