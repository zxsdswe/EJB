create view GNCD as
  select id,bzm from gncd_test where bzm in (select bzm from run_line where run_date>'20090110')
/

