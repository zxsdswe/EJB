create function charord(v2,varchar2) return varchar2 is
  Result varchar2;
begin
  select regexp_sub(v2,'[^]+',1level,'i') from dual connect by level<=length(v2)-length(regexp_replace(v2,'',''))+1;
  return(Result);
end charord;
/

