create procedure sunday_rbjh_fjktest(dnum  in number) is
rqstr       varchar2(8);
runid    number(10);
rid      number(10);
id       number(10);
qid      number(10);
sfddid   number(10);
bid      varchar2(10);
hid      varchar2(10);
sfbz     varchar2(10);
runcc    varchar2(16);
lcc      varchar2(5);
zm       varchar2(16);
hrq      varchar2(20);
str_sfz  varchar2(20);
str_dzd  varchar2(20);
sta_sj   varchar2(20);
end_sj   varchar2(20);
sta_d   varchar2(20);
end_d   varchar2(20);
nfjkz   varchar2(20);
DAY1    varchar2(16);
DAY2    varchar2(16);
wno     varchar2(16);
lc      number(5);
lklx    varchar2(10);
lkcc    varchar2(10);
trainkind varchar2(20);
cclong  number(5);
fid     number(5);

-------读坪石口车次数据
CURSOR read_run_point_psk IS
SELECT  runline_id,station_name,arr_date||arr_time,go_date||go_time,xh    FROM run_point 
   WHERE  runline_id in (select  id from run_line where STOPFLAG = 1 
          AND  cc NOT LIKE 'X%' AND cc NOT LIKE '%DJ%'   AND cc NOT LIKE '8%' and  cc NOT LIKE '576%') 
   and ((arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj) or 
        (go_date||go_time>sta_sj and  go_date||go_time <= end_sj))  and arr_time<>'-100' 
   and (station_name ='坪石北' ) ; 

--------过程开始
begin
   

    sta_sj :='201201111800';
    end_sj :='201201121800'; 
 
 -----统计坪石口数---- 
  rid := 0;   
OPEN read_run_point_psk;
       LOOP
       FETCH read_run_point_psk INTO runid,zm,sta_d,end_d,id;
       EXIT WHEN read_run_point_psk%NOTFOUND;
        select cc,sfz,zdz,train_kind into runcc,str_sfz,str_dzd,trainkind  from run_line where id=runid ;
           if runcc ='T97'  THEN 
               nfjkz :='交出';
            END IF;
            if runcc ='T98'  THEN 
               nfjkz :='交出';
            END IF;
         id :=id + 1;
        select station_name  into nfjkz from run_point  where runline_id = runid and xh = id;--下一站
        select count(*) into id from b_station where station_name = nfjkz AND bureau_code='Q' and ((subbureau_code='63' and station_name<>'九龙') or station_name='广州西');
         if id > 0 then -----下行
            hrq:=sta_d;
            nfjkz :='交出';
         else
            hrq:=end_d;
            nfjkz :='接入';
         end if;
        if  hrq >sta_sj and hrq <= end_sj then ------时间范围内
        select station_name  into str_sfz from run_point  where runline_id = runid and xh = 1;--始发站
        select station_name  into str_dzd from run_point  where runline_id = runid and xh in (select max(xh) from run_point where runline_id = runid);
             rid := rid + 1;
              begin
 -------2011-01-11增加临客分析       
          lkcc:=substr(runcc,1,1);
          lklx:='图客';
          if lkcc ='A' or lkcc= '0' or lkcc = 'L' or lkcc = 'Y' then
           lklx:='临客';
           end if;
           cclong:=length(runcc);
            fid :=INSTR(runcc,'/',1,1);
           if cclong>= 5 and (fid =0 or fid > 5) then  
              lkcc:=substr(runcc,1,5);
              if (lkcc >='K1167' and lkcc<='K1168') or (lkcc >='K1175' and lkcc<='K1176') or (lkcc >='K2001' and lkcc<='K2198') or (lkcc >='K9123' and lkcc<='K9124') or (lkcc >'K9130' and lkcc<='K9299') then
                   lklx:='临客';
              end if;
           end if;
           fid :=INSTR(trainkind,'LK',1,1);
           if fid > 0 then 
                 lklx:='临客';
            end if;
 -------2011-01-11增加              
              
------             insert into dds_start_kc_data(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,nfjkz,rid,runid,zm,runcc,hrq,str_sfz,str_dzd,lklx,trainkind);
             EXCEPTION 
            WHEN OTHERS THEN 
               ROLLBACK;
             END;
        end if;
      commit; 
  end loop;
  CLOSE read_run_point_psk; 
  
 




end sunday_rbjh_fjktest;
/

