create procedure SUNDAY_ZZK_UPDATE_SCHEDULE(rqstr in varchar2) is
rid      number(10);
id       number(10);
qid      number(10);
bid      varchar2(10);
hid      varchar2(10);
nfjkz   varchar2(20);
statype varchar2(20);
sh    number(5);

-------读分界口车次数据//////修改株洲分界口表示2009-03-24日
CURSOR read_run_point_zzk IS
select train_id,sta_sort,sta_type from train_schedule where train_id in(select TRAIN_id from train_info 
 where plan='09-148基本图') and sta_name='株洲';
begin
-------交出接入统计------株洲口   
  OPEN read_run_point_zzk;
      LOOP
       FETCH read_run_point_zzk INTO rid,sh,statype;
       EXIT WHEN read_run_point_zzk%NOTFOUND;
         qid :=sh - 1;
         id := sh + 1;----下一站
         hid :='';
         bid :='';
      begin
        select sta_name  into nfjkz from train_schedule  where train_id = rid and STA_SORT = id;
      EXCEPTION 
        WHEN OTHERS THEN 
           nfjkz:='株洲';
       end;
        select bureau_code into hid from b_station where station_name = nfjkz;
        
        begin 
        select sta_name  into nfjkz from train_schedule  where train_id = rid and STA_SORT = qid;
        EXCEPTION 
        WHEN OTHERS THEN 
           nfjkz:='株洲';
       ROLLBACK;
       end;
        select bureau_code into bid from b_station where station_name = nfjkz ;
        if (bid='Q' AND hid='Q') or (bid<>'Q' AND hid<>'Q') then 
             statype:=substr(statype,1,1);
             if statype='4' then 
                statype:='';
               end if;
        end if;
        
        update train_schedule set sta_type=statype where  train_id = rid and sta_name='株洲';
        commit;
       
end loop;

CLOSE read_run_point_zzk; 

commit;

  
end SUNDAY_ZZK_UPDATE_SCHEDULE;
/

