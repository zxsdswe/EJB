create FUNCTION        "BACKUP_CROSS_GRAPHICS_LOG" (backupPointDate in varchar2)
return boolean
is
  type runLineLogMess is record
  (
  id run_line_log.id%type,
  user_id run_line_log.user_id%type,
  use_time run_line_log.use_time%type
  );
  type runLineLogArray is table of runLineLogMess index by binary_integer;
  lineLogMess runLineLogMess;
  lineLogArr runLineLogArray;
  type crossGraphicsLogMess is record
  (
  id cross_graphics_log.id%type,
  user_id cross_graphics_log.user_id%type,
  use_time cross_graphics_log.use_time%type
  );
  type crossGraphicsLogArray is table of crossGraphicsLogMess index by binary_integer;
  graphicsLogMess crossGraphicsLogMess;
  graphicsLogArr crossGraphicsLogArray;
  --
  i number;
  tmpNum number;
  tmpDate char(8);
  crossGraphicsId run_line_log.crossgraphics_id%type;
  --
  cursor runLineLogCur is select id,user_id,use_time from run_line_log where id in (select runline_id from run_point_log where go_date<backupPointDate);
  cursor crossGraphicsLogCur is select id,user_id,use_time from cross_graphics_log where id not in (select crossgraphics_id from run_line_log) and create_date<>'00010101' and create_date<=backupPointDate;
begin
  i:=1;
  open runLineLogCur;
  loop
    fetch runLineLogCur into lineLogMess.id,lineLogMess.user_id,lineLogMess.use_time;
    exit when runLineLogCur%notfound;
    lineLogArr(i):=lineLogMess;
    i:=i+1;
  end loop;
  close runLineLogCur;
  for i in 1..lineLogArr.count loop
    tmpNum:=0;tmpDate:='00000000';
    select max(xh) into tmpNum from run_point_log where user_id=lineLogArr(i).user_id and use_time=lineLogArr(i).use_time and runline_id=lineLogArr(i).id;
    select go_date into tmpDate from run_point_log where user_id=lineLogArr(i).user_id and use_time=lineLogArr(i).use_time and runline_id=lineLogArr(i).id and xh=tmpNum;
    if tmpDate<=backupPointDate then
      --insert into run_point_log_backup select * from run_point_log where user_id=lineLogArr(i).user_id and use_time=lineLogArr(i).use_time and runline_id=lineLogArr(i).id;
      delete from run_point_log where user_id=lineLogArr(i).user_id and use_time=lineLogArr(i).use_time and runline_id=lineLogArr(i).id;
      --
      tmpNum:=0;crossGraphicsId:=0;
      select crossgraphics_id into crossGraphicsId from run_line_log where user_id=lineLogArr(i).user_id and use_time=lineLogArr(i).use_time and id=lineLogArr(i).id;
      select count(*) into tmpNum from run_line_log where user_id=lineLogArr(i).user_id and use_time=lineLogArr(i).use_time and crossgraphics_id=crossGraphicsId;
      --
      --insert into run_line_log_backup select * from run_line_log where user_id=lineLogArr(i).user_id and use_time=lineLogArr(i).use_time and id=lineLogArr(i).id;
      delete from run_line_log where user_id=lineLogArr(i).user_id and use_time=lineLogArr(i).use_time and id=lineLogArr(i).id;
      if tmpNum=1 then
        --insert into env_parameter_log_backup select * from env_parameter_log where user_id=lineLogArr(i).user_id and use_time=lineLogArr(i).use_time and crossgraphics_id=crossGraphicsId;
        delete from env_parameter_log where user_id=lineLogArr(i).user_id and use_time=lineLogArr(i).use_time and crossgraphics_id=crossGraphicsId;
        --
        --insert into stations_list_log_backup select * from stations_list_log where user_id=lineLogArr(i).user_id and use_time=lineLogArr(i).use_time and crossgraphics_id=crossGraphicsId;
        delete from stations_list_log where user_id=lineLogArr(i).user_id and use_time=lineLogArr(i).use_time and crossgraphics_id=crossGraphicsId;
        --
        --insert into cross_cmd_log_backup select * from cross_cmd_log where user_id=lineLogArr(i).user_id and use_time=lineLogArr(i).use_time and crossgraphics_id=crossGraphicsId;
        delete from cross_cmd_log where user_id=lineLogArr(i).user_id and use_time=lineLogArr(i).use_time and crossgraphics_id=crossGraphicsId;
        --
        --insert into cross_graphics_log_backup select * from cross_graphics_log where user_id=lineLogArr(i).user_id and use_time=lineLogArr(i).use_time and id=crossGraphicsId;
        delete from cross_graphics_log where user_id=lineLogArr(i).user_id and use_time=lineLogArr(i).use_time and id=crossGraphicsId;
      end if;
      --
      commit;
    end if;
  end loop;
  --
  i:=1;
  open crossGraphicsLogCur;
  loop
    fetch crossGraphicsLogCur into graphicsLogMess.id,graphicsLogMess.user_id,graphicsLogMess.use_time;
    exit when crossGraphicsLogCur%notfound;
    graphicsLogArr(i):=graphicsLogMess;
    i:=i+1;
  end loop;
  close crossGraphicsLogCur;
  for i in 1..graphicsLogArr.count loop
    --
    --insert into env_parameter_log_backup select * from env_parameter_log where user_id=graphicsLogArr(i).user_id and use_time=graphicsLogArr(i).use_time and crossgraphics_id=graphicsLogArr(i).id;
    delete from env_parameter_log where user_id=graphicsLogArr(i).user_id and use_time=graphicsLogArr(i).use_time and crossgraphics_id=graphicsLogArr(i).id;
    --
    --insert into stations_list_log_backup select * from stations_list_log where user_id=graphicsLogArr(i).user_id and use_time=graphicsLogArr(i).use_time and crossgraphics_id=graphicsLogArr(i).id;
    delete from stations_list_log where user_id=graphicsLogArr(i).user_id and use_time=graphicsLogArr(i).use_time and crossgraphics_id=graphicsLogArr(i).id;
    --
    --insert into cross_cmd_log_backup select * from cross_cmd_log where user_id=graphicsLogArr(i).user_id and use_time=graphicsLogArr(i).use_time and crossgraphics_id=graphicsLogArr(i).id;
    delete from cross_cmd_log where user_id=graphicsLogArr(i).user_id and use_time=graphicsLogArr(i).use_time and crossgraphics_id=graphicsLogArr(i).id;
    --
    --insert into cross_graphics_log_backup select * from cross_graphics_log where user_id=graphicsLogArr(i).user_id and use_time=graphicsLogArr(i).use_time and id=graphicsLogArr(i).id;
    delete from cross_graphics_log where user_id=graphicsLogArr(i).user_id and use_time=graphicsLogArr(i).use_time and id=graphicsLogArr(i).id;
    --
    commit;
  end loop;
  --
  return true;
end backup_cross_graphics_log;
/

