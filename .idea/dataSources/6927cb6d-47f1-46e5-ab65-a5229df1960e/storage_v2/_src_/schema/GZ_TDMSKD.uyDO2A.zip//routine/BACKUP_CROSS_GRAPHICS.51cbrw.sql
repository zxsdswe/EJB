create function backup_cross_graphics
(backupPointDate in varchar2)
return boolean
is
  type runLineIdArray is table of run_line.id%type index by binary_integer;
  lineIdArr runLineIdArray;
  type crossGraphicsIdArray is table of cross_graphics.id%type index by binary_integer;
  graphicsIdArr crossGraphicsIdArray;
  --
  i number;
  tmpNum number;
  tmpDate char(8);
  crossGraphicsId run_line.crossgraphics_id%type;
  --
  cursor runLineIdCur is select id from run_line where id in (select runline_id from run_point where go_date<backupPointDate);
  --20090326--cursor crossGraphicsIdCur is select id from cross_graphics where id not in (select crossgraphics_id from run_line) and create_date<>'00010101' and create_date<=backupPointDate;
  cursor crossGraphicsIdCur is select id from cross_graphics where id not in (select crossgraphics_id from run_line) and create_date<=backupPointDate;
begin
  i:=1;
  open runLineIdCur;
  loop
    fetch runLineIdCur into lineIdArr(i);
    exit when runLineIdCur%notfound;
    i:=i+1;
  end loop;
  close runLineIdCur;
  for i in 1..lineIdArr.count loop
    --DBMS_OUTPUT.PUT_LINE('runLineId='||lineIdArr(i)||';');
    tmpNum:=0;tmpDate:='00000000';
    select max(xh) into tmpNum from run_point where runline_id=lineIdArr(i);
    select go_date into tmpDate from run_point where runline_id=lineIdArr(i) and xh=tmpNum;
    if tmpDate<=backupPointDate then
      insert into run_point_backup select * from run_point where runline_id=lineIdArr(i);
      delete from run_point where runline_id=lineIdArr(i);
      --
      tmpNum:=0;crossGraphicsId:=0;
      select crossgraphics_id into crossGraphicsId from run_line where id=lineIdArr(i);
      select count(*) into tmpNum from run_line where crossgraphics_id=crossGraphicsId;
      --
      insert into run_line_backup select * from run_line where id=lineIdArr(i);
      delete from run_line where id=lineIdArr(i);
      --
      if tmpNum=1 then
        --
        insert into env_parameter_backup select * from env_parameter where crossgraphics_id=crossGraphicsId;
        delete from env_parameter where crossgraphics_id=crossGraphicsId;
        --
        insert into stations_list_backup select * from stations_list where crossgraphics_id=crossGraphicsId;
        delete from stations_list where crossgraphics_id=crossGraphicsId;
        --
        insert into cross_cmd_backup select * from cross_cmd where crossgraphics_id=crossGraphicsId;
        delete from cross_cmd where crossgraphics_id=crossGraphicsId;
        --
        insert into cross_graphics_backup select * from cross_graphics where id=crossGraphicsId;
        delete from cross_graphics where id=crossGraphicsId;
      end if;
      --
      commit;
    end if;
  end loop;
  --
  i:=1;
  open crossGraphicsIdCur;
  loop
    fetch crossGraphicsIdCur into graphicsIdArr(i);
    exit when crossGraphicsIdCur%notfound;
    i:=i+1;
  end loop;
  close crossGraphicsIdCur;
  for i in 1..graphicsIdArr.count loop
    --
    insert into env_parameter_backup select * from env_parameter where crossgraphics_id=graphicsIdArr(i);
    delete from env_parameter where crossgraphics_id=graphicsIdArr(i);
    --
    insert into stations_list_backup select * from stations_list where crossgraphics_id=graphicsIdArr(i);
    delete from stations_list where crossgraphics_id=graphicsIdArr(i);
    --
    insert into cross_cmd_backup select * from cross_cmd where crossgraphics_id=graphicsIdArr(i);
    delete from cross_cmd where crossgraphics_id=graphicsIdArr(i);
    --
    insert into cross_graphics_backup select * from cross_graphics where id=graphicsIdArr(i);
    delete from cross_graphics where id=graphicsIdArr(i);
    --
    commit;
  end loop;
  --
  return true;
end backup_cross_graphics;


/

