create FUNCTION GET_SIMPLE_CC
  ( cc IN varchar2)
  RETURN  varchar2 IS  
   result     varchar2(255);

BEGIN 
    result := cc;
     if INSTR(cc, '/',1,1) <> 0 then
      result := substr(cc, 0, INSTR(cc, '/',1,1) - 1);
    END IF;
    RETURN result ;
END;
/

