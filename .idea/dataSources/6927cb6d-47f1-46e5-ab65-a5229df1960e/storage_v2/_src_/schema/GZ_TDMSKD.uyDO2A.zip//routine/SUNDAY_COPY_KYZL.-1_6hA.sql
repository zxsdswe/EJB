create procedure sunday_copy_kyzl(fa_tar  in varchar2,fa_src in varchar2) is
begin
       DELETE FROM train_shcedule_kyzl
               WHERE kyzl_name = fa_tar;

         COMMIT;

         INSERT INTO train_shcedule_kyzl
            SELECT fa_tar kyzl_name, a.train_no cc, a.begin_sta_name sfzm,
                   a.end_sta_name zdzm, b.sta_name zm, b.sta_sort xh,
                   b.arrive_time arr_time, b.start_time run_time,
                   b.sta_type station_type
              FROM train_info a, train_schedule b
             WHERE a.train_id = b.train_id
               AND (a.train_code NOT LIKE 'K512%') AND (a.train_code NOT LIKE 'K9114')
               AND a.PLAN = fa_src;

         COMMIT;

         DELETE FROM train_info_kyzl
               WHERE kyzl_name = fa_tar;

         COMMIT;

         INSERT INTO train_info_kyzl
            SELECT fa_tar kyzl_name, '0' jlm, '0' kind, '0' kind_jc, '0' ds,
                   train_no cc, begin_sta_name sfzm, end_sta_name zdzm,
                   '0' distance, '0' token, '0' lib_check, '0' zs, '0' ts,
                   '' begin_date, '' end_date, '0' sxx, '0' check_flag,
                   '0' fzcc, NULL multipro_flag
              FROM train_info
             WHERE (train_code NOT LIKE 'K512%') and (train_code NOT LIKE 'K9114%') AND PLAN = fa_src;

         COMMIT;

--加入L31，L32
         INSERT INTO train_shcedule_kyzl
            SELECT fa_tar kyzl_name, a.train_no cc, a.begin_sta_name sfzm,
                   a.end_sta_name zdzm, b.sta_name zm, b.sta_sort xh,
                   b.arrive_time arr_time, b.start_time run_time,
                   b.sta_type station_type
              FROM train_info a, train_schedule b
             WHERE a.train_id = b.train_id
               AND (train_code IN ('L31', 'L32', 'L49/52', 'L51/0'))
               AND a.PLAN = fa_src ;

         COMMIT;

         INSERT INTO train_info_kyzl
            SELECT fa_tar kyzl_name, '0' jlm, '0' kind, '0' kind_jc, '0' ds,
                   train_no cc, begin_sta_name sfzm, end_sta_name zdzm,
                   '0' distance, '0' token, '0' lib_check, '0' zs, '0' ts,
                   '' begin_date, '' end_date, '0' sxx, '0' check_flag,
                   '0' fzcc, NULL multipro_flag
              FROM train_info
             WHERE (train_code IN ('L31', 'L32', 'L49/52', 'L51/0'))
               AND PLAN = fa_src ;

         COMMIT;
      EXCEPTION
         WHEN OTHERS
         THEN
            DBMS_OUTPUT.put_line (SUBSTR (   'Error '
                                          || TO_CHAR (SQLCODE)
                                          || ': '
                                          || SQLERRM,
                                          1,
                                          255
                                         )
                                 );
            ROLLBACK;
 
  
end sunday_copy_kyzl;
/

