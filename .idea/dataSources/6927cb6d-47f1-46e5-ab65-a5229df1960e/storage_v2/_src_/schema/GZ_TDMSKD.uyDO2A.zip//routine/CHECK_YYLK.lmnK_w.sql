create FUNCTION CHECK_YYLK
   RETURN BOOLEAN
IS
   RESULT      BOOLEAN;
   sta_type1   VARCHAR2 (20);
BEGIN
--2009年1月9日 陈历泉
   BEGIN
      FOR c IN (SELECT   a.station_name, a.arr_time, a.go_time, a.xh,
                         a.station_type, b.cc, b.train_id, b.ID,b.run_date
                    FROM run_point a, run_line b
                   WHERE a.runline_id = b.ID
                     AND b.run_date > '20090110'
                     AND cc IN (SELECT cc
                                  FROM sta_type_yylk)
                ORDER BY b.ID, a.xh)
	LOOP

         SELECT b.sta_type
           INTO sta_type1
           FROM train_info a, train_schedule b
          WHERE a.train_id = b.train_id
            AND a.train_id = c.train_id
            AND b.sta_name = c.station_name;
         if (sta_type1<>c.station_type) then
            insert into check_yylk_log(g_id,text) values(1,c.run_date||','||c.cc||','||c.station_name||',运行线=>'||c.station_type||'<>时刻表=>'||sta_type1);
            commit;
            end if;
        end LOOP;

      RESULT := TRUE;
   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         COMMIT;
         RESULT := FALSE;
   END;

   RETURN (RESULT);
END;
/

