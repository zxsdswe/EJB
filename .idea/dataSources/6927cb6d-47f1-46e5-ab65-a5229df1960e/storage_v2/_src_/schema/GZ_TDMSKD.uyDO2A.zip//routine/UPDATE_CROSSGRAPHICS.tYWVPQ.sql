create PROCEDURE UPDATE_CROSSGRAPHICS is
begin
     update run_line set stopflag=1 Where to_date(run_date,'yyyymmdd')>=trunc(Sysdate)+40 And crossgraphics_id=20710 and cc in ('G6116','G6117','0G6117') and TO_CHAR(TO_DATE(RUN_DATE,'YYYYMMDD'),'DAY') IN ('星期五','星期六','星期日');
     update run_line set stopflag=1 where to_date(run_date,'yyyymmdd')>=trunc(Sysdate)+40 And crossgraphics_id=20710 and cc in ('0G6105')  and TO_CHAR(TO_DATE(RUN_DATE,'YYYYMMDD'),'DAY') IN ('星期一','星期二','星期三','星期四');
     update run_line set stopflag=2 where to_date(run_date,'yyyymmdd')>=trunc(Sysdate)+40 And crossgraphics_id=20713 and cc in ('0G6112','G6112','G6113','0G6113','0G6114','G6114','G6115','0G6115') and TO_CHAR(TO_DATE(RUN_DATE,'YYYYMMDD'),'DAY') IN ('星期一','星期二','星期三','星期四');
     update run_line set stopflag=2 where to_date(run_date,'yyyymmdd')>=trunc(Sysdate)+40 And crossgraphics_id=20740 and cc in ('0G6108','G6108','G6109','G6120','G6121','0G6121')  and TO_CHAR(TO_DATE(RUN_DATE,'YYYYMMDD'),'DAY') IN ('星期一','星期二','星期三','星期四');


--     update run_line set stopflag=1 Where to_date(run_date,'yyyymmdd')>Sysdate+10 And crossgraphics_id=20493 and cc in ('G6116','G6117','0G6117') and TO_CHAR(TO_DATE(RUN_DATE,'YYYYMMDD'),'DAY') IN ('星期五','星期六','星期日');
--     update run_line set stopflag=1 where to_date(run_date,'yyyymmdd')>Sysdate+10 And crossgraphics_id=20493 and cc in ('0G6105')  and TO_CHAR(TO_DATE(RUN_DATE,'YYYYMMDD'),'DAY') IN ('星期一','星期二','星期三','星期四');
--     update run_line set stopflag=2 where to_date(run_date,'yyyymmdd')>Sysdate+10 And crossgraphics_id=20496 and cc in ('0G6112','G6112','G6113','0G6113','0G6114','G6114','G6115','0G6115') and TO_CHAR(TO_DATE(RUN_DATE,'YYYYMMDD'),'DAY') IN ('星期一','星期二','星期三','星期四');
     commit;
  
end update_crossgraphics;
/

