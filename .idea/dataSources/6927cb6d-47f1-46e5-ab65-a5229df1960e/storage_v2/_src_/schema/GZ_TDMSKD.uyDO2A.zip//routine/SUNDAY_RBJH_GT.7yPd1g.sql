create procedure sunday_rbjh_gt(dnum  in number) is
rqstr    varchar2(8);
brq      varchar2(8);
runid    number(12);
rid      number(10);
id       number(10);
sfddid   number(10);
sfbz     varchar2(10);
runcc    varchar2(16);
lcc      varchar2(5);
zm       varchar2(46);
gsj      varchar2(16);
grq      varchar2(16);
hrq      varchar2(20);
str_sfz  varchar2(20);
str_dzd  varchar2(50);
sta_sj   varchar2(20);
end_sj   varchar2(20);
sta_d    varchar2(20);
end_d    varchar2(20);
nfjkz    varchar2(20);
yzzm     varchar2(20);
qcc      varchar2(16);
ii       number(5);
DAY1     varchar2(16);
DAY2     varchar2(16);
yzid     number(4);
pxh      number(4);
tkid     number(5);
kct1     number(5);
kcl1     number(5);
kch1    number(5);
kct2    number(5);
kcl2    number(5);
kch2    number(5);
kct3    number(5);
kcl3    number(5);
kch3    number(5);
kct4    number(5);
kcl4    number(5);
kch4    number(5);
kct5    number(5);
kcl5    number(5);
kch5    number(5);
zmzdhz  varchar2(16);
lc      number(5);
lklx    varchar2(10);
lkcc    varchar2(16);
trainkind varchar2(20);
cclong  number(5);
fid     number(5);
ccline  varchar2(16);
fxstr   varchar2(60);
rtid    varchar2(60);
xbid    varchar2(12);
endcc   varchar2(10);
ptid    varchar2(30);
newrq   varchar2(8);
nextid  varchar2(12);
endtime varchar2(20);
runrq   varchar2(20);
rq1     varchar2(10);
rq2     varchar2(10);
-------567
------读出发车次
CURSOR read_run_line IS
SELECT  id,cc,sfz,zdz,train_kind    FROM run_line 
   WHERE id in (select  runline_id from run_point where go_date||go_time>sta_sj and  go_date||go_time <= end_sj 
        and station_name in (select ZM from zmzdb where ljdm='Q' )  and xh=1 )
       and multipro_flag='H' and  cc NOT LIKE 'DJ%' and  cc NOT LIKE '0%' and  cc NOT LIKE '5%' AND STOPFLAg = 1
       and   (cc like 'D%' or   cc like 'G%' or   cc like 'C%' or   cc like 'S%'); 
------读终到车次
CURSOR read_run_line_zd IS
SELECT  id,cc,sfz,zdz,train_kind    FROM run_line 
   WHERE  id in (select  runline_id from run_point where arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj 
        and station_name in (select ZM from zmzdb where ljdm='Q')  and arr_time<>'-100')
        and multipro_flag='H' and  cc NOT LIKE 'DJ%' and  cc NOT LIKE '0%' and  cc NOT LIKE '5%'  AND (STOPFLAg = 1)  ; 
-------读分界口车次数据
CURSOR read_run_point_fjk IS
SELECT  runline_id,station_name,arr_date||arr_time,go_date||go_time,xh    FROM run_point 
   WHERE  runline_id in (select  id from run_line where STOPFLAG = 1 
          and multipro_flag='H' and  cc NOT LIKE 'DJ%' and  cc NOT LIKE '0%' and  cc NOT LIKE '5%'  and  cc NOT LIKE 'K%' and  cc NOT LIKE 'Z%' and  cc NOT LIKE 'T%')
   and ((arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj) or 
        (go_date||go_time>sta_sj and  go_date||go_time <= end_sj))  and arr_time<>'-100' 
   and station_name in ( '赤壁北','醴陵东','永州','诏安','郁南','怀集','新晃西','铜仁铜玉场','福田','黔江渝怀场','定南南') ; 
   
-------读区段数据2015-02-15
--CURSOR read_run_point_qd IS
--SELECT  train_id,stn,to_char(arr_time,'yyyymmddhh24mi'),to_char(dep_time,'yyyymmddhh24mi'),node_order    FROM tdmsdayplan.gb_train_line_node 
--   where    dep_train_num  not  like 'DJ%' and  dep_train_num  not  like '55%'  and  (dep_train_num   like '%D%' or dep_train_num   like '%G%' or dep_train_num   like '%C%' or dep_train_num   like '%S%')
--    and  to_char(dep_time,'yyyymmddhh24mi') > sta_sj 
--    and  to_char(dep_time,'yyyymmddhh24mi') <= end_sj 
--   and stn in (select zm from DDS_START_KCQB_ZD where dcs='N') ; 
-------读区段数据2021-09-27
--CURSOR read_run_point_qd IS
--select id,t1.station_name,to_char(arr_sj,'yyyymmddhh24mi'),to_char(go_sj,'yyyymmddhh24mi'),xh,cc,sfz,zdz,train_kind,station_name from RUN_LINE t,RUN_POINT_DETAIL t1 where run_date>=brq and run_date<=rqstr and stopflag=1 and (cc like '%G%'or  cc like '%D%' or cc like '%C%' or cc like '%S%') and
--runline_id=t.id and arr_sj>=to_date(sta_sj,'yyyymmddhh24mi') 
--and arr_sj<=to_date(end_sj,'yyyymmddhh24mi')  and  t1.station_name in (select zm from DDS_START_KCQB_ZD where dcs='N');  and (cc like '%G%'or  cc like '%D%' or cc like '%C%' or cc like '%S%')

CURSOR read_run_point_qd IS
select id,t1.station_name,to_char(arr_sj,'yyyymmddhh24mi'),to_char(go_sj,'yyyymmddhh24mi'),xh,cc,sfz,zdz,train_kind,station_name from RUN_LINE t,run_point_tdgz t1 where run_date>=brq and run_date<=rqstr and stopflag=1  and cc not like 'DJ%'  and cc not like '5%' and
runline_id=t.id and arr_sj>=to_date(sta_sj,'yyyymmddhh24mi') 
and arr_sj<=to_date(end_sj,'yyyymmddhh24mi')  and  t1.station_name in (select zm from DDS_START_KCQB_ZD where dcs='N');


-------读动车段进出库数据2016-02-10
CURSOR read_run_point_dc IS
SELECT  train_id,stn,to_char(arr_time,'yyyymmddhh24mi'),to_char(dep_time,'yyyymmddhh24mi'),node_order    FROM tdmsdayplan.gb_train_line_node 
   where    to_char(dep_time,'yyyymmddhh24mi') > sta_sj 
    and  to_char(dep_time,'yyyymmddhh24mi') <= end_sj 
   and stn in ('广州动车段','长沙动车所武广场','深圳动车运用所') ; 

CURSOR read_run_point_sqq IS
SELECT  train_id,stn,to_char(arr_time,'yyyymmddhh24mi'),to_char(dep_time,'yyyymmddhh24mi'),node_order    FROM tdmsdayplan.gb_train_line_node 
   where    to_char(dep_time,'yyyymmddhh24mi') > sta_sj 
    and  to_char(dep_time,'yyyymmddhh24mi') <= end_sj 
   and stn in ('盐步所') ; 
 
-----读出发车次分析数据----
CURSOR read_dds_start_kc_data IS
SELECT  distinct(station)    FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz order by station; 
--------过程开始
begin
  


    select to_char(sysdate ,'yyyymmdd') into newrq  from dual;
    select to_char(sysdate + dnum +1,'yyyymmdd') into rqstr  from dual;
    select to_char(sysdate + dnum,'yyyymmdd') into sta_sj  from dual;
--   rqstr:='20150129';
--    sta_sj:='20150128';
    DAY1 :=sta_sj;
    DAY2 :=rqstr;
    
    sta_d :=sta_sj;
    end_d :=end_sj;
--    sta_sj :=sta_sj||'1800';
--    end_sj :=rqstr||'1800'; 
    sta_sj :=sta_sj||'0000';
    end_sj :=rqstr ||'0000';
    select to_char(sysdate + dnum,'yyyymmdd') into rqstr  from dual;
    rq1:=rqstr;
    select to_char(sysdate + dnum -1,'yyyymmdd') into runrq  from dual;
    rq2:=runrq;
    delete RUN_POINT_tdgz ;
    commit;
    insert into  run_point_tdgz  select t1.runline_id, t1.station_name,arr_sj,go_sj,xh,arr_date,arr_time  from tdmskd.RUN_POINT_DETAIL t1,run_line a  where run_date in (rq1,rq2) and  a.multipro_flag='H'  and id=t1.runline_id and t1.arr_date=rqstr and t1.arr_time>='0000' and  t1.arr_time<='2359';
    commit;
    insert into run_point_tdgz   select runline_id, station_name,arr_sj,go_sj,xh,arr_date,arr_time from RUN_POINT t,run_line a where run_date in (rq1,rq2) and a.multipro_flag='H'  and id=t.runline_id  and arr_date=rqstr and runline_id not in (select runline_id from RUN_POINT_TDGZ t  where arr_date=rqstr) and run_flag<>-1;
    commit;
    
    
    
    
    select to_char(sysdate + dnum -1,'yyyymmdd') into brq  from dual;
    delete from dds_start_kc_data_gt where rq = rqstr;
    delete from dds_start_kc_tj_gt where rq = rqstr;
    delete from dds_start_kc_tj_zlwgt where rq = rqstr;
    commit;
    rid := 0;
  OPEN read_run_line;
       LOOP
       FETCH read_run_line INTO runid,runcc,str_sfz,str_dzd,trainkind;
       EXIT WHEN read_run_line%NOTFOUND;
 ---      select count(*) into id  from run_line where cc=rqstr;
      -----2022-04-05 select station_name,go_date,go_time  into zm,grq,gsj  from run_point where runline_id=runid and xh=1;
      
       select station_name,go_date,go_time  into zm,grq,gsj from (select station_name,go_date,go_time from run_point where runline_id=runid order by xh) where  rownum=1;
       
       hrq:=grq||gsj;
       rid := rid + 1;
       lcc := substr(runcc,1,1);
       if runcc ='S7884' then 
          runcc :='S7884';
       end if;
       
       select count(*) into sfddid from dds_start_kc_data_qj where (end_station = zm AND start_station=str_dzd) or (end_station = str_dzd AND start_station=zm);
        
        
        
        if (sfddid>0 and lcc ='0') or runcc ='57001' or runcc ='57002'  THEN 
           str_dzd:='不写';
        ELSE
          if zm='邵阳娄邵场' then
             
              lkcc:=substr(runcc,1,1);  
          end if;
-------2011-01-11增加       
          lkcc:=substr(runcc,1,1);
          lklx:='图客';
          if lkcc ='A' or lkcc= '0' or lkcc = 'L' or lkcc = 'Y' then
           lklx:='临客';
           end if;
            fid :=INSTR(runcc,'/',1,1);
            ccline:=runcc;
           if fid> 0 then
              ccline:=substr(runcc,1,fid - 1); 
           end if;
           cclong:=length(ccline);
           if cclong>= 5  then  
              lkcc:=ccline;
              if  (lkcc >='G4001' and lkcc<='G4998') or (lkcc >='G9001' and lkcc<='G9998') or (lkcc >='C9001' and lkcc<='C9998')  or (lkcc >'D4001' and lkcc<='D4998') or (lkcc >'D9001' and lkcc<='D9998') or (lkcc >'K5001' and lkcc<='K6998') then
                   lklx:='临客';
              end if;
           end if;
 -------2015-01-01增加 
             qcc:=runcc;
           if fid > 0 then 
              qcc:=substr(runcc,1,fid - 1);
           end if;
           if qcc >='3001' and qcc<='3998' and length(qcc)=4 then 
              lklx:='临客';
           end if;
           fid :=INSTR(trainkind,'LK',1,1);
           if fid > 0 then 
              --   lklx:='临客';
              fid:=fid;
            end if;
      
           insert into dds_start_kc_data_gt(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,'始发',rid,runid,zm,runcc,hrq,zm,str_dzd,lklx,trainkind);

         END IF;
      commit;
      end loop;
      CLOSE read_run_line;
 -------终到数据统计-------  
 rid := 0;   
OPEN read_run_line_zd;
       LOOP
       FETCH read_run_line_zd INTO runid,runcc,str_sfz,str_dzd,trainkind;
       EXIT WHEN read_run_line_zd%NOTFOUND;
        select station_name,arr_date,arr_time into zm,grq,gsj  from run_point where runline_id=runid and xh in (
        select max(xh) from run_point where runline_id = runid ) ;
        id :=0;
        zmzdhz :=zm;
        select count(*) into id from zmzdb where zm = zmzdhz AND ljdm='Q';
        if zm ='桂林北' then 
          id:=id;
        end if;
        
        select station_name into str_sfz from run_point where runline_id = runid and xh=1;
        
        hrq:=grq||gsj;
        if id > 0 and hrq >sta_sj and hrq <= end_sj then 
            rid := rid + 1;
 --------dds_start_kc_data_gt_qj在不在统计区段内的数
          lcc := substr(runcc,1,1);
          select count(*) into sfddid from dds_start_kc_data_qj where (end_station = zm AND start_station=str_sfz) or (end_station = str_sfz AND start_station=zm);
             if (sfddid>0 and lcc ='0') or runcc ='57001' or runcc ='57002' THEN 
                str_sfz:='不写';
              else
-------2011-01-11增加临客分析       
          lkcc:=substr(runcc,1,1);
          lklx:='图客';
          if lkcc ='A' or lkcc= '0' or lkcc = 'L' or lkcc = 'Y' then
           lklx:='临客';
           end if;
           fid :=INSTR(runcc,'/',1,1);
            ccline:=runcc;
           if fid> 0 then
              ccline:=substr(runcc,1,fid - 1); 
           end if;
           cclong:=length(ccline);

           if cclong>= 5  then  
              lkcc:=ccline;
              if  (lkcc >='G4001' and lkcc<='G4998') or (lkcc >='G9001' and lkcc<='G9998') or (lkcc >='C9001' and lkcc<='C9998')  or (lkcc >'D4001' and lkcc<='D4998') or (lkcc >'D9001' and lkcc<='D9998') or (lkcc >'K5001' and lkcc<='K6998') then
                   lklx:='临客';
              end if;
           end if;
 -------2015-01-01增加 
           qcc:=runcc;
           if fid > 0 then 
              qcc:=substr(runcc,1,fid - 1);
           end if;
           if qcc >='3001' and qcc<='3998' and length(qcc)=4 then 
              lklx:='临客';
           end if;
             fid :=INSTR(trainkind,'LK',1,1);
            if fid > 0 then 
           ---    lklx:='临客';
           ----2021-01-25
            --    fid := 0;
            fid:=fid;
             end if;
      
                 insert into dds_start_kc_data_gt(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,'终到',rid,runid,zm,runcc,hrq,str_sfz,zm,lklx,trainkind);

             end if;
        end if;
      commit; 
  end loop;
  CLOSE read_run_line_zd;
  -------交出接入统计
  rid := 0;   
OPEN read_run_point_fjk;
       LOOP
       FETCH read_run_point_fjk INTO runid,zm,sta_d,end_d,id;
       EXIT WHEN read_run_point_fjk%NOTFOUND;
        select cc,sfz,zdz,train_kind into runcc,str_sfz,str_dzd,trainkind  from run_line where id=runid ;
        if runid='27705116' then 
             tkid:=id;
         end if;
        
         tkid:=id;
         pxh:=id;
         id :=id + 1;
         lc:=0;
         yzid:=tkid;
       if zm='铜仁铜玉场' and id > 2 then 
            id :=id - 1; 
        end if;
       
        
        if zm='福田' and (id = 3) then
              cclong:=length(runcc);
              if runcc='G418' then 
                 runcc:=runcc;
              end if; 
              lkcc:=substr(runcc,cclong,1);
              if lkcc='0' or lkcc='2' or lkcc='4' or lkcc='6' or lkcc='8' then 
                  id :=id - 1; 
              end if;
        end if;
        -------2023年03-19修改,为福田
       cclong:=length(runcc);
       lkcc:=substr(runcc,cclong,1); 
       if zm ='福田' and (lkcc='0' or lkcc='2' or lkcc='4' or lkcc='6' or lkcc='8') then
               select count(*)  into lc from run_point  where runline_id = runid and station_name = '香港西九龙' and run_flag<>-1;
       else     
               select count(*)  into lc from run_point  where runline_id = runid and xh = id and run_flag<>-1;
       end if;
       
       if lc=0 and zm='黔江渝怀场' then 
           lc := 1;
           id :=id - 1;
       end if;
       -------2022-02-10日增加分界的始发终到不统计
        if zm=str_sfz and (zm='怀集' or zm ='郁南') then 
                lc:=0;    
        end if;
       
       
       
   if lc > 0 then ------有一个站
        select station_name  into nfjkz from run_point  where runline_id = runid and xh = id and run_flag<>-1;
        select count(*) into id from zmzdb where zm = nfjkz AND ljdm='Q' ;
       ------结束时间
        hrq:=end_d;
         
       ----- select station_name  into str_sfz from run_point  where runline_id = runid and xh = 1;
        
        select station_name into str_sfz from (select * from run_point where   runline_id=runid and run_flag<>-1 order by xh) where rownum=1;
        
        
        select station_name  into str_dzd from run_point  where runline_id = runid and xh in (select max(xh) from run_point where runline_id = runid);
          
          if id > 0 then 
             nfjkz :='接入';
             else
             nfjkz :='交出';
          end if;
  ------------塘口的特殊处理方法          
          if  zm='塘口' then 
              if tkid > 7 then
                   nfjkz :='接入';
               else
                   nfjkz :='交出';
               end if;
               if str_dzd ='徐闻' or str_dzd='海口' or str_dzd='三亚' then 
                    nfjkz:='接入';
               else
                    nfjkz:='交出';
               end if;
          end if;
------------永州的特殊处理方法          
          if  zm='永州' then 
            select count(*)  into tkid from run_point  where runline_id = runid and station_name in ('楠木塘','滩头湾');
              if tkid > 0 then
                   nfjkz :='通过';
               end if;
          end if;

           if  nfjkz ='接入'  then  
              if  (ZM  = '滩头湾' or  ZM = '株洲' or  ZM = '琥市' or  ZM = '楠木塘' or  ZM = '楠木塘' or  ZM = '珠玑巷') then
                   hrq:=sta_d;
                else
                   hrq:=end_d;
                end if;
           end if;
          if  nfjkz ='交出'  then  
              if  (ZM  = '滩头湾' or  ZM = '株洲' or  ZM = '琥市' or  ZM = '楠木塘' or  ZM = '楠木塘' or  ZM = '珠玑巷') then
                  hrq:=end_d;
                else
                  hrq:=sta_d;
                end if;
           end if;
         if  hrq >sta_sj and hrq <= end_sj then
               rid := rid + 1;
 -------2011-01-11增加临客分析 
 --         if runcc='T77' or runcc='K25'  or runcc='K26' then
 --            lklx:='图客';
 --         end if;      
          lkcc:=substr(runcc,1,1);
          lklx:='图客';
          if lkcc ='A' or lkcc= '0' or lkcc = 'L' or lkcc = 'Y' then
           lklx:='临客';
          end if;
            fid :=INSTR(runcc,'/',1,1);
            ccline:=runcc;
           if fid> 0 then
              ccline:=substr(runcc,1,fid - 1); 
           end if;
           cclong:=length(ccline);
           if cclong>= 5  then  
              lkcc:=ccline;
              if  (lkcc >='G4001' and lkcc<='G4998') or (lkcc >='G9001' and lkcc<='G9998') or (lkcc >='C9001' and lkcc<='C9998')  or (lkcc >'D4001' and lkcc<='D4998') or (lkcc >'D9001' and lkcc<='D9998') or (lkcc >'K5001' and lkcc<='K6998') then
                   lklx:='临客';
              end if;
           end if;
           qcc:=runcc;
           if fid > 0 then 
              qcc:=substr(runcc,1,fid - 1);
           end if;
           if qcc >='3001' and qcc<='3998' and length(qcc)=4 then 
              lklx:='临客';
           end if;
           fid :=INSTR(trainkind,'LK',1,1);
           if fid > 0 then 
           ---      lklx:='临客';
           -- fid := 0;
           fid:=fid;
            end if;
 -------2014-01-17增加 
         if  zm='塘口' then
             select count(*)  into tkid from run_point  where runline_id = runid and station_name in ('茂名');
             if tkid < 1 then
                select count(*)  into tkid from run_point  where runline_id = runid and station_name in ('茂名东'); 
                if tkid > 0 then
                   select xh into tkid from run_point where runline_id = runid and station_name in ('茂名东');
                   if pxh> tkid then 
                      yzzm :='交出';
                   else
                      yzzm :='接入';
                    end if;
                insert into dds_start_kc_data_gt(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,yzzm,rid,runid,'塘口北',runcc,hrq,str_sfz,str_dzd,lklx,trainkind);
             end if;
             end if;
          end if;
            if zm ='永州' then            
               if nfjkz='接入' and str_sfz='永州' then 
                 nfjkz:='始发1';
               end if;
               if nfjkz='交出' and str_dzd='永州' then
                  nfjkz:='终到1' ;
                end if;
                if (nfjkz='接入' ) or (nfjkz='交出' ) then
                      tkid:=yzid - 1;
                      yzid:=yzid + 1;
                  select count(*) into yzid from zmzdb where  ljdm<>'Q' and zm in( select station_name from run_point  where runline_id = runid and xh=yzid);
                  select count(*) into tkid from zmzdb where  ljdm<>'Q' and zm in( select station_name from run_point  where runline_id = runid and xh=tkid);
                  if yzid=0 and tkid=0 then 
                     nfjkz:='永州内' ;
                  end if; 
               end if;
                
             end if; 
             
             if zm ='铜仁铜玉场' then 
                 if   str_sfz='铜仁铜玉场' then

                     nfjkz:='交出';
                 else
                     nfjkz:='接入' ;
                  end if;

             end if;
             
             if zm='福田' and nfjkz='接入' and str_sfz<>'香港西九龙' then
                 nfjkz:='分界站发';
             end if;
             
             if zm='福田' and nfjkz='交出' and str_dzd<>'香港西九龙' then
                 nfjkz:='分界站发';
             end if;
             
             insert into dds_start_kc_data_gt(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,nfjkz,rid,runid,zm,runcc,hrq,str_sfz,str_dzd,lklx,trainkind);

       end if;
      commit; 
   ----else
       ---- if zm ='铜仁铜玉场' then
       ----      nfjkz:='接入' ;
       ---      insert into dds_start_kc_data_gt(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,nfjkz,rid,runid,zm,runcc,hrq,str_sfz,str_dzd,lklx,trainkind);
       --- end if
      
  end if;
  
  end loop;
  
  CLOSE read_run_point_fjk;
  
-----------区段统计  
  
 rid := 0;   
OPEN read_run_point_qd;
       LOOP
       FETCH read_run_point_qd INTO runid,zm,sta_d,end_d,id,runcc,str_sfz,str_dzd,trainkind,ptid;
       EXIT WHEN read_run_point_qd%NOTFOUND;
------       select train_num,sfz,zdz,stat_kind,pt_id  into runcc,str_sfz,str_dzd,trainkind,ptid  from tdmsdayplan.gb_train_line where train_id=runid ;
       endtime:='';
       nextid:='';

     if runid='31656645' or runid='31661409' then 
       nfjkz:='过车';
     end if;
       --------上下行
       fid := id + 1;
       zmzdhz:='';
       begin
       -------- 
       -------select station_name into  zmzdhz from tdmskd.RUN_POINT_DETAIL where runline_id=runid and xh = fid; 
       select station_name into  zmzdhz from tdmskd.run_point_tdgz where runline_id=runid and xh = fid; 
       EXCEPTION 
        WHEN OTHERS THEN 
            zmzdhz:='';  
       ROLLBACK;
       end;
       yzzm:='';
       fid :=id - 1;
       begin
       ------select stn into  yzzm from tdmsdayplan.gb_train_line_node where train_id=runid and node_order = fid;
       ------select station_name into  yzzm from tdmskd.RUN_POINT_DETAIL where runline_id=runid and xh = fid;
       select station_name into  yzzm from tdmskd.run_point_tdgz where runline_id=runid and xh = fid;
       EXCEPTION
        WHEN OTHERS THEN
             yzzm:='';
           ROLLBACK;
        end;
       fxstr:=yzzm || zm ||  zmzdhz;
       begin
       select fx into  nfjkz from dds_start_kc_gtfx where jlm=fxstr ; 
       EXCEPTION 
        WHEN OTHERS THEN 
           ROLLBACK;
           insert into dds_start_kc_gtfx(jlm,fx,zm,rid) values (fxstr,'过车x',zm,runid);
           commit;
       end; 
       
          lkcc:=substr(runcc,1,1);
          lklx:='图客';
          if lkcc ='A' or lkcc= '0' or lkcc = 'L' or lkcc = 'Y' then
           lklx:='临客';
          end if;
            fid :=INSTR(runcc,'/',1,1);
            ccline:=runcc;
           if fid> 0 then
              ccline:=substr(runcc,1,fid - 1); 
           end if;
           cclong:=length(ccline);
           if cclong>= 5  then  
              lkcc:=ccline;
              if  (lkcc >='G4001' and lkcc<='G4998') or (lkcc >='G9001' and lkcc<='G9998') or (lkcc >='C9001' and lkcc<='C9998')  or (lkcc >'D4001' and lkcc<='D4998') or (lkcc >'D9001' and lkcc<='D9998') or (lkcc >'K5001' and lkcc<='K6998') then
                   lklx:='临客';
              end if;
           end if;
           qcc:=runcc;
           if fid > 0 then 
              qcc:=substr(runcc,1,fid - 1);
           end if;
           if qcc >='3001' and qcc<='3998' and length(qcc)=4 then 
              lklx:='临客';
           end if;
       
       
       
        fid :=INSTR(trainkind,'LK',1,1);
        if fid > 0 then 
       ---          lklx:='临客';
         ---      fid := 0;
         fid:=fid;
        end if;
       hrq:=end_d;
       if nfjkz<>'过车x' then  
           insert into dds_start_kc_data_gt(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind,pt_id,endsj,endid) values (rqstr,nfjkz,rid,runid,zm,runcc,hrq,str_sfz,str_dzd,lklx,trainkind,ptid,endtime,nextid);
           commit;
       end if;
 end loop;
  
  CLOSE read_run_point_qd;

----------区段过车统计完成


-------2016-02-12增加动车段统计----刘伟才
---    sta_sj :=substr(day1,1,4)||'-' ||substr(day1,5,2) ||'-' ||substr(day1,7,2)||' 00:00';
---    end_sj :=substr(day2,1,4)||'-' ||substr(day2,5,2) ||'-' ||substr(day2,7,2)||' 00:00';
 
OPEN read_run_point_dc;
       LOOP
       FETCH read_run_point_dc INTO runid,zm,sta_d,end_d,id;
       EXIT WHEN read_run_point_dc%NOTFOUND;
       select train_num,sfz,zdz,stat_kind into runcc,str_sfz,str_dzd,trainkind  from tdmsdayplan.gb_train_line where train_id=runid ;
     if runid='10569938' then 
       nfjkz:='过车';
     end if;
       --------上下行
       fid := id + 1;
       zmzdhz:='';
       begin
       select stn into  zmzdhz from tdmsdayplan.gb_train_line_node where train_id=runid and node_order = fid; 
       EXCEPTION 
        WHEN OTHERS THEN 
            zmzdhz:='';  
       ROLLBACK;
       end;
       yzzm:='';
       fid :=id - 1;
       begin
       select stn into  yzzm from tdmsdayplan.gb_train_line_node where train_id=runid and node_order = fid;
       EXCEPTION
        WHEN OTHERS THEN
             yzzm:='';
           ROLLBACK;
        end;
       fxstr:=yzzm || zm ||  zmzdhz;
       begin
       select fx into  nfjkz from dds_start_kc_gtfx where jlm=fxstr ; 
       EXCEPTION 
        WHEN OTHERS THEN 
           ROLLBACK;
           insert into dds_start_kc_gtfx(jlm,fx,zm,rid) values (fxstr,'过车x',zm,runid);
           commit;
       end; 
       
          lkcc:=substr(runcc,1,1);
          lklx:='图客';
          if lkcc ='A' or lkcc= '0' or lkcc = 'L' or lkcc = 'Y' then
           lklx:='临客';
          end if;
            fid :=INSTR(runcc,'/',1,1);
            ccline:=runcc;
           if fid> 0 then
              ccline:=substr(runcc,1,fid - 1); 
           end if;
           cclong:=length(ccline);
           if cclong>= 5  then  
              lkcc:=ccline;
              if  (lkcc >='G4001' and lkcc<='G4998') or (lkcc >='G9001' and lkcc<='G9998') or (lkcc >='C9001' and lkcc<='C9998')  or (lkcc >'D4001' and lkcc<='D4998') or (lkcc >'D9001' and lkcc<='D9998') or (lkcc >'K5001' and lkcc<='K6998') then
                   lklx:='临客';
              end if;
           end if;
           qcc:=runcc;
           if fid > 0 then 
              qcc:=substr(runcc,1,fid - 1);
           end if;
           if qcc >='3001' and qcc<='3998' and length(qcc)=4 then 
              lklx:='临客';
           end if;
       
       
       
        fid :=INSTR(trainkind,'LK',1,1);
        if fid > 0 then 
           ----      lklx:='临客';
        ---   fid := 0;
        fid:=fid;
        end if;
       hrq:=end_d;
       if nfjkz<>'过车x' then 
         insert into dds_start_kc_data_gt(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,nfjkz,rid,runid,zm,runcc,hrq,str_sfz,str_dzd,lklx,trainkind);
         commit;
       end if;
 end loop;
  
  CLOSE read_run_point_dc;
  
 --------------三眼桥统计方法 
  
  
OPEN read_run_point_sqq;
       LOOP
       FETCH read_run_point_sqq INTO runid,zm,sta_d,end_d,id;
       EXIT WHEN read_run_point_sqq%NOTFOUND;
         select train_num,sfz,zdz,stat_kind,route_id into runcc,str_sfz,str_dzd,trainkind,rtid  from tdmsdayplan.gb_train_line where train_id=runid ;
       begin
       select zm_xbid into xbid from tdmsxd2.xd_routejyz t where r_num in (select xd_rnum from tdmsdayplan.dic_route_map_xd t where route_id=rtid)and jyz='盐步所';
       EXCEPTION
        WHEN OTHERS THEN
            xbid:='问';  
       ROLLBACK;
       end;
        
       if xbid='19485' then 
          xbid:='_南广';
       else
          if xbid<>'问' then 
              xbid:='_贵广' ;
          end if;
       end if;
       
       --------上下行
       fid := id + 1;
       zmzdhz:='';
       begin
       select stn into  zmzdhz from tdmsdayplan.gb_train_line_node where train_id=runid and node_order = fid; 
       EXCEPTION 
        WHEN OTHERS THEN 
            zmzdhz:='';  
       ROLLBACK;
       end;
       yzzm:='';
       fid :=id - 1;
       begin
       select stn into  yzzm from tdmsdayplan.gb_train_line_node where train_id=runid and node_order = fid;
       EXCEPTION
        WHEN OTHERS THEN
             yzzm:='';
           ROLLBACK;
        end;
       fxstr:=yzzm || zm ||  zmzdhz;
       begin
       select fx into  nfjkz from dds_start_kc_gtfx where jlm=fxstr ; 
       EXCEPTION 
        WHEN OTHERS THEN 
           ROLLBACK;
           insert into dds_start_kc_gtfx(jlm,fx,zm,rid) values (fxstr,'过车x',zm,runid);
           commit;
       end; 
       
          lkcc:=substr(runcc,1,1);
          lklx:='图客';
          if lkcc ='A' or lkcc= '0' or lkcc = 'L' or lkcc = 'Y' then
           lklx:='临客';
          end if;
            fid :=INSTR(runcc,'/',1,1);
            ccline:=runcc;
           if fid> 0 then
              ccline:=substr(runcc,1,fid - 1); 
           end if;
           cclong:=length(ccline);
           if cclong>= 5  then  
              lkcc:=ccline;
              if  (lkcc >='G4001' and lkcc<='G4998') or (lkcc >='G9001' and lkcc<='G9998') or (lkcc >='C9001' and lkcc<='C9998')  or (lkcc >'D4001' and lkcc<='D4998') or (lkcc >'D9001' and lkcc<='D9998') or (lkcc >'K5001' and lkcc<='K6998') then
                   lklx:='临客';
              end if;
           end if;
           qcc:=runcc;
           if fid > 0 then 
              qcc:=substr(runcc,1,fid - 1);
           end if;
           if qcc >='3001' and qcc<='3998' and length(qcc)=4 then 
              lklx:='临客';
           end if;
       
       
       
        fid :=INSTR(trainkind,'LK',1,1);
        if fid > 0 then 
         ----        lklx:='临客';
        --- fid := 0;
        fid:=fid;
        end if;
       hrq:=end_d;
       if nfjkz<>'过车x' then 
         rtid := zm||xbid;
         insert into dds_start_kc_data_gt(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind) values (rqstr,nfjkz,rid,runid,rtid,runcc,hrq,str_sfz,str_dzd,lklx,trainkind);
         commit;
       end if;
 end loop;
  
  CLOSE read_run_point_sqq;  

----------区段过车统计完成









  
 

  
----统计出发情况分析-----
 delete from dds_start_kc_tj_gt where rq = rqstr;
 COMMIT;
 
ii := 0;
loop 
ii := ii+ 1;
if ii = 1 then 
 sfbz:='始发';
end if;
if ii = 2 then 
 sfbz:='终到';
end if;
if ii = 3 then 
 sfbz:='接入';
end if;
if ii = 4 then 
 sfbz:='交出';
end if;


if ii = 5 then 
 sfbz:='过车上';
end if;

if ii = 6 then 
 sfbz:='过车下';
end if;




EXIT WHEN ii > 6 ;
rid := 0;  
kct1 :=0;
kcl1  :=0;
kch1  :=0;
kct2  :=0;
kcl2  :=0;
kch2   :=0;
kct3  :=0;
kcl3   :=0;
kch3   :=0;
kct4  :=0;
kcl4   :=0;
kch4   :=0;
kct5   :=0;
kcl5   :=0;
kch5  :=0;

OPEN read_dds_start_kc_data;
       LOOP
       FETCH read_dds_start_kc_data INTO ZM;
       EXIT WHEN read_dds_start_kc_data%NOTFOUND;
       ----第一阶段
       sta_sj := DAY2||'0000' ;
       end_sj := DAY2||'0600';
        SELECT  count(*) into kct1 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx ='图客' and      tsj >sta_sj and tsj <= end_sj;
        SELECT  count(*) into kcl1 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx ='临客' and   tsj >sta_sj and tsj <= end_sj ;
           kch1:=kct1+kcl1; 
       -----第二阶段
        sta_sj := DAY2||'0600' ;
        end_sj := DAY2||'1200';
        SELECT  count(cc) into kct2 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx ='图客' and     tsj >sta_sj and tsj <=end_sj;
        SELECT  count(cc) into kcl2 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                        lx ='临客' AND   tsj >sta_sj and tsj <=end_sj;
           kch2:=kct2+kcl2;    
       ------第三阶段
       sta_sj := DAY2||'1200' ;
       end_sj := DAY2||'1800';
        SELECT  count(cc) into kct3 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                     lx ='图客' AND        tsj >sta_sj and tsj <=end_sj;
        SELECT  count(cc) into kcl3 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                        lx ='临客' AND    tsj >sta_sj and tsj <=end_sj;
           kch3:=kct3+kcl3;     
         ---第四阶段
         sta_sj := DAY2||'1800' ;
         end_sj := DAY1||'0000';
        SELECT  count(cc) into kct4 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx ='图客' AND    tsj >sta_sj and tsj <=end_sj;
        SELECT  count(cc) into kcl4 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx ='临客' AND  tsj >sta_sj and tsj <=end_sj;
             kch4:=kct4+kcl4; 
             kct5:=kct1+kct2+kct3+kct4;
             kcl5:=kcl1+kcl2+kcl3+kcl4;
             kch5:=kch1+kch2+kch3+kch4;              
             rid := rid + 1;
             insert into dds_start_kc_tj_gt values (rqstr,sfbz,rid,zm,kct1,kcl1,kch1,kct2,kcl2,kch2,kct3,kcl3,kch3,kct4,kcl4,kch4,kct5,kcl5,kch5,1);
        
      commit; 
  end loop;
CLOSE read_dds_start_kc_data;
end loop;


----统计出发情况分析(按调度所统计)-----
delete from dds_start_kc_tj_zlwgt where rq = rqstr;
COMMIT;
 
ii := 0;
loop 
ii := ii+ 1;
if ii = 1 then 
 sfbz:='始发';
end if;
if ii = 2 then 
 sfbz:='终到';
end if;
if ii = 3 then 
 sfbz:='接入';
end if;
if ii = 4 then 
 sfbz:='交出';
end if;

if ii = 5 then 
 sfbz:='过车上';
end if;

if ii = 6 then 
 sfbz:='过车下';
end if;

EXIT WHEN ii > 6 ;
rid := 0;  
kct1 :=0;
kct2 :=0;
kct3 :=0;
kct4 :=0;
kct5 :=0;
 
OPEN read_dds_start_kc_data;
       LOOP
       FETCH read_dds_start_kc_data INTO ZM;
       EXIT WHEN read_dds_start_kc_data%NOTFOUND;
       sta_sj := DAY1||'0000' ;
       end_sj := DAY2||'0000';
       
       ----图定客车
        SELECT  count(cc) into kct1 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx='图客' and   tsj >sta_sj and tsj <= end_sj;
        -----临客-----
        
        SELECT  count(cc) into kct2 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                        lx='临客' and  cc not like '0%' and  tsj >sta_sj and tsj <= end_sj ;
          ------车底----------  
                    
         SELECT  count(cc) into kct3 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                         lx='临客'  and  cc  like '0%'  and   tsj >sta_sj and tsj <= end_sj ;              
                     
             kct4:=kct1+kct2+kct3;         
             rid := rid + 1;
             insert into dds_start_kc_tj_zlwgt values (rqstr,sfbz,rid,zm,kct1,kct2,kct3,kct4,kct5);
        
      commit; 
  end loop;
CLOSE read_dds_start_kc_data;
end loop;
  delete from  DDS_START_KCGT_TIME where tren='高速铁路';
  insert into  DDS_START_KCGT_TIME select '高速铁路',to_char(sysdate ,'yyyy-mm-dd hh24:mi')   from dual;
commit;
end sunday_rbjh_gt;
/

