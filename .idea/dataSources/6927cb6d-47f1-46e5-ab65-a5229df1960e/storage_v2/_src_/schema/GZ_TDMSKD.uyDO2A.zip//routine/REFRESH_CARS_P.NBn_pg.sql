create procedure refresh_cars_p
AS
BEGIN
  if synch_cars(10) then
    insert into users_log(log_time,user_id,note,name,logtype) values(sysdate,'DB','客车确报编组数据同步刷新','OracleDB','KctjCarsSynch');
    commit;
  end if;
  --整理
  delete from car_marshalling_head where to_date(szorg_time,'yyyymmddhh24miss')<(select sysdate-60 from dual);
  commit;
  delete from car_marshalling_head where valid_flag='1';
  insert into users_log(log_time,user_id,note,name,logtype) values(sysdate,'DB','客车确报编组过期数据删除','OracleDB','KctjCarsSynch');
  commit;
END;


/

