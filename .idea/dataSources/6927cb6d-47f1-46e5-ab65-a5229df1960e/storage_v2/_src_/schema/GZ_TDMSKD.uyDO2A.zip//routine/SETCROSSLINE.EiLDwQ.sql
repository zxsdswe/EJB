create procedure      setCrossLine(cid integer) as
  pid integer;
  nid integer; 
begin
  pid:=-1;
  nid:=-1;
for c in (
select * from unit_run_line where crossgraphics_id=cid order by id
) loop
  begin
    update unit_run_line 
    set 
      prerunline_id =pid
    where id = c.id ;
      pid:=c.id;
  end;
end loop;

for c in (
select * from unit_run_line where crossgraphics_id=cid order by id desc
) loop
  begin
    update unit_run_line 
    set 
      nextrunline_id=nid
    where id = c.id ;
      nid:=c.id;
  end;
end loop;
  
  commit;

end;
/

