create PROCEDURE "CREATE_KDJHB" (
  p_mlrq in sgml.rq%TYPE,
  p_mlh in sgml.mlh%TYPE,
  cmd_begin in number,
  cmd_end in number,
  p_rtnstring out varchar2,
  v_successful out varchar2) IS
  /*定义游标*/
  cursor c_cgkdl is select distinct rq,mlh,mlxh,qsrq,zzrq,gcz,gczm,cc,sgwz,
                           zy,cs,ls,yt,scz,sczm,zcz,zczm,qtlh,lhwz,fscz,fsczm,dwcz1,
                           dwczm1,dwcz2,dwczm2,grbz,zrxh,action,action_date from
                           sgml where cc not like '00%' and cc not like 'Y%' and ((to_number(mlh)>=cmd_begin and to_number(mlh)<=cmd_end) or (to_number(mlh)>=8201 and to_number(mlh)<=8299))
                                  and to_char(rq,'YYYYMMDD')||mlh||decode(length(to_char(mlxh)),2,to_char(mlxh),0||to_char(mlxh))||decode(length(to_char(zrxh)),2,to_char(zrxh),0||to_char(zrxh)) not in(select distinct to_char(rq,'YYYYMMDD')||mlh||decode(length(to_char(mlxh)),2,to_char(mlxh),0||to_char(mlxh))||decode(length(to_char(zrxh)),2,to_char(zrxh),0||to_char(zrxh)) from sgml where action=-1)
                                  and (
                                  (rq=p_mlrq and mlh=p_mlh)
                                         or to_char(zzrq,'YYYYMMDD')='20991231'
                                         or (action>0 and to_char(action_date,'YYYYMMDD')=to_char(p_mlrq,'YYYYMMDD'))
                                  )
                                   order by rq,mlh,mlxh,zrxh;
  cursor c_kdlrccl(pcl_mlrq varchar2,pcl_mlh varchar2,pcl_mlxh number,
                   pcl_zrxh number) is
                   select distinct cz,ch from sgcl
                   where to_char(rq,'YYYYMMDD')=pcl_mlrq and trim(mlh)=trim(pcl_mlh) and mlxh=pcl_mlxh and zrxh=pcl_zrxh;
  cursor c_cancel is select rq,mlh,mlxh,zrxh
                     from sgml
                     where ((to_number(mlh)>=cmd_begin and to_number(mlh)<=cmd_end) or (to_number(mlh)>=8201 and to_number(mlh)<=8299))
                     and action=-1 and to_char(action_date,'YYYYMMDD')=to_char(p_mlrq,'YYYYMMDD')
                     order by rq,mlh,mlxh,zrxh;
  /*路局代码*/
  ls_lj varchar2(1);
  /*判断用变量*/
  li_num number(3):=0;
  li_w number(5):=1;
  /*循环变量*/
  li_count number(4);
  /*定义局部变量*/
  vb_grbz boolean;vb_yzcd boolean;vb_yllh boolean;vb_ywf boolean;
  li_cdzs number(2);li_jgts number(4);
  ls_fjmc varchar2(10); ls_gcz_st varchar2(4);ls_gcz_no varchar2(2);li_gcz_day number(3);
  ls_jhrq varchar2(8);ls_sjd varchar2(2);
  ls_zgnr varchar2(200); ls_scz_zgnr varchar2(200);ls_dwcz1_zgnr varchar2(200);ls_dwcz2_zgnr varchar2(200);
  ls_zdz_gcz_zgnr varchar2(200);ls_zdz_zgnr varchar2(200);
  ls_scz_zdz varchar2(3);ls_scz_zdzm varchar2(20); ls_scz_fjmc varchar2(10); ls_scz_st varchar2(4);
  ls_scz_no varchar2(2);li_scz_day number(3);ls_scz_qsrq varchar2(8);ls_scz_jhrq varchar2(8);ls_scz_sjd varchar2(2);
  ls_sczdz varchar2(3);ls_sczdzm varchar2(20);ls_sczdz_fjmc varchar2(10);ls_sczdz_st varchar2(4);li_sczdz_day number(3);
  ls_sczdz_qsrq varchar2(8);ls_sczdz_jhrq varchar2(8);ls_sczdz_sjd varchar2(2);
  ls_lhwz varchar2(10);ls_zdz_gcz varchar2(3);ls_zdz_gczm varchar2(20);
  ls_zdz varchar2(3);ls_zdzm varchar2(20);ls_fcc varchar2(8);li_fts number(2);li_zdz_day number(3);
  ls_zdz_gcz_fjmc varchar2(10);ls_zdz_gcz_st varchar2(4);li_zdz_gcz_day number(3);
  ls_zdz_gcz_qsrq varchar2(8);ls_zdz_gcz_jhrq varchar2(8);ls_zdz_gcz_sjd varchar2(2);
  ls_zdz_fjmc varchar2(10);ls_zdz_st varchar2(4);
  ls_zdzf_st varchar2(4);ls_zdz_qsrq varchar2(8);ls_zdz_jhrq varchar2(8);ls_zdz_sjd varchar2(2);
  ls_zdzf_qsrq varchar2(8);ls_zdzf_jhrq varchar2(8);ls_zdzf_sjd varchar2(2);
  ls_dwcz1_fjmc varchar2(10);ls_dwcz1_st varchar2(4);ls_dwcz1_no varchar2(2);li_dwcz1_day number(3);
  vb_dwcz1 boolean;
  ls_dwcz1_qsrq varchar2(8);ls_dwcz1_jhrq varchar2(8);ls_dwcz1_sjd varchar2(2);
  ls_dwcz2_fjmc varchar2(10);ls_dwcz2_st varchar2(4);ls_dwcz2_no varchar2(2);li_dwcz2_day number(3);
  vb_dwcz2 boolean;
  ls_dwcz2_qsrq varchar2(8);ls_dwcz2_jhrq varchar2(8);ls_dwcz2_sjd varchar2(2);
  /*车辆库使用变量*/
  ls_fir_cz varchar2(6);ls_fir_ch varchar2(10);ls_cz varchar2(6);ls_ch varchar2(10);
  /*常规命令使用的变量*/
  v_cgkdl c_cgkdl%rowtype;
  --
  v_mlrq varchar2(8);
  v_qsrq varchar2(8);
  v_zzrq varchar2(8);
  vv_qsrq varchar2(8);
  v_action_date varchar2(8);
  --
  v_action sgml.action%type;
  v_mlh sgml.mlh%type;v_mlxh sgml.mlxh%type;
  v_gcz sgml.gcz%type;v_gczm sgml.gczm%type;v_cc sgml.cc%type;
  v_sgwz sgml.sgwz%type;v_zy sgml.zy%type;v_cs sgml.cs%type;v_ls sgml.ls%type;
  v_yt sgml.yt%type;v_scz sgml.scz%type;v_sczm sgml.sczm%type;v_zcz sgml.zcz%type;
  v_zczm sgml.zczm%type;v_qtlh sgml.qtlh%type;v_lhwz sgml.lhwz%type;v_fscz sgml.fscz%type;
  v_fsczm sgml.fsczm%type;v_dwcz1 sgml.dwcz1%type;v_dwczm1 sgml.dwczm1%type;
  v_dwcz2 sgml.dwcz2%type;v_dwczm2 sgml.dwczm2%type;v_grbz sgml.grbz%type;
  v_zrxh sgml.zrxh%type;v_mlhm varchar2(20);
  --客票八位车次
  v_train_id train_schedule.train_kpid%type;
  --客票八位车次
  --事务成功标志
  b_successful boolean;
  --事务成功标志
  --取消令
  v_cancel c_cancel%rowtype;
  v_cancel_mlrq varchar2(8);
  v_cancel_mlh sgml.mlh%type;
  v_cancel_mlxh sgml.mlxh%type;
  v_cancel_zrxh sgml.zrxh%type;
  --取消令
  --长期令标记
  vb_lzl boolean;
  vb_cql boolean;
  --长期令标记
  --站内到达车次换挂用
  v_pre_mlxh sgml.mlxh%type;v_pre_yt sgml.yt%type;v_pre_zrxh sgml.zrxh%type;v_pre_sgwz sgml.sgwz%type;
  ls_pre_zgnr varchar2(2000);
  --站内到达车次换挂用
BEGIN
  p_rtnstring:='';
  b_successful:=true;
  v_successful:='';
  open c_cancel;
  loop
   fetch c_cancel into v_cancel;
   exit when c_cancel%notfound;
   v_cancel_mlrq:=to_char(v_cancel.rq,'YYYYMMDD');
   v_cancel_mlh:=v_cancel.mlh;
   v_cancel_mlxh:=v_cancel.mlxh;
   v_cancel_zrxh:=v_cancel.zrxh;
   delete from k_kdjhb
          where to_char(mlrq,'YYYYMMDD')=v_cancel_mlrq and mlh=v_cancel_mlh and to_number(mlxh)=v_cancel_mlxh and zrxh=v_cancel_zrxh;
  end loop;
  close c_cancel;
  open c_cgkdl;
  select count(*) into li_num from b_bureau where cur_bureau='1';
  if li_num = 0 then
     p_rtnstring:=p_rtnstring||'B_BUREAU中没有指定所属路局标志!'||chr(10)||'<br>';
     b_successful:=false;
     goto break;
  elsif li_num >1 then
     p_rtnstring:=p_rtnstring||'B_BUREAU中只能指定一个所属路局标志!'||chr(10)||'<br>';
     b_successful:=false;
     goto break;
  elsif li_num=1 then
     select bureau_code into ls_lj from b_bureau where cur_bureau='1';
  end if;
  --
  v_pre_mlxh:=0;v_pre_yt:=' ';v_pre_zrxh:=0;v_pre_sgwz:=' ';
  ls_pre_zgnr:=' ';
  --
  loop
    fetch c_cgkdl into v_cgkdl;
    exit when c_cgkdl%notfound;
    /*初始化变量*/
    li_w := 1;
    vb_lzl := false;
    vb_cql := false;
    vb_grbz := false;
    vb_yzcd := false;
    vb_yllh := false;
    li_cdzs := 0;
    li_jgts := 0;
    ls_fjmc := '';
    ls_gcz_st:='';
    ls_gcz_no:='';
    li_gcz_day:=0;
    ls_jhrq:='';
    ls_sjd:='';
    ls_zgnr:='';
    ls_scz_zgnr:='';
    ls_dwcz1_zgnr:='';
    ls_dwcz2_zgnr:='';
    ls_zdz_gcz_zgnr:='';
    ls_zdz_zgnr:='';
    li_count:=0;
    ls_scz_zdz:='';
    ls_scz_zdzm:='';
    ls_scz_fjmc := '';
    ls_scz_st:='';
    ls_scz_no:='';
    li_scz_day:=0;
    ls_scz_qsrq:='';
    ls_scz_jhrq:='';
    ls_scz_sjd:='';
    ls_sczdz:='';
    ls_sczdzm:='';
    ls_sczdz_fjmc:='';
    ls_sczdz_st:='';
    li_sczdz_day:=0;
    ls_sczdz_qsrq:='';
    ls_sczdz_jhrq:='';
    ls_sczdz_sjd:='';
    ls_lhwz:='';
    ls_zdz_gcz:='';
    ls_zdz_gczm:='';
    ls_zdz:='';
    ls_zdzm:='';
    ls_fcc:='';
    li_fts:=0;
    li_zdz_day:=0;
    ls_zdz_gcz_fjmc:='';
    ls_zdz_gcz_st:='';
    li_zdz_gcz_day:=0;
    ls_zdz_gcz_qsrq:='';
    ls_zdz_gcz_jhrq:='';
    ls_zdz_gcz_sjd:='';
    ls_zdz_fjmc:='';
    ls_zdz_st:='';
    ls_zdzf_st:='';
    ls_zdz_qsrq:='';
    ls_zdz_jhrq:='';
    ls_zdz_sjd:='';
    ls_zdzf_qsrq:='';
    ls_zdzf_jhrq:='';
    ls_zdzf_sjd:='';
    ls_dwcz1_fjmc:='';
    ls_dwcz1_st:='';
    ls_dwcz1_no:='';
    li_dwcz1_day:=0;
    vb_dwcz1:=false;
    ls_dwcz1_qsrq:='';
    ls_dwcz1_jhrq:='';
    ls_dwcz1_sjd:='';
    ls_dwcz2_fjmc:='';
    ls_dwcz2_st:='';
    ls_dwcz2_no:='';
    li_dwcz2_day:=0;
    vb_dwcz2:=false;
    ls_dwcz2_qsrq:='';
    ls_dwcz2_jhrq:='';
    ls_dwcz2_sjd:='';

    ls_fir_cz:='';ls_fir_ch:='';ls_cz:='';ls_ch:='';

    v_action:=v_cgkdl.action;
    v_action_date:=to_char(v_cgkdl.action_date,'YYYYMMDD');
    v_mlrq:=to_char(v_cgkdl.rq,'YYYYMMDD');
    v_mlh:=v_cgkdl.mlh;
    v_mlxh:=v_cgkdl.mlxh;
    if v_mlh='82041' then
      li_count:=9;
    end if;
    v_qsrq:=to_char(v_cgkdl.qsrq,'YYYYMMDD');
    vv_qsrq:=v_qsrq;
    v_zzrq:=to_char(nvl(v_cgkdl.zzrq,v_cgkdl.qsrq),'YYYYMMDD');
    v_gcz:=nvl(v_cgkdl.gcz,' ');
    v_gczm:=nvl(v_cgkdl.gczm,' ');
    v_cc:=v_cgkdl.cc;
    v_sgwz:=nvl(v_cgkdl.sgwz,' ');
    v_zy:=nvl(v_cgkdl.zy,' ');
    v_cs:=nvl(v_cgkdl.cs,' ');
    v_ls:=nvl(v_cgkdl.ls,0);
    v_yt:=v_cgkdl.yt;
    v_scz:=nvl(v_cgkdl.scz,' ');
    v_sczm:=nvl(v_cgkdl.sczm,' ');
    v_zcz:=nvl(v_cgkdl.zcz,' ');
    v_zczm:=nvl(v_cgkdl.zczm,' ');
    v_qtlh:=nvl(v_cgkdl.qtlh,' ');
    v_lhwz:=nvl(v_cgkdl.lhwz, ' ');
    v_fscz:=nvl(v_cgkdl.fscz,' ');
    v_fsczm:=nvl(v_cgkdl.fsczm,' ');
    v_dwcz1:=nvl(v_cgkdl.dwcz1,' ');
    v_dwczm1:=nvl(v_cgkdl.dwczm1,' ');
    v_dwcz2:=nvl(v_cgkdl.dwcz2,' ');
    v_dwczm2:=nvl(v_cgkdl.dwczm2,' ');
    v_grbz:=nvl(v_cgkdl.grbz,' ');
    v_zrxh:=v_cgkdl.zrxh;

    if length(to_char(v_mlxh)) = 1 then
       v_mlhm:=v_mlh||'-0'||to_char(v_mlxh)||'('||substr(v_mlrq,5,2)||')';
    else
       v_mlhm:=v_mlh||'-'||to_char(v_mlxh)||'('||substr(v_mlrq,5,2)||')';
    end if;
    --
    v_train_id := gettrainid(v_cc,vv_qsrq);
    if v_train_id = 'Not1' then
          p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_schedule表中无对应的信息!'||chr(10)||'<br>';
          goto continue;
    elsif v_train_id = 'Not2' then
          p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_schedule表中无对应的信息!'||chr(10)||'<br>';
          goto continue;
    end if;
    --
    --找最新得命令
    select count(*)-1 into li_num from sgml
       where to_char(rq,'YYYYMMDD')=v_mlrq and mlh=v_mlh and mlxh=v_mlxh and zrxh=v_zrxh;
    if li_num>0 then
       if v_action!=li_num then
          --p_rtnstring:=p_rtnstring||v_mlhm||'令'||'action:'||to_char(v_action)||chr(10)||'<br>';
          goto continue;
       end if;
    end if;
    --如不是最新得，不作处理
    if v_zzrq !='20991231' and v_zzrq != v_qsrq and v_zzrq < to_char(sysdate - 8,'yyyymmdd') then
       goto continue;
    end if;
    if v_zzrq = '20991231' then
       vb_lzl := true;
       if v_qsrq > to_char(sysdate,'yyyymmdd') then
          v_zzrq := to_char(to_date(v_qsrq,'yyyymmdd') + 8, 'yyyymmdd');
       else
          v_qsrq := to_char(sysdate - 8, 'yyyymmdd');
          v_zzrq := to_char(sysdate + 8, 'yyyymmdd');
       end if;
    end if;
    if v_zzrq !='20991231' and v_zzrq != v_qsrq then
       vb_cql := true;
    end if;
    if v_grbz!=' ' then
       if upper(substr(v_grbz,1,1)) = 'Y' then
          vb_grbz := true;
       elsif upper(substr(v_grbz,1,1)) = 'A' then
          vb_yzcd := true;
       end if;
    end if;
    select groups-1 into li_cdzs from train_info
       where train_kpid = v_train_id;
    /*
    if vb_yzcd then
       --v_train_id := gettrainid(v_cc,vv_qsrq);
       if v_train_id = 'Not1' then
          p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_info表中无对应的信息!'||chr(10)||'<br>';
          goto continue;
       elsif v_train_id = 'Not2' then
          p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_info表中无对应的信息!'||chr(10)||'<br>';
          goto continue;
       else
          select groups-1 into li_cdzs from train_info
             where train_kpid = v_train_id;
       end if;
    end if;
    */
    li_jgts := to_date(v_zzrq,'YYYYMMDD')- to_date(v_qsrq,'YYYYMMDD');
    /*删除旧的客调计划*/
    delete from k_kdjhb where to_char(mlrq,'YYYYMMDD')=v_mlrq and mlh=v_mlh and to_number(mlxh)=v_mlxh and zrxh=v_zrxh;
    if v_gcz != ' ' then
       if v_zy != ' ' then
          select count(*) into li_num from  b_station a,b_subbureau b
             where trim(b.subbureau_code) = trim(a.subbureau_code) and trim(a.station_telecode)=trim(v_gcz);
          if li_num=0 then
             p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||v_gczm||'站无对应的分局!'||chr(10)||'<br>';
             goto continue;
          elsif li_num>1 then
             p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||v_gczm||'站对应的分局多余一个!'||chr(10)||'<br>';
             goto continue;
          elsif li_num=1 then
             select b.subbureau_short_name into ls_fjmc from b_station a,b_subbureau b
                where b.subbureau_code = a.subbureau_code and a.station_telecode=v_gcz;
          end if;
          --v_train_id := gettrainid(v_cc,vv_qsrq);
          select count(*) into li_num from train_schedule
             where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(v_gczm));
          if li_num=0 then
             p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次无对应的时刻表!'||chr(10)||'<br>';
             goto continue;
          elsif li_num>1 then
             p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次中有一个以上的'||v_gczm||'营业站!'||chr(10)||'<br>';
             goto continue;
          elsif li_num=1 then
             select start_time,run_days,sta_sort into ls_gcz_st,li_gcz_day,ls_gcz_no from train_schedule
               where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(v_gczm));
             if ls_gcz_st = '-' then
                 select arrive_time into ls_gcz_st from train_schedule
                   where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(v_gczm));
             end if;
          end if;
          if to_number(ls_gcz_st) >= 0 and to_number(ls_gcz_st) < 600 then
             ls_jhrq := v_qsrq;
             ls_sjd:='1';
          elsif to_number(ls_gcz_st)>=600 and to_number(ls_gcz_st)<1800 then
             ls_jhrq:=v_qsrq;
             ls_sjd:='2';
          else
             ls_jhrq:=to_char(to_date(v_qsrq,'YYYYMMDD') + 1,'YYYYMMDD');
             ls_sjd:='1';
          end if;
          /*查询车辆库，组合摘挂内容项*/
          ls_zgnr:= ls_zgnr||v_cs;
          open c_kdlrccl(v_mlrq,v_mlh,v_mlxh,v_zrxh);
          fetch c_kdlrccl into ls_fir_cz,ls_fir_ch;
          if nvl(ls_fir_ch,'0')=nvl(null,'0') then
             ls_zgnr:= ls_zgnr||ls_fir_cz||to_char(v_ls)||'辆';
          else
             ls_zgnr:=ls_zgnr||ls_fir_cz||ls_fir_ch;
             loop
               fetch c_kdlrccl into ls_cz,ls_ch;
               exit when c_kdlrccl%notfound;
               ls_zgnr:=ls_zgnr||','||ls_cz||ls_ch;
             end loop;
          end if;
          close c_kdlrccl;
          /*查询车辆库结束*/
          ls_scz_zgnr:=ls_zgnr;
          ls_dwcz1_zgnr:=ls_zgnr;
          ls_dwcz2_zgnr:=ls_zgnr;
          ls_zdz_gcz_zgnr:=ls_zgnr;
          ls_zdz_zgnr:=ls_zgnr;
          ls_zgnr:=ls_zgnr||v_yt;
          /*对用途是存站、充组的命令进行 处理开始（隔日标志为D，表示针对到达车次的命令）*/
          if v_yt = '存站' or v_yt = '充组' then
             if substr(v_gcz,3,1) = ls_lj then
              if v_mlxh=v_pre_mlxh and v_pre_yt='存站' and v_yt='充组' then
                delete from k_kdjhb where to_char(mlrq,'YYYYMMDD')=v_mlrq and mlh=v_mlh and to_number(mlxh)=v_mlxh and zrxh=v_pre_zrxh and cc=v_cc;
                li_count:=0;
                while li_count <= li_jgts loop
                  if trim(v_sgwz)!=trim(v_pre_sgwz) then
                    insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                          values(to_char(to_date(ls_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                 ls_sjd,
                                 ls_fjmc,
                                 v_gczm,
                                 v_cc,
                                 '甩/挂',--v_zy,
                                 v_pre_sgwz,
                                 ls_pre_zgnr||','||v_sgwz || '换挂'||ls_zgnr,
                                 to_date(v_mlrq,'YYYYMMDD'),
                                 v_mlh,
                                 v_mlxh,
                                 v_zrxh);
                  else
                    insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                          values(to_char(to_date(ls_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                 ls_sjd,
                                 ls_fjmc,
                                 v_gczm,
                                 v_cc,
                                 '甩/挂',--v_zy,
                                 v_pre_sgwz,
                                 ls_pre_zgnr||',原位换挂'||ls_zgnr,
                                 to_date(v_mlrq,'YYYYMMDD'),
                                 v_mlh,
                                 v_mlxh,
                                 v_zrxh);
                  end if;
                    if vb_grbz then
                       li_count:=li_count + 1;
                    end if;
                    if vb_yzcd then
                       li_count:=li_count + li_cdzs;
                    end if;
                    li_count:=li_count+ 1;
                end loop;
              else
               li_count:=0;
                while li_count <= li_jgts loop
                    insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                          values(to_char(to_date(ls_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                 ls_sjd,
                                 ls_fjmc,
                                 v_gczm,
                                 v_cc,
                                 v_zy,
                                 v_sgwz,
                                 ls_zgnr,
                                 to_date(v_mlrq,'YYYYMMDD'),
                                 v_mlh,
                                 v_mlxh,
                                 v_zrxh);
                    if vb_grbz then
                       li_count:=li_count + 1;
                    end if;
                    if vb_yzcd then
                       li_count:=li_count + li_cdzs;
                    end if;
                    li_count:=li_count+ 1;
                end loop;
              end if;--
             end if;--v_gcz=ls_lj
             --对应始发车次的计划开始
             /*
             if v_grbz!=' ' then
               if (length(v_grbz)= 1 and upper(substr(v_grbz,1,1)) = 'D') or (length(v_grbz)=2 and upper(substr(v_grbz,2,1)) = 'D') then
                  select back_train_kpid,back_days - 1 into ls_fcc,li_fts from train_info
                    where train_kpid = v_train_id;
                  select count(*) into li_num from train_schedule
                    where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(v_gczm)) and sta_sort='01';
                  if li_num=0 then
                     p_rtnstring:=p_rtnstring||v_mlhm||'令'||gettraincode(ls_fcc)||'次无'||v_gczm||'对应的时刻表!'||chr(10)||'<br>';
                     goto continue;
                  elsif li_num>1 then
                     p_rtnstring:=p_rtnstring||v_mlhm||'令'||gettraincode(ls_fcc)||'次中有一个以上的'||v_gczm||'营业站!'||chr(10)||'<br>';
                     goto continue;
                  elsif li_num=1 then
                     select start_time into ls_zdzf_st from train_schedule
                       where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(v_gczm)) and sta_sort='01';
                     if ls_zdzf_st = '-' then
                         select arrive_time into ls_zdzf_st from train_schedule
                           where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(v_gczm)) and sta_sort='01';
                     end if;
                  end if;
                  ls_zdzf_qsrq := to_char(to_date(v_qsrq,'YYYYMMDD') + li_fts,'YYYYMMDD');
                  if to_number(ls_zdzf_st)>=0 and to_number(ls_zdzf_st)<600 then
                     ls_zdzf_jhrq := ls_zdzf_qsrq;
                     ls_zdzf_sjd := '1';
                  elsif to_number(ls_zdzf_st)>=600 and to_number(ls_zdzf_st)<1800 then
                     ls_zdzf_jhrq := ls_zdzf_qsrq;
                     ls_zdzf_sjd := '2';
                  else
                     ls_zdzf_jhrq := to_char(to_date(ls_zdzf_qsrq,'YYYYMMDD') + 1,'YYYYMMDD');
                     ls_zdzf_sjd := '1';
                  end if;
                 if v_mlxh=v_pre_mlxh and v_pre_yt='存站' and v_yt='充组' then
                  delete from k_kdjhb where to_char(mlrq,'YYYYMMDD')=v_mlrq and mlh=v_mlh and to_number(mlxh)=v_mlxh and zrxh=v_pre_zrxh and cc=gettraincode(ls_fcc);
                  if ls_sjd!=ls_zdzf_sjd then
                  li_count:=0;
                  while li_count <= li_jgts loop
                    insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                          values(to_char(to_date(ls_zdzf_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                 ls_zdzf_sjd,
                                 ls_fjmc,
                                 v_gczm,
                                 gettraincode(ls_fcc),
                                 '甩/挂',--v_zy,
                                 v_sgwz,
                                 ls_pre_zgnr||',换挂'||ls_zgnr,
                                 to_date(v_mlrq,'YYYYMMDD'),
                                 v_mlh,
                                 v_mlxh,
                                 v_zrxh);
                    if vb_grbz then
                       li_count:=li_count + 1;
                    end if;
                    if vb_yzcd then
                       li_count:=li_count + li_cdzs;
                    end if;
                    li_count:=li_count+ 1;
                  end loop;
                  end if;--ls_sjd!=ls_zdzf_sjd
                  v_pre_mlxh:=0;v_pre_yt:=' ';v_pre_zrxh:=0;
                 else
                  if ls_sjd!=ls_zdzf_sjd then
                  li_count:=0;
                  while li_count <= li_jgts loop
                      insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                            values(to_char(to_date(ls_zdzf_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                   ls_zdzf_sjd,
                                   ls_fjmc,
                                   v_gczm,
                                   gettraincode(ls_fcc),
                                   v_zy,
                                   v_sgwz,
                                   ls_zgnr,
                                   to_date(v_mlrq,'YYYYMMDD'),
                                   v_mlh,
                                   v_mlxh,
                                   v_zrxh);
                      if vb_grbz then
                         li_count:=li_count + 1;
                      end if;
                      if vb_yzcd then
                         li_count:=li_count + li_cdzs;
                      end if;
                      li_count:=li_count+ 1;
                  end loop;
                  end if;--ls_sjd!=ls_zdzf_sjd
                 end if;--
               else
                  select back_train_kpid into ls_fcc from train_info
                    where train_kpid = v_train_id;
                  select back_days - 1 into li_fts from train_info
                    where train_kpid = ls_fcc;
                  select count(*) into li_num from train_schedule
                     where train_kpid=ls_fcc and trim(sta_name)=trim(v_gczm);
                  if li_num=0 then
                     p_rtnstring:=p_rtnstring||v_mlhm||'令'||gettraincode(ls_fcc)||'次中的'||v_gczm||'站无对应的时刻表!'||chr(10)||'<br>';
                     goto continue;
                  elsif li_num>1 then
                     p_rtnstring:=p_rtnstring||v_mlhm||'令'||gettraincode(ls_fcc)||'次中的'||v_gczm||'站有多于一个的时刻表!'||chr(10)||'<br>';
                     goto continue;
                  elsif li_num=1 then
                     select start_time into ls_zdz_st from train_schedule
                       where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(v_gczm));
                     if ls_zdz_st = '-' then
                        select arrive_time into ls_zdz_st from train_schedule
                          where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(v_gczm));
                     end if;
                  end if;
                  ls_zdz_qsrq :=to_char(to_date(v_qsrq,'YYYYMMDD') - li_fts,'YYYYMMDD');
                  if to_number(ls_zdz_st)>=0 and to_number(ls_zdz_st)<600 then
                     ls_zdz_jhrq := ls_zdz_qsrq;
                     ls_zdz_sjd := '1';
                  elsif to_number(ls_zdz_st)>=600 and to_number(ls_zdz_st)<1800 then
                     ls_zdz_jhrq := ls_zdz_qsrq;
                     ls_zdz_sjd := '2';
                  else
                     ls_zdz_jhrq := to_char(to_date(ls_zdz_qsrq,'YYYYMMDD') + 1,'YYYYMMDD');
                     ls_zdz_sjd := '1';
                  end if;
                  if v_mlxh=v_pre_mlxh and v_pre_yt='存站' and v_yt='充组' then
                    delete from k_kdjhb where to_char(mlrq,'YYYYMMDD')=v_mlrq and mlh=v_mlh and to_number(mlxh)=v_mlxh and zrxh=v_pre_zrxh and cc=gettraincode(ls_fcc);
                    if ls_sjd!=ls_zdz_sjd then
                    li_count:=0;
                    while li_count <= li_jgts loop
                      insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                            values(to_char(to_date(ls_zdz_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                   ls_zdz_sjd,
                                   ls_fjmc,
                                   v_gczm,
                                   gettraincode(ls_fcc),
                                   '甩/挂',--v_zy,
                                   v_sgwz,
                                   ls_pre_zgnr||',换挂'||ls_zgnr,
                                   to_date(v_mlrq,'YYYYMMDD'),
                                   v_mlh,
                                   v_mlxh,
                                   v_zrxh);
                      if vb_grbz then
                         li_count:=li_count + 1;
                      end if;
                      if vb_yzcd then
                         li_count:=li_count + li_cdzs;
                      end if;
                      li_count:=li_count+ 1;
                    end loop;
                    end if;--ls_sjd!=ls_zdz_sjd
                  else
                    if ls_sjd!=ls_zdz_sjd then
                    li_count:=0;
                    while li_count <= li_jgts loop
                      insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                            values(to_char(to_date(ls_zdz_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                   ls_zdz_sjd,
                                   ls_fjmc,
                                   v_gczm,
                                   gettraincode(ls_fcc),
                                   v_zy,
                                   v_sgwz,
                                   ls_zgnr,
                                   to_date(v_mlrq,'YYYYMMDD'),
                                   v_mlh,
                                   v_mlxh,
                                   v_zrxh);
                      if vb_grbz then
                         li_count:=li_count + 1;
                      end if;
                      if vb_yzcd then
                         li_count:=li_count + li_cdzs;
                      end if;
                      li_count:=li_count+ 1;
                    end loop;
                    end if;--ls_sjd!=ls_zdz_sjd
                  end if;
               end if;--v_grbz='D'
             end if; --v_grbz!=' '
             */
             --对应始发车次的计划结束
             --
             v_pre_mlxh:=v_mlxh;v_pre_yt:=v_yt;v_pre_zrxh:=v_zrxh;v_pre_sgwz:=v_sgwz;
             ls_pre_zgnr:=ls_zgnr;
             --
             goto continue;
          end if;--v_yt=存站、充组
          /*对用途是存站、充组的命令进行 处理结束（隔日标志为D，表示针对到达车次的命令）*/
          if v_zy='挂' then
             if v_scz != ' ' then
                ls_zgnr:=ls_zgnr||v_sczm;
             end if;
             if v_lhwz != ' ' then
                ls_zgnr:=ls_zgnr||v_lhwz;
             end if;
             if v_qtlh != ' ' then
                ls_zgnr:=ls_zgnr||v_qtlh;
             end if;
             if v_fscz != ' ' then
                ls_zgnr:=ls_zgnr||v_fsczm;
             end if;
             if v_dwcz1 != ' ' then
                ls_zgnr:=ls_zgnr||' '||v_dwczm1||'调尾';
                if v_dwcz2 != ' ' then
                   ls_zgnr:=ls_zgnr||' '||v_dwczm2||'调尾';
                end if;
             end if;
             if substr(v_gcz,3,1) = ls_lj then
                li_count:=0;
                li_w := 1;
                while li_count <= li_jgts loop
                    if li_w > li_cdzs + 1 then
                       insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                          values(to_char(to_date(ls_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                 ls_sjd,
                                 ls_fjmc,
                                 v_gczm,
                                 v_cc,
                                 '原列',--v_zy,
                                 v_sgwz,
                                 ls_zgnr,
                                 to_date(v_mlrq,'YYYYMMDD'),
                                 v_mlh,
                                 v_mlxh,
                                 v_zrxh);
                    else
                       insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                          values(to_char(to_date(ls_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                 ls_sjd,
                                 ls_fjmc,
                                 v_gczm,
                                 v_cc,
                                 v_zy,
                                 v_sgwz,
                                 ls_zgnr,
                                 to_date(v_mlrq,'YYYYMMDD'),
                                 v_mlh,
                                 v_mlxh,
                                 v_zrxh);
                    end if;
                    if vb_grbz then
                       li_count:=li_count + 1;
                       li_w := li_w + 1;
                    end if;
                    if vb_yzcd then
                       li_count:=li_count + li_cdzs;
                       li_w := li_w + li_cdzs;
                    end if;
                    li_count:=li_count+ 1;
                    li_w := li_w + 1;
                end loop;
             end if;
             if v_scz != ' ' then
                if v_qtlh != ' ' then
                   if v_qtlh='原列利回' or v_qtlh='原列空送' or v_qtlh='原列充组' or v_qtlh='原列欠车' then
                      --v_train_id := gettrainid(v_cc,vv_qsrq);
                      /*
                         if v_train_id = 'Not1' then
                              p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_info表中无对应的信息!'||chr(10)||'<br>';
                              goto continue;
                         elsif v_train_id = 'Not2' then
                              p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_info表中无对应的信息!'||chr(10)||'<br>';
                              goto continue;
                         else
                             select begin_Sta_Code,begin_Sta_Name into ls_scz_zdz,ls_scz_zdzm from train_info
                                where train_kpid=v_train_id;
                         end if;
                         */
                      select end_Sta_Code,end_Sta_Name into ls_scz_zdz,ls_scz_zdzm from train_info
                             where train_kpid = v_train_id;
                      if v_scz=ls_scz_zdz then
                         vb_yllh := true;
                      else
                         vb_yllh := false;
                         p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次原列列回的甩车站'||v_sczm||'不是终点站'||ls_scz_zdzm||chr(10)||'<br>';
                         goto continue;
                      end if;
                   end if;
                end if;
                if not(vb_yllh) then
                   if substr(v_scz,3,1) = ls_lj then
                      select count(*) into li_num from b_station a,b_subbureau b
                         where trim(b.subbureau_code)=trim(a.subbureau_code) and trim(a.station_telecode)=trim(v_scz);
                      if li_num=0 then
                         p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_sczm||'站无对应的分局!'||chr(10)||'<br>';
                         goto continue;
                      elsif li_num>1 then
                         p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_sczm||'站对应的分局多于一个!'||chr(10)||'<br>';
                         goto continue;
                      elsif li_num=1 then
                         select b.subbureau_short_name into ls_scz_fjmc from b_station a,b_subbureau b
                            where b.subbureau_code=a.subbureau_code and a.station_telecode=v_scz;
                      end if;
                      --v_train_id := gettrainid(v_cc,vv_qsrq);
                      select count(*) into li_num from train_schedule
                            where train_kpid=v_train_id and trim(sta_name)=trim(v_sczm);
                      if li_num=0 then
                         p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次无'||v_sczm||'营业站的时刻'||chr(10)||'<br>';
                         goto continue;
                      elsif li_num>1 then
                         p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次有多于一个的'||v_sczm||'营业站的时刻'||chr(10)||'<br>';
                         goto continue;
                      elsif li_num=1 then
                         select start_time,run_days,sta_sort into ls_scz_st,li_scz_day,ls_scz_no
                            from train_schedule
                               where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(v_sczm));
                         if ls_scz_st = '-' then
                            select arrive_time into ls_scz_st
                               from train_schedule
                                  where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(v_sczm));
                         end if;
                      end if;
                      if to_number(ls_scz_no) > to_number(ls_gcz_no) then
                         ls_scz_qsrq := to_char(to_date(v_qsrq,'YYYYMMDD') + (li_scz_day-li_gcz_day),'YYYYMMDD');
                         if to_number(ls_scz_st) >= 0 and to_number(ls_scz_st) < 600 then
                            ls_scz_jhrq := ls_scz_qsrq;
                            ls_scz_sjd:='1';
                         elsif to_number(ls_scz_st) >=600 and to_number(ls_scz_st) <1800 then
                            ls_scz_jhrq := ls_scz_qsrq;
                            ls_scz_sjd := '2';
                         else
                            ls_scz_jhrq := to_char(to_date(ls_scz_qsrq,'YYYYMMDD') + 1,'YYYYMMDD');
                            ls_scz_sjd := '1';
                         end if;
                         li_count:=0;
                         li_w := 0;
                         if v_zcz != ' ' then
                            ls_scz_zgnr := ls_scz_zgnr ||'转'||v_zczm;
                         else
                            ls_scz_zgnr:= ls_scz_zgnr||'存站';
                         end if;
                         while li_count<=li_jgts loop
                            li_w:=li_w + 1;
                            insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                                  values(to_char(to_date(ls_scz_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                         ls_scz_sjd,
                                         ls_scz_fjmc,
                                         v_sczm,
                                         v_cc,
                                         '甩',
                                         v_sgwz,
                                         ls_scz_zgnr,
                                         to_date(v_mlrq,'YYYYMMDD'),
                                         v_mlh,
                                         v_mlxh,
                                         v_zrxh);
                            if vb_grbz then
                               li_count:=li_count + 1;
                            end if;
                            if vb_yzcd then
                               li_count:=li_count + li_cdzs;
                            end if;
                            li_count:= li_count + 1;
                         end loop;
                      else
                         p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次挂车站'||v_gczm||'站序应该大于甩车站'||v_sczm||'站序'||chr(10)||'<br>';
                         goto continue;
                      end if;--ls_scz_no>ls_gcz_no
                   end if;--substr(v_scz,3,1) = ls_lj
                end if;--not vb_yllh
             end if;
          end if;--v_zy='挂'
          if v_zy='甩' then
             if substr(v_gcz,3,1)= ls_lj then
                li_count:=0;
                li_w := 1;
                while li_count <= li_jgts loop
                   if li_w > li_cdzs + 1 then
                      insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                          values(to_char(to_date(ls_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                 ls_sjd,
                                 ls_fjmc,
                                 v_gczm,
                                 v_cc,
                                 '原列',--v_zy,
                                 v_sgwz,
                                 ls_zgnr,
                                 to_date(v_mlrq,'YYYYMMDD'),
                                 v_mlh,
                                 v_mlxh,
                                 v_zrxh);
                   else
                      insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                          values(to_char(to_date(ls_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                 ls_sjd,
                                 ls_fjmc,
                                 v_gczm,
                                 v_cc,
                                 v_zy,
                                 v_sgwz,
                                 ls_zgnr,
                                 to_date(v_mlrq,'YYYYMMDD'),
                                 v_mlh,
                                 v_mlxh,
                                 v_zrxh);
                    end if;
                    if vb_grbz then
                       li_count:=li_count + 1;
                       li_w := li_w + 1;
                    end if;
                    if vb_yzcd then
                       li_count:=li_count + li_cdzs;
                       li_w := li_w + li_cdzs;
                    end if;
                    li_count:=li_count + 1;
                    li_w := li_w + 1;
                end loop;
             end if;--v_gcz='Q'
                  --v_train_id := gettrainid(v_cc,vv_qsrq);
                  /*
                         if v_train_id = 'Not1' then
                              p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_info表中无对应的信息!'||chr(10)||'<br>';
                              goto continue;
                         elsif v_train_id = 'Not2' then
                              p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_info表中无对应的信息!'||chr(10)||'<br>';
                              goto continue;
                         else
                             select end_Sta_Code,end_Sta_Name into ls_sczdz,ls_sczdzm from train_info
                                where train_kpid = v_train_id;
                         end if;
                         */
             select end_Sta_Code,end_Sta_Name into ls_sczdz,ls_sczdzm from train_info
                    where train_kpid = v_train_id;
             select count(*) into li_num from b_station a,b_subbureau b
               where trim(b.subbureau_code)=trim(a.subbureau_code) and trim(a.station_telecode)=trim(ls_sczdz);
             if li_num=0 then
                p_rtnstring:=p_rtnstring||v_mlhm||'令'||'甩车作业的终到站没有对应的分局!'||chr(10)||'<br>';
                goto continue;
             elsif li_num>1 then
                p_rtnstring:=p_rtnstring||v_mlhm||'令'||'甩车作业的终到站对应的分局多于一个!'||chr(10)||'<br>';
                goto continue;
             elsif li_num=1 then
                select b.subbureau_short_name into ls_sczdz_fjmc from b_station a,b_subbureau b
                  where b.subbureau_code=a.subbureau_code and a.station_telecode=ls_sczdz;
             end if;
             select start_time,run_days into ls_sczdz_st,li_sczdz_day from train_schedule
               where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(ls_sczdzm));
             if ls_sczdz_st = '-' then
                select arrive_time into ls_sczdz_st from train_schedule
                  where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(ls_sczdzm));
             end if;
             ls_sczdz_qsrq:=to_char(to_date(v_qsrq,'YYYYMMDD') + (li_sczdz_day - li_gcz_day),'YYYYMMDD');
             if to_number(ls_sczdz_st)>=0 and to_number(ls_sczdz_st)<600 then
                ls_sczdz_jhrq:=ls_sczdz_qsrq;
                ls_sczdz_sjd:='1';
             elsif to_number(ls_sczdz_st)>=600 and to_number(ls_sczdz_st)<1800 then
                ls_sczdz_jhrq:=ls_sczdz_qsrq;
                ls_sczdz_sjd:='2';
             else
                ls_sczdz_jhrq:=to_char(to_date(ls_sczdz_qsrq,'YYYYMMDD') + 1,'YYYYMMDD');
                ls_sczdz_sjd:='1';
             end if;
             if not(nvl(ls_sczdz,'0')=nvl(null,'0')) then
                if substr(ls_sczdz,3,1)=ls_lj then
                   if nvl(v_qtlh,'0')!=nvl(null,'0') then
                      if v_qtlh!='一往返' then
                         li_count:=0;
                         li_w := 1;
                      end if;
                   else
                         li_count:=0;
                         li_w := 1;
                   end if;
                end if;
             end if;
          end if;--v_zy='甩'
       else
          p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次车甩挂作业不能为空!'||chr(10)||'<br>';
          goto continue;
       end if;--v_zy != ' '
    end if;--v_gcz != ' '
    /*一往返、原列利回作业生成开始*/
    if v_qtlh !=' ' then
       if v_lhwz !=' ' then
          ls_lhwz := v_lhwz;
       else
          ls_lhwz := v_sgwz;
       end if;
       if v_qtlh='原列利回' or v_qtlh='原列空送' or v_qtlh='原列充组' or v_qtlh='原列欠车' or v_qtlh='一往返'  then
          if v_qtlh='原列利回' or v_qtlh='原列空送' or v_qtlh='原列充组' or v_qtlh='原列欠车'  then
             if v_fscz != ' ' then
                ls_zdz_gcz := v_fscz;
                ls_zdz_gczm := v_fsczm;
             end if;
          end if;
          if v_qtlh='一往返' then
             if v_gcz!= ' ' then
                ls_zdz_gcz := v_gcz;
                ls_zdz_gczm := v_gczm;
                vb_ywf := true;
             end if;
          end if;
          if vb_yllh or vb_ywf then
       --v_train_id := gettrainid(v_cc,vv_qsrq);
       /*
       if v_train_id = 'Not1' then
          p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_info表中无对应的信息!'||chr(10)||'<br>';
          goto continue;
       elsif v_train_id = 'Not2' then
          p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_info表中无对应的信息!'||chr(10)||'<br>';
          goto continue;
       else
          select end_sta_code,end_sta_name,back_train_kpid,back_days into ls_zdz,ls_zdzm,ls_fcc,li_fts from train_info
             where train_kpid = v_train_id;
       end if;
       */
             select end_sta_code,end_sta_name,back_train_kpid,back_days - 1 into ls_zdz,ls_zdzm,ls_fcc,li_fts from train_info
                 where train_kpid = v_train_id;
             select max(run_days) into li_zdz_day from train_schedule
                 where train_kpid=v_train_id;
             if substr(ls_zdz_gcz,3,1)=ls_lj then
                select b.subbureau_short_name into ls_zdz_gcz_fjmc from b_station a,b_subbureau b
                  where b.subbureau_code=a.subbureau_code and a.station_telecode=ls_zdz_gcz;
                --2004-08-21  针对返回车次终到站与原车次始发站不同进行处理
                select count(*) into li_num from train_schedule
                  where train_kpid=ls_fcc and trim(sta_name)=trim(ls_zdz_gczm);
                if li_num=0 then
                   p_rtnstring:=p_rtnstring||v_mlhm||'令'||gettraincode(ls_fcc)||'次中的'||ls_zdz_gczm||'站无对应的时刻表!'||chr(10)||'<br>';
                   goto continue;
                elsif li_num>1 then
                   p_rtnstring:=p_rtnstring||v_mlhm||'令'||gettraincode(ls_fcc)||'次中的'||ls_zdz_gczm||'站有多于一个的时刻表!'||chr(10)||'<br>';
                   goto continue;
                elsif li_num=1 then
                   select start_time,run_days into ls_zdz_gcz_st,li_zdz_gcz_day from train_schedule
                     where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(ls_zdz_gczm));
                   if ls_zdz_gcz_st = '-' then
                      select arrive_time into ls_zdz_gcz_st from train_schedule
                        where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(ls_zdz_gczm));
                   end if;
                end if;
                --
                ls_zdz_gcz_qsrq := to_char(to_date(v_qsrq,'YYYYMMDD') + (li_zdz_day + li_fts + li_zdz_gcz_day - li_gcz_day),'YYYYMMDD');
                if to_number(ls_zdz_gcz_st)>=0 and to_number(ls_zdz_gcz_st)<600 then
                   ls_zdz_gcz_jhrq := ls_zdz_gcz_qsrq;
                   ls_zdz_gcz_sjd := '1';
                elsif to_number(ls_zdz_gcz_st)>=600 and to_number(ls_zdz_gcz_st)<1800 then
                   ls_zdz_gcz_jhrq := ls_zdz_gcz_qsrq;
                   ls_zdz_gcz_sjd := '2';
                else
                   ls_zdz_gcz_jhrq := to_char(to_date(v_qsrq,'YYYYMMDD') + 1,'YYYYMMDD');
                   ls_zdz_gcz_sjd := '1';
                end if;
                if v_zy='挂' then
                   ls_zdz_gcz_zgnr := ls_zdz_gcz_zgnr||'存站';
                   li_count:=0;
                   li_w :=1;
                   while li_count <= li_jgts loop
                       if li_w > (li_jgts - li_cdzs) and vb_cql then
                          insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                             values(to_char(to_date(ls_zdz_gcz_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                    ls_zdz_gcz_sjd,
                                    ls_zdz_gcz_fjmc,
                                    ls_zdz_gczm,
                                    gettraincode(ls_fcc),
                                    '甩',
                                    ls_lhwz,
                                    ls_zdz_gcz_zgnr,
                                    to_date(v_mlrq,'YYYYMMDD'),
                                    v_mlh,
                                    v_mlxh,
                                    v_zrxh);
                       elsif vb_cql then
                          insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                             values(to_char(to_date(ls_zdz_gcz_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                    ls_zdz_gcz_sjd,
                                    ls_zdz_gcz_fjmc,
                                    ls_zdz_gczm,
                                    gettraincode(ls_fcc),
                                    '原列',
                                    ls_lhwz,
                                    ls_zgnr,--ls_zdz_gcz_zgnr,
                                    to_date(v_mlrq,'YYYYMMDD'),
                                    v_mlh,
                                    v_mlxh,
                                    v_zrxh);
                       else
                          insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                             values(to_char(to_date(ls_zdz_gcz_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                    ls_zdz_gcz_sjd,
                                    ls_zdz_gcz_fjmc,
                                    ls_zdz_gczm,
                                    gettraincode(ls_fcc),
                                    '甩',
                                    ls_lhwz,
                                    ls_zdz_gcz_zgnr,--ls_zdz_gcz_zgnr,
                                    to_date(v_mlrq,'YYYYMMDD'),
                                    v_mlh,
                                    v_mlxh,
                                    v_zrxh);
                       end if;
                       if vb_grbz then
                          li_count:=li_count + 1;
                          li_w := li_w + 1;
                       end if;
                       if vb_yzcd then
                          li_count:=li_count + li_cdzs;
                          li_w := li_w + li_cdzs;
                       end if;
                       li_count:=li_count+ 1;
                       li_w := li_w + 1;
                   end loop;
                else
                   ls_zdz_gcz_zgnr := '挂'||ls_zdz_gcz_zgnr||'恢复原编组';
                   li_count:=0;
                   li_w := 1;
                   while li_count <= li_jgts loop
                      if li_w > (li_jgts - li_cdzs) and vb_cql then
                         insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                             values(to_char(to_date(ls_zdz_gcz_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                    ls_zdz_gcz_sjd,
                                    ls_zdz_gcz_fjmc,
                                    ls_zdz_gczm,
                                    gettraincode(ls_fcc),
                                    '挂',
                                    ls_lhwz,
                                    ls_zdz_gcz_zgnr,
                                    to_date(v_mlrq,'YYYYMMDD'),
                                    v_mlh,
                                    v_mlxh,
                                    v_zrxh);
                       elsif vb_cql then
                          insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                             values(to_char(to_date(ls_zdz_gcz_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                    ls_zdz_gcz_sjd,
                                    ls_zdz_gcz_fjmc,
                                    ls_zdz_gczm,
                                    gettraincode(ls_fcc),
                                    '原列',
                                    ls_lhwz,
                                    ls_zgnr,--ls_zdz_gcz_zgnr,
                                    to_date(v_mlrq,'YYYYMMDD'),
                                    v_mlh,
                                    v_mlxh,
                                    v_zrxh);
                       else
                          insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                             values(to_char(to_date(ls_zdz_gcz_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                    ls_zdz_gcz_sjd,
                                    ls_zdz_gcz_fjmc,
                                    ls_zdz_gczm,
                                    gettraincode(ls_fcc),
                                    '挂',
                                    ls_lhwz,
                                    ls_zdz_gcz_zgnr,--ls_zdz_gcz_zgnr,
                                    to_date(v_mlrq,'YYYYMMDD'),
                                    v_mlh,
                                    v_mlxh,
                                    v_zrxh);
                       end if;
                       if vb_grbz then
                          li_count:=li_count + 1;
                          li_w := li_w + 1;
                       end if;
                       if vb_yzcd then
                          li_count:=li_count + li_cdzs;
                          li_w := li_w + li_cdzs;
                       end if;
                       li_count:=li_count+ 1;
                       li_w := li_w + 1;
                   end loop;
                end if;
             end if;--ls_zdz_gcz='XXQ'
             if length(ls_zdz)=3 then
                if substr(ls_zdz,3,1) = ls_lj then
                   select b.subbureau_short_name into ls_zdz_fjmc from b_station a,b_subbureau b
                     where b.subbureau_code=a.subbureau_code and a.station_telecode=ls_zdz;
                   select start_time,run_days into ls_zdz_st,li_zdz_day from train_schedule
                     where train_kpid=v_train_id and ltrim(rtrim(sta_name)) = ltrim(rtrim(ls_zdzm));
                   if ls_zdz_st = '-' then
                      select arrive_time into ls_zdz_st from train_schedule
                        where train_kpid=v_train_id and ltrim(rtrim(sta_name)) = ltrim(rtrim(ls_zdzm));
                   end if;
                   --2004-08-24 针对基础数据不完善
                   select count(*) into li_num from train_schedule
                     where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(ls_zdzm)) and sta_sort='01';
                   if li_num=0 then
                      p_rtnstring:=p_rtnstring||v_mlhm||'令'||gettraincode(ls_fcc)||'次无'||ls_zdzm||'对应的时刻表!'||chr(10)||'<br>';
                      goto continue;
                   elsif li_num>1 then
                      p_rtnstring:=p_rtnstring||v_mlhm||'令'||gettraincode(ls_fcc)||'次中有一个以上的'||ls_zdzm||'营业站!'||chr(10)||'<br>';
                      goto continue;
                   elsif li_num=1 then
                      select start_time into ls_zdzf_st from train_schedule
                        where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(ls_zdzm)) and sta_sort='01';
                      if ls_zdzf_st = '-' then
                         select arrive_time into ls_zdzf_st from train_schedule
                           where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(ls_zdzm)) and sta_sort='01';
                      end if;
                   end if;
                   --2004-08-24
                   ls_zdz_qsrq :=to_char(to_date(v_qsrq,'YYYYMMDD') + (li_zdz_day - li_gcz_day),'YYYYMMDD');
                   if to_number(ls_zdz_st)>=0 and to_number(ls_zdz_st)<600 then
                      ls_zdz_jhrq := ls_zdz_qsrq;
                      ls_zdz_sjd := '1';
                   elsif to_number(ls_zdz_st)>=600 and to_number(ls_zdz_st)<1800 then
                      ls_zdz_jhrq := ls_zdz_qsrq;
                      ls_zdz_sjd := '2';
                   else
                      ls_zdz_jhrq := to_char(to_date(ls_zdz_qsrq,'YYYYMMDD') + 1,'YYYYMMDD');
                      ls_zdz_sjd := '1';
                   end if;
                   ls_zdzf_qsrq := to_char(to_date(v_qsrq,'YYYYMMDD') + (li_zdz_day + li_fts - li_gcz_day),'YYYYMMDD');
                   if to_number(ls_zdzf_st)>=0 and to_number(ls_zdzf_st)<600 then
                      ls_zdzf_jhrq := ls_zdzf_qsrq;
                      ls_zdzf_sjd := '1';
                   elsif to_number(ls_zdzf_st)>=600 and to_number(ls_zdzf_st)<1800 then
                      ls_zdzf_jhrq := ls_zdzf_qsrq;
                      ls_zdzf_sjd := '2';
                   else
                      ls_zdzf_jhrq := to_char(to_date(ls_zdzf_qsrq,'YYYYMMDD') + 1,'YYYYMMDD');
                      ls_zdzf_sjd := '1';
                   end if;
                   if v_zy='挂' then
                      if ls_zdz_jhrq=ls_zdzf_jhrq and ls_zdz_sjd=ls_zdzf_sjd then
                         if v_qtlh='原列欠车' then
                            ls_zdz_zgnr := ls_zdz_zgnr||'欠车'||v_gczm||','||gettraincode(ls_fcc)||'次欠车'||v_gczm;
                         elsif v_qtlh='原列充组' then
                            ls_zdz_zgnr := ls_zdz_zgnr||'充组'||v_gczm||','||gettraincode(ls_fcc)||'次充组'||v_gczm;
                         else
                            ls_zdz_zgnr := ls_zdz_zgnr||'利回'||v_gczm||','||gettraincode(ls_fcc)||'次利回'||v_gczm;
                         end if;
                         li_count:=0;
                         li_w := 1;
                         while li_count <= li_jgts loop
                             insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                                   values(to_char(to_date(ls_zdz_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                          ls_zdz_sjd,
                                          ls_zdz_fjmc,
                                          ls_zdzm,
                                          v_cc,
                                          '原列',
                                          ls_lhwz,
                                          ls_zdz_zgnr,
                                          to_date(v_mlrq,'YYYYMMDD'),
                                          v_mlh,
                                          v_mlxh,
                                          v_zrxh);
                             if vb_grbz then
                                li_count:=li_count + 1;
                                li_w := li_w + 1;
                             end if;
                             if vb_yzcd then
                                li_count:=li_count + li_cdzs;
                                li_w := li_w + li_cdzs;
                             end if;
                             li_count:=li_count+ 1;
                             li_w := li_w + 1;
                         end loop;
                      else
                         --
                         if v_qtlh='原列欠车' then
                             ls_zdz_zgnr := ls_zdz_zgnr||'欠车'||v_gczm;
                         elsif v_qtlh='原列充组' then
                             ls_zdz_zgnr := ls_zdz_zgnr||'充组'||v_gczm;
                         else
                             ls_zdz_zgnr := ls_zdz_zgnr||'利回'||v_gczm;
                         end if;
                         li_count:=0;
                         li_w := 1;
                         while li_count <= li_jgts loop
                             insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                                   values(to_char(to_date(ls_zdz_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                          ls_zdz_sjd,
                                          ls_zdz_fjmc,
                                          ls_zdzm,
                                          v_cc,
                                          '原列',
                                          ls_lhwz,
                                          ls_zdz_zgnr,
                                          to_date(v_mlrq,'YYYYMMDD'),
                                          v_mlh,
                                          v_mlxh,
                                          v_zrxh);
                             if vb_grbz then
                                li_count:=li_count + 1;
                                li_w :=li_w + 1;
                             end if;
                             if vb_yzcd then
                                li_count:=li_count + li_cdzs;
                                li_w := li_w + li_cdzs;
                             end if;
                             li_count:=li_count+ 1;
                             li_w := li_w + 1;
                         end loop;
                         --
                         li_count:=0;
                         li_w := 1;
                         while li_count <= li_jgts loop
                             insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                                   values(to_char(to_date(ls_zdzf_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                          ls_zdzf_sjd,
                                          ls_zdz_fjmc,
                                          ls_zdzm,
                                          gettraincode(ls_fcc),
                                          '原列',
                                          ls_lhwz,
                                          ls_zdz_zgnr,
                                          to_date(v_mlrq,'YYYYMMDD'),
                                          v_mlh,
                                          v_mlxh,
                                          v_zrxh);
                             if vb_grbz then
                                li_count:=li_count + 1;
                                li_w := li_w + 1;
                             end if;
                             if vb_yzcd then
                                li_count:=li_count + li_cdzs;
                                li_w := li_w + li_cdzs;
                             end if;
                             li_count:=li_count+ 1;
                             li_w := li_w + 1;
                         end loop;
                      end if;
                   else
                      if ls_zdz_jhrq=ls_zdzf_jhrq and ls_zdz_sjd=ls_zdzf_sjd then
                         ls_zdz_zgnr := '欠'||ls_zdz_zgnr||'运行'||v_gczm||','||gettraincode(ls_fcc)||'次欠车运行'||v_gczm;
                         li_count:=0;
                         li_w := 1;
                         while li_count <= li_jgts loop
                             insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                                   values(to_char(to_date(ls_zdz_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                          ls_zdz_sjd,
                                          ls_zdz_fjmc,
                                          ls_zdzm,
                                          v_cc,
                                          '欠车',
                                          ls_lhwz,
                                          ls_zdz_zgnr,
                                          to_date(v_mlrq,'YYYYMMDD'),
                                          v_mlh,
                                          v_mlxh,
                                          v_zrxh);
                             if vb_grbz then
                                li_count:=li_count + 1;
                                li_w := li_w + 1;
                             end if;
                             if vb_yzcd then
                                li_count:=li_count + li_cdzs;
                                li_w := li_w + li_cdzs;
                             end if;
                             li_count:=li_count+ 1;
                             li_w := li_w + 1;
                         end loop;
                      else
                         --
                         ls_zdz_zgnr := '欠'||ls_zdz_zgnr||'运行'||v_gczm;
                         li_count:=0;
                         li_w := 1;
                         while li_count <= li_jgts loop
                             insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                                   values(to_char(to_date(ls_zdz_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                          ls_zdz_sjd,
                                          ls_zdz_fjmc,
                                          ls_zdzm,
                                          v_cc,
                                          '欠车',
                                          ls_lhwz,
                                          ls_zdz_zgnr,
                                          to_date(v_mlrq,'YYYYMMDD'),
                                          v_mlh,
                                          v_mlxh,
                                          v_zrxh);
                             if vb_grbz then
                                li_count:=li_count + 1;
                                li_w := li_w + 1;
                             end if;
                             if vb_yzcd then
                                li_count:=li_count + li_cdzs;
                                li_w := li_w + li_cdzs;
                             end if;
                             li_count:=li_count+ 1;
                             li_w := li_w + 1;
                         end loop;
                         --
                         li_count:=0;
                         li_w := 1;
                         while li_count <= li_jgts loop
                             insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                                   values(to_char(to_date(ls_zdzf_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                          ls_zdzf_sjd,
                                          ls_zdz_fjmc,
                                          ls_zdzm,
                                          gettraincode(ls_fcc),
                                          '欠车',
                                          ls_lhwz,
                                          ls_zdz_zgnr,
                                          to_date(v_mlrq,'YYYYMMDD'),
                                          v_mlh,
                                          v_mlxh,
                                          v_zrxh);
                             if vb_grbz then
                                li_count:=li_count + 1;
                                li_w := li_w + 1;
                             end if;
                             if vb_yzcd then
                                li_count:=li_count + li_cdzs;
                                li_w := li_w + li_cdzs;
                             end if;
                             li_count:=li_count+ 1;
                             li_w := li_w + 1;
                         end loop;
                      end if;
                   end if;
                end if;--ls_zdz='XXQ'
             end if;--ls_zdz length is 3
          end if;
       end if;
    end if;--v_qtlh!=' '
    /*一往返、原列利回作业生成结束*/
    /*调尾调度作业生成开始*/
    if v_dwcz1 != ' ' then
       if substr(v_dwcz1,3,1) = ls_lj then
          select b.subbureau_short_name into ls_dwcz1_fjmc from b_station a,b_subbureau b
            where b.subbureau_code=a.subbureau_code and a.station_telecode=v_dwcz1;
          select start_time,run_days,sta_sort into ls_dwcz1_st,li_dwcz1_day,ls_dwcz1_no from train_schedule
            where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(v_dwczm1));
          if ls_dwcz1_st = '-' then
             select arrive_time into ls_dwcz1_st from train_schedule
               where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(v_dwczm1));
          end if;
          if to_number(ls_scz_no)!=0 then
             if to_number(ls_dwcz1_no)<=to_number(ls_scz_no) then
                vb_dwcz1 := true;
             end if;
          else
             if to_number(ls_dwcz1_no) > to_number(ls_gcz_no) then
                vb_dwcz1 :=true;
             end if;
          end if;
          if vb_dwcz1 then
             ls_dwcz1_qsrq := to_char(to_date(v_qsrq,'YYYYMMDD') + (li_dwcz1_day - li_gcz_day),'YYYYMMDD');
             if to_number(ls_dwcz1_st)>=0 and to_number(ls_dwcz1_st)<600 then
                ls_dwcz1_jhrq := ls_dwcz1_qsrq;
                ls_dwcz1_sjd := '1';
             elsif to_number(ls_dwcz1_st)>=600 and to_number(ls_dwcz1_st)<1800 then
                ls_dwcz1_jhrq := ls_dwcz1_qsrq;
                ls_dwcz1_sjd := '2';
             else
                ls_dwcz1_jhrq := to_char(to_date(ls_dwcz1_qsrq,'YYYYMMDD') + 1,'YYYYMMDD');
                ls_dwcz1_sjd := '1';
             end if;
             ls_dwcz1_zgnr:=ls_dwcz1_zgnr||'调尾';
             li_count:=0;
             while li_count <= li_jgts loop
             li_w:=li_w + 1;
                 insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                       values(to_char(to_date(ls_dwcz1_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                              ls_dwcz1_sjd,
                              ls_dwcz1_fjmc,
                              v_dwczm1,
                              v_cc,
                              '调头',
                              '尾部',
                              ls_dwcz1_zgnr,
                              to_date(v_mlrq,'YYYYMMDD'),
                              v_mlh,
                              v_mlxh,
                              v_zrxh);
                 if vb_grbz then
                    li_count:=li_count + 1;
                 end if;
                 if vb_yzcd then
                    li_count:=li_count + li_cdzs;
                 end if;
                 li_count:=li_count+ 1;
             end loop;
          else
             p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次车调尾车站站序应该在挂车站与甩车站之间!'||chr(10)||'<br>';
             goto continue;
          end if;
       end if;
       if v_dwcz2 != ' ' then
          if substr(v_dwcz2,3,1) = ls_lj then
             select b.subbureau_short_name into ls_dwcz2_fjmc from b_station a,b_subbureau b
               where b.subbureau_code=a.subbureau_code and a.station_telecode=v_dwcz2;
             select start_time,run_days,sta_sort into ls_dwcz2_st,li_dwcz2_day,ls_dwcz2_no from train_schedule
               where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(v_dwczm2));
             if ls_dwcz2_st = '-' then
                select arrive_time into ls_dwcz2_st from train_schedule
                  where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(v_dwczm2));
             end if;
             if to_number(ls_dwcz2_no)>to_number(ls_dwcz1_no) then
                vb_dwcz2 := true;
             end if;
             if vb_dwcz2 then
                ls_dwcz2_qsrq := to_char(to_date(v_qsrq,'YYYYMMDD') + (li_dwcz2_day - li_gcz_day),'YYYYMMDD');
                if to_number(ls_dwcz2_st)>=0 and to_number(ls_dwcz2_st)<600 then
                   ls_dwcz2_jhrq := ls_dwcz2_qsrq;
                   ls_dwcz2_sjd := '1';
                elsif to_number(ls_dwcz2_st)>=600 and to_number(ls_dwcz2_st)<1800 then
                   ls_dwcz2_jhrq := ls_dwcz2_qsrq;
                   ls_dwcz2_sjd := '2';
                else
                   ls_dwcz2_jhrq := to_char(to_date(ls_dwcz2_qsrq,'YYYYMMDD') + 1,'YYYYMMDD');
                   ls_dwcz2_sjd := '1';
                end if;
                ls_dwcz2_zgnr:=ls_dwcz2_zgnr||'调尾';
                li_count:=0;
                while li_count <= li_jgts loop
                li_w:=li_w + 1;
                    insert into k_kdjhb(rq,sjd,fjjc,zm,cc,zg,wz,zgnr,mlrq,mlh,mlxh,zrxh)
                          values(to_char(to_date(ls_dwcz2_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                 ls_dwcz2_sjd,
                                 ls_dwcz2_fjmc,
                                 v_dwczm2,
                                 v_cc,
                                 '调头',
                                 '尾部',
                                 ls_dwcz2_zgnr,
                                 to_date(v_mlrq,'YYYYMMDD'),
                                 v_mlh,
                                 v_mlxh,
                                 v_zrxh);
                    if vb_grbz then
                       li_count:=li_count + 1;
                    end if;
                    if vb_yzcd then
                       li_count:=li_count + li_cdzs;
                    end if;
                    li_count:=li_count+ 1;
                end loop;
             else
                p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次车第二调尾站应该在第一调尾站之后!'||chr(10)||'<br>';
                goto continue;
             end if;--vb_dwcz2=true
          end if;
       end if;--v_dwcz2!=' '
    end if;
    /*调尾调度作业生成结束*/
    --p_rtnstring:=p_rtnstring||'令：'||v_mlhm||'！'||chr(10);
    <<continue>>
    li_num:=0;--废语句
  end loop;
  <<break>>
  close c_cgkdl;
  if b_successful then
     p_rtnstring:=p_rtnstring||'生成计划结束！'||chr(10)||'<br>';
     v_successful:='true';
     commit;
  else
     p_rtnstring:=p_rtnstring||'生成计划失败！'||chr(10)||'<br>';
     v_successful:='false';
     rollback;
  end if;
END Create_Kdjhb;
/

