create view RUN_POINT_VIEW as
  (select runline_id,station_name,arr_date,go_date,arr_time,go_time,station_type,arr_sj,go_sj from run_point
UNION
select runline_id,station_name,arr_date,go_date,arr_time,go_time,station_type,arr_sj,go_sj from run_point_detail) order by arr_sj
/

