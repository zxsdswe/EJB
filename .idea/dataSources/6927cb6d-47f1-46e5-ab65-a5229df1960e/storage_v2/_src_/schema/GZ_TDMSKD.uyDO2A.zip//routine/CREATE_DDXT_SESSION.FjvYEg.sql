create procedure create_ddxt_session is
sqlStr varchar2(1000);

 v_ErrorCode   NUMBER;                     --   Code   for   the   error
 v_ErrorMsg     VARCHAR2(200);       --   Message   text   for   the   error
 v_CurrentUser   VARCHAR2(8);       --   Current   database   user
 v_Information   VARCHAR2(100);   --   Information   about   the   error
type ref_cursor_type is ref cursor;
c_xs ref_cursor_type;


/*定义变量*/



  li_num number(2):=0;
  v_successful varchar2(1);
  l_kssj date;





begin

v_successful := '1';

select sysdate into l_kssj from dual;

--insert into ddxt_client select t.*,sysdate from v$session t where t.CLIENT_INFO is null;
--commit;

insert into ddxt_session(lx,username,sl,kssj) select '1',a.*,l_kssj from (select t.USERNAME,count(*) from v$session t group by t.USERNAME order by 2 desc)a;
commit;

insert into ddxt_session(lx,CLIENT_INFO,sl,kssj) select '2',a.*,l_kssj from (select t.CLIENT_INFO,count(*) from v$session t group by t.CLIENT_INFO order by 2 desc) a where rownum<50;
commit;

insert into ddxt_session(lx,username,CLIENT_INFO,sl,kssj) select '3',a.*,l_kssj from (select t.USERNAME,t.CLIENT_INFO,count(*) from v$session t group by t.USERNAME,t.CLIENT_INFO order by 3 desc)a where rownum<50;
commit;

insert into ddxt_session(lx,sl,kssj)select '4',count(*),l_kssj from v$process t;
commit;


--delete from ddxt_client where czsj<sysdate - 1/24;
--commit;

delete from ddxt_session where czsj<sysdate - 1/24 and lx<'4';
commit;






  EXCEPTION
   WHEN OTHERS THEN
   v_ErrorCode   :=   SQLCODE;
   v_ErrorMsg   :=   SQLERRM;
   v_CurrentUser   :=   USER;
   v_Information   :=   'Error   encountered   on   '   ||   TO_CHAR(SYSDATE)   ||   '   by   database   user   '   ||   v_CurrentUser;
   ROLLBACK;
   RETURN;
end create_ddxt_session;
/

