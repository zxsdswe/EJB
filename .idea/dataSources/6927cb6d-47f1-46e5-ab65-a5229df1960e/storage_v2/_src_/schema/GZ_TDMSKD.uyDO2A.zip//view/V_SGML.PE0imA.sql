create view V_SGML as
  select rawtohex(sys_guid()) as guid,a.rq,a.mlh,a.mlxh,a.zrxh,a.qsrq,a.zzrq,a.grbz,a.cc,a.gczm,a.sgwz,a.zy,a.cs,b.cz,b.ch,'1' as ls,a.yt,a.qtlh from sgml a,sgcl b where a.rq = b.rq and a.mlh = b.mlh and a.mlxh = b.mlxh and a.zrxh = b.zrxh
/

