create PACKAGE BODY COPY_DATA
IS
   PROCEDURE copy_sk (kyfa_src VARCHAR2, kyfa_tar VARCHAR2)
   AS
      v_errmsg         VARCHAR2 (200);
      train_id_local   NUMBER;
      flag             BOOLEAN;
   BEGIN
      DELETE FROM train_copy;

      DELETE FROM train_info_tmp;

      DELETE FROM train_schedule_tmp;

      COMMIT;

      INSERT INTO train_copy
         SELECT train_no, train_id, kyfa_tar
           FROM train_info
          WHERE train_no LIKE 'D%' or train_no LIKE 'C%'AND PLAN = kyfa_src;

      COMMIT;

      FOR c IN (SELECT train_id, PLAN
                  FROM train_copy)
      LOOP
         SELECT train_id_s.NEXTVAL
           INTO train_id_local
           FROM DUAL;

         INSERT INTO train_info_tmp
            SELECT train_id_local, a.train_kpid, a.train_no, a.train_code,
                   a.subbureau_code, a.run_cycle, a.run_rule,
                   a.begin_sta_code, a.begin_sta_name, a.end_sta_code,
                   a.end_sta_name, a.back_train_kpid, a.back_train_no,
                   a.back_days, a.pass_burs, a.pass_subburs, a.begin_axes,
                   a.most_axes, a.GROUPS, kyfa_tar, a.base_id, a.route_id,
                   a.start_date, a.stop_date, a.train_type, a.note, a.token,
                   a.car_attribute, a.engine_type
              FROM train_info a
             WHERE a.train_id = c.train_id;

         INSERT INTO train_schedule_tmp
            SELECT a.start_date, a.stop_date, train_id_local, a.train_kpid,
                   a.train_no, a.sta_sort, a.sta_name, a.sta_code,
                   a.subbur_code, a.bureau_code, a.arrive_time, a.start_time,
                   a.arrive_train, a.start_train, a.sta_type, a.sta_type2,
                   a.run_days
              FROM train_schedule a
             WHERE a.train_id = c.train_id;

         COMMIT;
      END LOOP;
--select * from train_info_tmp;
--select * from train_schedule_tmp;

   insert into train_info select * from train_info_tmp;
   insert into train_schedule select * from train_schedule_tmp;
   commit;
   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         v_errmsg := SQLERRM;

         INSERT INTO copy_data_log
                     (v1
                     )
              VALUES (v_errmsg
                     );

         COMMIT;
   END;

   PROCEDURE copy_hk (kyfa_name VARCHAR2, jbt_id NUMBER)
   AS
      v_errmsg         VARCHAR2 (200);
      train_id_local   NUMBER;
      flag             BOOLEAN;
   BEGIN
      DELETE FROM train_copy;

      DELETE FROM train_info_tmp;

      DELETE FROM train_schedule_tmp;

      COMMIT;

      INSERT INTO train_copy
         SELECT train_num1, base_line_id, kyfa_name PLAN
           FROM dic_base_line
          WHERE chartid = jbt_id
            AND (   train_num1 LIKE '0%'
                 
                 OR train_num1 LIKE '57%'
                 OR train_num1 LIKE '72%'
                 OR (train_num1 LIKE '86%' AND LENGTH (train_num1) = 4)
                );

      COMMIT;

      FOR c IN (SELECT train_id, PLAN
                  FROM train_copy)
      LOOP
         SELECT train_id_s.NEXTVAL
           INTO train_id_local
           FROM DUAL;

         INSERT INTO train_info_tmp
            SELECT train_id_local, '?', a.train_num1, a.train_num1, 'Q', 0,
                   '1', 'Q', '?', 'Q', '?', a.base_line_id, a.base_line_id, 0,
                   '', 'Q', 0, 0, 2, kyfa_name, a.base_line_id, route_id,
                   a.begin_use_time, a.end_use_time, '', '', '', '', 0
              FROM dic_base_line a
             WHERE a.base_line_id = c.train_id;

         INSERT INTO train_schedule_tmp
            SELECT a.begin_use_time, a.end_use_time, train_id_local,
                   train_id_local, a.train_num1, b.node_order, b.stn, '?',
                   '?', 'Q', REPLACE (b.arr_time, ':', ''),
                   REPLACE (b.dep_time, ':', ''), '', '', '1E', '4', '0'
              FROM dic_base_line a, dic_base_line_node b
             WHERE a.base_line_id = b.base_line_id
               AND b.arr_time <> b.dep_time
               AND a.base_line_id = c.train_id;

         COMMIT;
      END LOOP;
   EXCEPTION
      WHEN OTHERS
      THEN
         ROLLBACK;
         v_errmsg := SQLERRM;

         INSERT INTO copy_data_log
                     (v1
                     )
              VALUES (v_errmsg
                     );

         COMMIT;
   END;

   FUNCTION update_sta (kyfa_name VARCHAR2)
      RETURN BOOLEAN
   IS
      RESULT   BOOLEAN;
   BEGIN
      BEGIN
         FOR c IN (SELECT   train_id, MIN (sta_sort) sta_sort
                       FROM train_schedule_tmp
                      WHERE train_id IN (SELECT train_id
                                           FROM train_info_tmp
                                          WHERE PLAN = kyfa_name)
                   GROUP BY train_id)
         LOOP
            UPDATE train_info_tmp
               SET begin_sta_name = get_station (c.train_id, c.sta_sort)
             WHERE train_id = c.train_id;

            COMMIT;
         END LOOP;

         FOR c IN (SELECT   train_id, MAX (sta_sort) sta_sort
                       FROM train_schedule_tmp
                      WHERE train_id IN (SELECT train_id
                                           FROM train_info_tmp
                                          WHERE PLAN = kyfa_name)
                   GROUP BY train_id)
         LOOP
            UPDATE train_info_tmp
               SET end_sta_name = get_station (c.train_id, c.sta_sort)
             WHERE train_id = c.train_id;

            COMMIT;
         END LOOP;

/*
         UPDATE train_schedule_tmp
            SET sta_type='1'
          WHERE start_time = arrive_time;
*/
         UPDATE train_schedule_tmp
            SET arrive_time = start_time
          WHERE arrive_time = '-100';

         UPDATE train_schedule_tmp
            SET start_time = arrive_time
          WHERE start_time = '-100';

         UPDATE train_schedule_tmp
            SET sta_type = '1'
          WHERE train_no LIKE '0%';

         UPDATE train_info_tmp a
            SET begin_sta_code = (SELECT station_telecode
                                    FROM b_station b
                                   WHERE a.begin_sta_name = b.station_name);

         UPDATE train_info_tmp a
            SET end_sta_code = (SELECT station_telecode
                                  FROM b_station b
                                 WHERE a.end_sta_name = b.station_name);

         UPDATE train_schedule_tmp a
            SET sta_code = NVL ((SELECT station_telecode
                                   FROM b_station b
                                  WHERE a.sta_name = b.station_name), '???');

         COMMIT;
         RESULT := TRUE;
      EXCEPTION
         WHEN OTHERS
         THEN
            ROLLBACK;
            COMMIT;
            RESULT := FALSE;
      END;

      RETURN (RESULT);
   END;

--2010年1月16日 陈历泉
   FUNCTION get_station (v_train_id NUMBER, v_sta_sort NUMBER)
      RETURN VARCHAR2
   IS
      RESULT   VARCHAR2 (30);
   BEGIN
      SELECT TRIM (sta_name)
        INTO RESULT
        FROM train_schedule_tmp
       WHERE train_id = v_train_id AND sta_sort = v_sta_sort;

      RETURN (RESULT);
   END;
END;
/

