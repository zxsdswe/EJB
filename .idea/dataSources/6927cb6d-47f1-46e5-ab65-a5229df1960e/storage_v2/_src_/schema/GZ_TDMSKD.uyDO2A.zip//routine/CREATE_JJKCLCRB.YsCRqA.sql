create PROCEDURE CREATE_JJKCLCRB (
  p_mlrq in sgml.rq%TYPE,
  p_mlh in sgml.mlh%TYPE,
  cmd_begin in number,
  cmd_end in number,
  p_rtnstring out varchar2,
  v_successful out varchar2) IS
    /*定义游标*/
  cursor c_cgkdl is select distinct rq,mlh,mlxh,qsrq,zzrq,gcz,gczm,cc,sgwz,
                           zy,cs,ls,yt,scz,sczm,zcz,zczm,qtlh,lhwz,fscz,fsczm,dwcz1,
                           dwczm1,dwcz2,dwczm2,grbz,zrxh,action,action_date from sgml
                           where cc not like '00%' and ((to_number(mlh)>=cmd_begin and to_number(mlh)<=cmd_end) or (to_number(mlh)>=8201 and to_number(mlh)<=8299))
                                 and to_char(rq,'YYYYMMDD')||mlh||decode(length(to_char(mlxh)),2,to_char(mlxh),0||to_char(mlxh))||decode(length(to_char(zrxh)),2,to_char(zrxh),0||to_char(zrxh)) not in(select distinct to_char(rq,'YYYYMMDD')||mlh||decode(length(to_char(mlxh)),2,to_char(mlxh),0||to_char(mlxh))||decode(length(to_char(zrxh)),2,to_char(zrxh),0||to_char(zrxh)) from sgml where action=-1)
                                 and(
                                 (rq=p_mlrq and mlh=p_mlh)
                                  or to_char(zzrq,'YYYYMMDD')='20991231'
                                  or (action>0 and to_char(action_date,'YYYYMMDD')=to_char(p_mlrq,'YYYYMMDD')
                                  )
                                 )
                           order by rq,mlh,mlxh,zrxh;
  cursor c_noch(pcl_mlrq varchar2,pcl_mlh varchar2,pcl_mlxh number,
                   pcl_zrxh number) is
                   select distinct cz from sgcl where to_char(rq,'YYYYMMDD')=pcl_mlrq and trim(mlh)=trim(pcl_mlh) and mlxh=pcl_mlxh and zrxh=pcl_zrxh and ch is null order by cz;
  cursor c_havech(pcl_mlrq varchar2,pcl_mlh varchar2,pcl_mlxh number,
                   pcl_zrxh number) is
                   select cz,ch from sgcl where to_char(rq,'YYYYMMDD')=pcl_mlrq and trim(mlh)=trim(pcl_mlh) and mlxh=pcl_mlxh and zrxh=pcl_zrxh and ch is not null order by cz;
  cursor c_jjk(jjk_cc varchar2,jjk_gcz_no varchar2,jjk_scz_no varchar2) is
              select sta_name,start_time,run_days from train_schedule
                where train_kpid=jjk_cc and to_number(sta_sort)>=to_number(jjk_gcz_no) and to_number(sta_sort)<=to_number(jjk_scz_no)
                  and sta_type='3';
  cursor c_temp_cz_ch is select cz_ch from k_temp_cz_ch;
  cursor c_cancel is select rq,mlh,mlxh,zrxh
                   from sgml
                   where ((to_number(mlh)>=cmd_begin and to_number(mlh)<=cmd_end) or (to_number(mlh)>=8201 and to_number(mlh)<=8299))
                         and action=-1 and to_char(action_date,'YYYYMMDD')=to_char(p_mlrq,'YYYYMMDD')
                   order by rq,mlh,mlxh,zrxh;
  /*判断用变量*/
  li_num number(3):=0;
  li_w number(5):=0;
  /*循环变量*/
  li_count number(4):=0;--while 用
  /*局界口查询使用变量*/
  ls_jjk_name varchar2(12);
  ls_jjk_st varchar2(4);
  li_jjk_day number(3);
  ls_jjk2_name varchar2(12);
  ls_jjk2_st varchar2(4);
  li_jjk2_day number(3);
  ls_ybrq varchar2(8);
  ls_jhrq varchar2(8);
  ls_ybrq2 varchar2(8);
  ls_jhrq2 varchar2(8);
  ls_zdz_jjk_name varchar2(12);
  ls_zdz_jjk_st varchar2(4);
  li_zdz_jjk_day number(3);
  ls_zdz_jjk2_name varchar2(12);
  ls_zdz_jjk2_st varchar2(4);
  li_zdz_jjk2_day number(3);
  ls_zdz_jjk_ybrq varchar2(8);
  ls_zdz_jjk_jhrq varchar2(8);
  ls_zdz_jjk2_ybrq varchar2(8);
  ls_zdz_jjk2_jhrq varchar2(8);
  /*存储所用变量*/
  ls_crbz varchar2(1);
  ls_lj varchar2(1);
  /*车辆库使用变量*/
  ls_noch_cz varchar2(20);
  li_liangs number(2);
  ls_havecz varchar2(20);
  ls_havech varchar2(20);
  ls_cz_ch varchar2(20);
  /*定义局部变量*/
  vb_grbz boolean;
  vb_yzcd boolean;
  li_cdzs number(2);
  li_jgts number(4);
  ls_zdz varchar2(3);
  ls_zdzm varchar2(20);
  ls_fcc varchar2(8);
  li_fts number(2);
  ls_gcz_no varchar2(2);
  li_gcz_day number(3);
  ls_scz_no varchar2(2);
  li_zdz_day number(3);
  ls_zdz_gcz_no varchar2(2);
  /*常规命令使用的变量*/
  v_cgkdl c_cgkdl%rowtype;
  --
  v_mlrq varchar2(8);
  v_qsrq varchar2(8);
  v_zzrq varchar2(8);
  vv_qsrq varchar2(8);
  v_action_date varchar2(8);
  --
  v_action sgml.action%type;
  v_mlh sgml.mlh%type;
  v_mlxh sgml.mlxh%type;
  v_gcz sgml.gcz%type;
  v_gczm sgml.gczm%type;
  v_cc sgml.cc%type;
  v_sgwz sgml.sgwz%type;
  v_zy sgml.zy%type;
  v_cs sgml.cs%type;
  v_ls sgml.ls%type;
  v_yt sgml.yt%type;
  v_scz sgml.scz%type;
  v_sczm sgml.sczm%type;
  v_zcz sgml.zcz%type;
  v_zczm sgml.zczm%type;
  v_qtlh sgml.qtlh%type;
  v_lhwz sgml.lhwz%type;
  v_fscz sgml.fscz%type;
  v_fsczm sgml.fsczm%type;
  v_dwcz1 sgml.dwcz1%type;
  v_dwczm1 sgml.dwczm1%type;
  v_dwcz2 sgml.dwcz2%type;
  v_dwczm2 sgml.dwczm2%type;
  v_grbz sgml.grbz%type;
  v_zrxh sgml.zrxh%type;
  v_mlhm varchar2(20);
  --客票八位车次
  v_train_id train_schedule.train_kpid%type;
  --客票八位车次
  --事务成功标志
  b_successful boolean;
  --事务成功标志
  --取消令
  v_cancel c_cancel%rowtype;
  v_cancel_mlrq varchar2(8);
  v_cancel_mlh sgml.mlh%type;
  v_cancel_mlxh sgml.mlxh%type;
  v_cancel_zrxh sgml.zrxh%type;
  --取消令
begin
  p_rtnstring:='';
  b_successful:=true;
  v_successful:='';
  open c_cancel;
  loop
   fetch c_cancel into v_cancel;
   exit when c_cancel%notfound;
   v_cancel_mlrq:=to_char(v_cancel.rq,'YYYYMMDD');
   v_cancel_mlh:=v_cancel.mlh;
   v_cancel_mlxh:=v_cancel.mlxh;
   v_cancel_zrxh:=v_cancel.zrxh;
   delete from k_jjkclcrb
          where to_char(mlrq,'YYYYMMDD')=v_cancel_mlrq and mlh=v_cancel_mlh and to_number(mlxh)=v_cancel_mlxh and zrxh=v_cancel_zrxh;
  end loop;
  close c_cancel;
  open c_cgkdl;
  select count(*) into li_num from b_bureau where cur_bureau='1';
  if li_num = 0 then
     p_rtnstring:=p_rtnstring||'B_BUREAU中没有指定所属路局标志!'||chr(10)||'<br>';
     b_successful:=false;
     goto break;
  elsif li_num >1 then
     p_rtnstring:=p_rtnstring||'B_BUREAU中只能指定一个所属路局标志!'||chr(10)||'<br>';
     b_successful:=false;
     goto break;
  elsif li_num=1 then
     select bureau_code into ls_lj from b_bureau where cur_bureau='1';
  end if;
  loop
    fetch c_cgkdl into v_cgkdl;
    exit when c_cgkdl%notfound;
    /*初始化变量*/
     li_count:=0;
     li_cdzs := 0;
     li_jgts := 0;
     ls_noch_cz:='';
     li_liangs := 0;
     ls_havecz:='';
     ls_havech:='';
     ls_zdz:='';
     ls_zdzm:='';
     ls_fcc:='';
     li_fts:=0;
     ls_gcz_no:='';
     li_gcz_day:=0;
     ls_scz_no:='';
     ls_jjk_name:=' ';
     ls_jjk_st:='';
     li_jjk_day:=0;
     ls_jjk2_name:=' ';
     ls_jjk2_st:='';
     li_jjk2_day:=0;
     ls_ybrq:='';
     ls_jhrq:='';
     ls_ybrq2:='';
     ls_jhrq2:='';
     ls_crbz :='0';
     li_zdz_day:=0;
     ls_zdz_gcz_no:='';
     ls_zdz_jjk_name:='';
     ls_zdz_jjk_st:='';
     li_zdz_jjk_day:=0;
     ls_zdz_jjk2_name:='';
     ls_zdz_jjk2_st:='';
     li_zdz_jjk2_day:=0;
     ls_zdz_jjk_ybrq:='';
     ls_zdz_jjk_jhrq:='';
     ls_zdz_jjk2_ybrq:='';
     ls_zdz_jjk2_jhrq:='';
     ls_cz_ch:='';
     vb_grbz:=false;
     vb_yzcd:=false;
    /*初始化变量结束*/
    v_action:=v_cgkdl.action;
    v_action_date:=to_char(v_cgkdl.action_date,'YYYYMMDD');
    v_mlrq:=to_char(v_cgkdl.rq,'YYYYMMDD');
    v_mlh:=v_cgkdl.mlh;
    v_mlxh:=v_cgkdl.mlxh;
    if v_mlh='82058' then
      li_w:=9;
    end if;
    v_qsrq:=to_char(v_cgkdl.qsrq,'YYYYMMDD');
    vv_qsrq:=v_qsrq;
    v_zzrq:=to_char(nvl(v_cgkdl.zzrq,v_cgkdl.qsrq),'YYYYMMDD');
    v_gcz:=nvl(v_cgkdl.gcz,' ');
    v_gczm:=nvl(v_cgkdl.gczm,' ');
    v_cc:=v_cgkdl.cc;
    v_sgwz:=nvl(v_cgkdl.sgwz,' ');
    v_zy:=nvl(v_cgkdl.zy,' ');
    v_cs:=nvl(v_cgkdl.cs,' ');
    v_ls:=nvl(v_cgkdl.ls,0);
    v_yt:=v_cgkdl.yt;
    v_scz:=nvl(v_cgkdl.scz,' ');
    v_sczm:=nvl(v_cgkdl.sczm,' ');
    v_zcz:=nvl(v_cgkdl.zcz,' ');
    v_zczm:=nvl(v_cgkdl.zczm,' ');
    v_qtlh:=nvl(v_cgkdl.qtlh,' ');
    v_lhwz:=nvl(v_cgkdl.lhwz, ' ');
    v_fscz:=nvl(v_cgkdl.fscz,' ');
    v_fsczm:=nvl(v_cgkdl.fsczm,' ');
    v_dwcz1:=nvl(v_cgkdl.dwcz1,' ');
    v_dwczm1:=nvl(v_cgkdl.dwczm1,' ');
    v_dwcz2:=nvl(v_cgkdl.dwcz2,' ');
    v_dwczm2:=nvl(v_cgkdl.dwczm2,' ');
    v_grbz:=nvl(v_cgkdl.grbz,' ');
    v_zrxh:=v_cgkdl.zrxh;
    /*对用途是存站、充组的命令进行 处理开始（隔日标志为D，表示针对到达车次的命令）*/
    if v_yt = '存站' or v_yt = '充组' then
       goto continue;
    end if;
    /*对用途是存站、充组的命令进行 处理结束（隔日标志为D，表示针对到达车次的命令）*/
    if length(to_char(v_mlxh)) = 1 then
       v_mlhm:=v_mlh||'-0'||to_char(v_mlxh)||'('||substr(v_mlrq,5,2)||')';
    else
       v_mlhm:=v_mlh||'-'||to_char(v_mlxh)||'('||substr(v_mlrq,5,2)||')';
    end if;
    --
    v_train_id := gettrainid(v_cc,vv_qsrq);
    if v_train_id = 'Not1' then
          p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_schedule表中无对应的信息!'||chr(10)||'<br>';
          goto continue;
    elsif v_train_id = 'Not2' then
          p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_schedule表中无对应的信息!'||chr(10)||'<br>';
          goto continue;
    end if;
    --
    --找最新得命令
    select count(*)-1 into li_num from sgml
       where to_char(rq,'YYYYMMDD')=v_mlrq and mlh=v_mlh and mlxh=v_mlxh and zrxh=v_zrxh;
    if li_num>0 then
      if v_action!=li_num then
          --p_rtnstring:=p_rtnstring||v_mlhm||'令'||'action:'||to_char(v_action)||chr(10)||'<br>';
          goto continue;
       end if;
    end if;
    --如不是最新得，不作处理
    if v_zzrq !='20991231' and v_zzrq != v_qsrq and v_zzrq < to_char(sysdate - 8,'yyyymmdd') then
       goto continue;
    end if;
    if v_zzrq = '20991231' then
       if v_qsrq > to_char(sysdate,'yyyymmdd') then
          v_zzrq := to_char(to_date(v_qsrq,'yyyymmdd') + 8, 'yyyymmdd');
       else
          v_qsrq := to_char(sysdate - 8, 'yyyymmdd');
          v_zzrq := to_char(sysdate + 8, 'yyyymmdd');
       end if;
    end if;
    if v_grbz!=' ' then
       if upper(substr(v_grbz,1,1)) = 'Y' then
          vb_grbz := true;
       elsif upper(substr(v_grbz,1,1)) = 'A' then
          vb_yzcd := true;
       end if;
    end if;
    if vb_yzcd then
       --v_train_id := gettrainid(v_cc,vv_qsrq);
       /*
       if v_train_id = 'Not1' then
          p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_info表中无对应的信息!'||chr(10)||'<br>';
          goto continue;
       elsif v_train_id = 'Not2' then
          p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_info表中无对应的信息!'||chr(10)||'<br>';
          goto continue;
       else
          select groups-1 into li_cdzs from train_info
             where train_kpid= v_train_id;
       end if;
       */
       select groups-1 into li_cdzs from train_info
             where train_kpid = v_train_id;
    end if;
    li_jgts := to_date(v_zzrq,'YYYYMMDD')- to_date(v_qsrq,'YYYYMMDD');
    /*删除旧的局界口车辆出入情况表*/
    delete from k_jjkclcrb where to_char(mlrq,'YYYYMMDD')=v_mlrq and mlh=v_mlh and to_number(mlxh)=v_mlxh and zrxh=v_zrxh;
    if v_gcz != ' ' then
       if v_zy != ' ' then
          if v_ls != 0 then
             /*查询车辆库*/
             open c_noch(v_mlrq,v_mlh,to_number(v_mlxh),to_number(v_zrxh));
             loop
               fetch c_noch into ls_noch_cz;
               exit when c_noch%notfound;
               select count(*) into li_liangs from sgcl where to_char(rq,'YYYYMMDD')=v_mlrq and trim(mlh)=trim(v_mlh) and mlxh=v_mlxh and zrxh=v_zrxh
                 and cz=ls_noch_cz;
               if v_zy='挂' then
                  insert into k_temp_cz_ch values('+'||trim(ls_noch_cz)||to_char(li_liangs)||'辆');
               else
                  insert into k_temp_cz_ch values('-'||trim(ls_noch_cz)||to_char(li_liangs)||'辆');
               end if;
             end loop;
             close c_noch;
             open c_havech(v_mlrq,v_mlh,v_mlxh,v_zrxh);
             loop
                fetch c_havech into ls_havecz,ls_havech;
                exit when c_havech%notfound;
                insert into k_temp_cz_ch values(trim(ls_havecz)||trim(ls_havech));
             end loop;
             close c_havech;
             /*查询车辆库结束*/
             open c_temp_cz_ch;
             loop
               fetch c_temp_cz_ch into ls_cz_ch;
               exit when c_temp_cz_ch%notfound;
             end loop;
             close c_temp_cz_ch;
          else
             p_rtnstring := p_rtnstring||v_mlhm||'令'||v_cc||'次无对应的车辆信息!'||chr(10)||'<br>';
             goto continue;
          end if;--v_ls!=0

          /*查询车次基本信息*/
          --v_train_id := gettrainid(v_cc,vv_qsrq);
          /*
          if v_train_id = 'Not1' then
             p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_info表中无对应的信息!'||chr(10)||'<br>';
             goto continue;
          elsif v_train_id = 'Not2' then
             p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次在train_info表中无对应的信息!'||chr(10)||'<br>';
             goto continue;
          else
             select end_sta_code,end_sta_name,back_train_kpid,back_days into ls_zdz,ls_zdzm,ls_fcc,li_fts from train_info
                where train_kpid= v_train_id;
          end if;
          */
           select count(*) into li_num from train_info where train_kpid = v_train_id;
          if li_num=0 then 
          p_rtnstring := p_rtnstring ||v_mlhm||'令'||v_cc||'次在train_info表中无对应信息！'||chr(10)||'<br>';
          goto continue;
          elsif li_num>1 then
          p_rtnstring := p_rtnstring ||v_mlhm||'令'||v_cc||'次在train_info表中有多余信息！'||chr(10)||'<br>';
          goto continue;
          elsif li_num = 1 then
          select end_sta_code,end_sta_name,back_train_kpid,back_days into ls_zdz,ls_zdzm,ls_fcc,li_fts from train_info
                where train_kpid= v_train_id;
          end if;
          /*查询挂车站信息*/
          --v_train_id := gettrainid(v_cc,vv_qsrq);
          /*
          if v_train_id = 'Not1' then
             p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次无对应的时刻表!'||chr(10)||'<br>';
             goto continue;
          elsif v_train_id = 'Not2' then
             p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次无对应的时刻表!'||chr(10)||'<br>';
             goto continue;
          else
             select run_days,sta_sort into li_gcz_day,ls_gcz_no from train_schedule
              where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(v_gczm));
          end if;
          */
          select count(*) into li_num from train_schedule where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(v_gczm));
          if li_num=0 then 
          p_rtnstring := p_rtnstring ||v_mlhm||'令'||v_cc||'次'||v_gczm||'在train_schedule表中无对应信息！'||chr(10)||'<br>';
          goto continue;
          elsif li_num>1 then
          p_rtnstring := p_rtnstring ||v_mlhm||'令'||v_cc||'次'||v_gczm||'在train_schedule表中有多余信息！'||chr(10)||'<br>';
          goto continue;
          elsif li_num = 1 then
          select run_days,sta_sort into li_gcz_day,ls_gcz_no from train_schedule
              where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(v_gczm));
          end if;
          /*查询甩车站信息*/
          if v_scz!=' ' then
          ---------------
             --v_train_id := gettrainid(v_cc,vv_qsrq);
             select count(*) into li_num from train_schedule
                where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(v_sczm));
             if li_num=0 then
                p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次无对应的时刻表!'||chr(10)||'<br>';
                goto continue;
             elsif li_num>1 then
                p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次中有一个以上的'||v_sczm||'营业站!'||chr(10)||'<br>';
                goto continue;
             elsif li_num=1 then
                select sta_sort into ls_scz_no from train_schedule
                   where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(v_sczm));
             end if;
          else
             --v_train_id := gettrainid(v_cc,vv_qsrq);
             select count(*) into li_num from train_schedule
                where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(ls_zdzm));
             if li_num=0 then
                p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次无对应的时刻表!'||chr(10)||'<br>';
                goto continue;
             elsif li_num>1 then
                p_rtnstring:=p_rtnstring||v_mlhm||'令'||v_cc||'次中有一个以上的'||ls_zdzm||'营业站!'||chr(10)||'<br>';
                goto continue;
             elsif li_num=1 then
                select sta_sort into ls_scz_no from train_schedule
                   where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(ls_zdzm));
             end if;
          end if;
          /*查询局界口信息*/
          open c_jjk(v_train_id,ls_gcz_no,ls_scz_no);
             fetch c_jjk into ls_jjk_name,ls_jjk_st,li_jjk_day;
             if c_jjk%notfound then
                ls_jjk2_name:=' ';
                ls_jjk2_st:='';
                li_jjk2_day:=0;
             else
                fetch c_jjk into ls_jjk2_name,ls_jjk2_st,li_jjk2_day;
             end if;
          close c_jjk;
          if ls_jjk_name!=' ' then
             ls_ybrq := to_char(to_date(v_qsrq,'YYYYMMDD') + (li_jjk_day - li_gcz_day),'YYYYMMDD');
             if to_number(ls_jjk_st) >1800 then
                ls_jhrq:=to_char(to_date(ls_ybrq,'YYYYMMDD') + 1,'YYYYMMDD');
             else
                ls_jhrq:=ls_ybrq;
             end if;
             if substr(v_gcz,3,1)=ls_lj then
                ls_crbz := '2';
             else
                ls_crbz := '1';
             end if;
             li_count:=0;
             while li_count<=li_jgts loop
                open c_temp_cz_ch;
                loop
                  fetch c_temp_cz_ch into ls_cz_ch;
                  exit when c_temp_cz_ch%notfound;
                  li_w:=li_w + 1;
                 insert into k_jjkclcrb(rq,jjkmc,sslj,cc,cz_ch,crbz,mlrq,mlh,mlxh,zrxh)
                         values(to_char(to_date(ls_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                 trim(ls_jjk_name),
                                 trim(v_cs),
                                 trim(v_cc),
                                 trim(ls_cz_ch),
                                 trim(ls_crbz),
                                 to_date(v_mlrq,'YYYYMMDD'),
                                 trim(v_mlh),
                                 trim(v_mlxh),
                                 to_number(trim(v_zrxh)));
                end loop;
                close c_temp_cz_ch;
                if vb_grbz then
                   li_count:=li_count + 1;
                end if;
                if vb_yzcd then
                   li_count:=li_count + li_cdzs;
                end if;
                li_count:=li_count+ 1;
             end loop;
             if ls_jjk2_name!=' ' then
                ls_ybrq2 := to_char(to_date(v_qsrq,'YYYYMMDD') + (li_jjk2_day - li_gcz_day),'YYYYMMDD');
                if to_number(ls_jjk2_st)>1800 then
                   ls_jhrq2 := to_char(to_date(ls_ybrq2,'YYYYMMDD'),'YYYYMMDD');
                else
                   ls_jhrq2 := ls_ybrq2;
                end if;
                if substr(v_gcz,3,1)=ls_lj then
                   ls_crbz := '1';
                else
                   ls_crbz := '2';
                end if;
                li_count:=0;
                while li_count<=li_jgts loop
                  open c_temp_cz_ch;
                loop
                  fetch c_temp_cz_ch into ls_cz_ch;
                  exit when c_temp_cz_ch%notfound;
                     li_w:=li_w + 1;
                     insert into k_jjkclcrb(rq,jjkmc,sslj,cc,cz_ch,crbz,mlrq,mlh,mlxh,zrxh)
                            values(to_char(to_date(ls_jhrq2,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                    trim(ls_jjk2_name),
                                    trim(v_cs),
                                    trim(v_cc),
                                    trim(ls_cz_ch),
                                    trim(ls_crbz),
                                    to_date(v_mlrq,'YYYYMMDD'),
                                    trim(v_mlh),
                                    trim(v_mlxh),
                                    to_number(trim(v_zrxh)));
                   end loop;
                   close c_temp_cz_ch;
                   if vb_grbz then
                      li_count:=li_count + 1;
                   end if;
                   if vb_yzcd then
                      li_count:=li_count + li_cdzs;
                   end if;
                   li_count:=li_count+ 1;
                end loop;
             end if;--jjk2!=' '
          end if;--jjk1!=' '
          /*查询局界口信息结束*/
                    /*对一往返、原列利回、原列空送等双程操作进行处理*/
          if v_qtlh!=' ' then
             if v_qtlh='一往返' or v_qtlh='原列利回' or v_qtlh='原列空送' or v_qtlh='原列欠车' then
                --v_train_id := gettrainid(v_cc,vv_qsrq);
                select run_days into li_zdz_day from train_schedule
                  where train_kpid=v_train_id and ltrim(rtrim(sta_name))=ltrim(rtrim(ls_zdzm));
                if v_fscz!= ' ' then
                   select count(*) into li_num from train_schedule
                     where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(v_fsczm));
                   if li_num=0 then
                      p_rtnstring:=p_rtnstring||v_mlhm||'令'||gettraincode(ls_fcc)||'次无'||v_fsczm||'对应的时刻表!'||chr(10)||'<br>';
                      goto continue;
                   elsif li_num>1 then
                      p_rtnstring:=p_rtnstring||v_mlhm||'令'||gettraincode(ls_fcc)||'次中有一个以上的'||v_fsczm||'营业站!'||chr(10)||'<br>';
                      goto continue;
                   elsif li_num=1 then
                      select sta_sort into ls_zdz_gcz_no from train_schedule
                         where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(v_fsczm));
                   end if;
                else
                   select count(*) into li_num from train_schedule
                     where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(v_gczm));
                   if li_num=0 then
                      p_rtnstring:=p_rtnstring||v_mlhm||'令'||gettraincode(ls_fcc)||'次无'||v_gczm||'对应的时刻表!'||chr(10)||'<br>';
                      goto continue;
                   elsif li_num>1 then
                      p_rtnstring:=p_rtnstring||v_mlhm||'令'||gettraincode(ls_fcc)||'次中有一个以上的'||v_gczm||'营业站!'||chr(10)||'<br>';
                      goto continue;
                   elsif li_num=1 then
                      select sta_sort into ls_zdz_gcz_no from train_schedule
                         where train_kpid=ls_fcc and ltrim(rtrim(sta_name))=ltrim(rtrim(v_gczm));
                   end if;
                end if;--v_fscz!= ' '
                /*查询返回车次局界口信息*/
                open c_jjk(ls_fcc,'01',ls_zdz_gcz_no);
                   fetch c_jjk into ls_zdz_jjk_name,ls_zdz_jjk_st,li_zdz_jjk_day;
                   if c_jjk%notfound then
                      ls_zdz_jjk2_name:=' ';
                      ls_zdz_jjk2_st:='';
                      li_zdz_jjk2_day:=0;
                   else
                      fetch c_jjk into ls_zdz_jjk2_name,ls_zdz_jjk2_st,li_zdz_jjk2_day;
                   end if;
                close c_jjk;
                if ls_zdz_jjk_name!=' ' then
                   ls_zdz_jjk_ybrq := to_char(to_date(v_qsrq,'YYYYMMDD') + (li_zdz_day + li_fts + li_zdz_jjk_day - li_gcz_day),'YYYYMMDD');
                   if to_number(ls_zdz_jjk_st) >1800 then
                      ls_zdz_jjk_jhrq:=to_char(to_date(ls_zdz_jjk_ybrq,'YYYYMMDD') + 1,'YYYYMMDD');
                   else
                      ls_zdz_jjk_jhrq:=ls_zdz_jjk_ybrq;
                   end if;
                   if substr(ls_zdz,3,1)=ls_lj then
                      ls_crbz := '2';
                   else
                      ls_crbz := '1';
                   end if;
                   li_count:=0;
                   while li_count<=li_jgts loop
                    open c_temp_cz_ch;
                loop
                  fetch c_temp_cz_ch into ls_cz_ch;
                  exit when c_temp_cz_ch%notfound;
                        li_w:=li_w + 1;
                       insert into k_jjkclcrb(rq,jjkmc,sslj,cc,cz_ch,crbz,mlrq,mlh,mlxh,zrxh)
                               values(to_char(to_date(ls_zdz_jjk_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                       trim(ls_zdz_jjk_name),
                                       trim(v_cs),
                                       trim(gettraincode(ls_fcc)),
                                       trim(ls_cz_ch),--v_varchar2(v_index),
                                       trim(ls_crbz),
                                       to_date(v_mlrq,'YYYYMMDD'),
                                       trim(v_mlh),
                                       trim(v_mlxh),
                                       to_number(trim(v_zrxh)));
                      end loop;
                      close c_temp_cz_ch;
                      if vb_grbz then
                         li_count:=li_count + 1;
                      end if;
                      if vb_yzcd then
                         li_count:=li_count + li_cdzs;
                      end if;
                      li_count:=li_count+ 1;
                   end loop;
                   if ls_zdz_jjk2_name!=' ' then
                      ls_zdz_jjk2_ybrq := to_char(to_date(v_qsrq,'YYYYMMDD') + (li_zdz_day + li_fts + li_zdz_jjk2_day - li_gcz_day),'YYYYMMDD');
                      if to_number(ls_zdz_jjk2_st)>1800 then
                         ls_zdz_jjk2_jhrq := to_char(to_date(ls_zdz_jjk2_ybrq,'YYYYMMDD'),'YYYYMMDD');
                      else
                         ls_zdz_jjk2_jhrq := ls_zdz_jjk2_ybrq;
                      end if;
                      if substr(ls_zdz,3,1)=ls_lj then
                         ls_crbz := '1';
                      else
                         ls_crbz := '2';
                      end if;
                      li_count:=0;
                      while li_count<=li_jgts loop
                        open c_temp_cz_ch;
                loop
                  fetch c_temp_cz_ch into ls_cz_ch;
                  exit when c_temp_cz_ch%notfound;
                           li_w:=li_w + 1;
                           insert into k_jjkclcrb(rq,jjkmc,sslj,cc,cz_ch,crbz,mlrq,mlh,mlxh,zrxh)
                                  values(to_char(to_date(ls_zdz_jjk2_jhrq,'YYYYMMDD') + li_count,'YYYYMMDD'),
                                          trim(ls_zdz_jjk2_name),
                                          trim(v_cs),
                                          trim(gettraincode(ls_fcc)),
                                          trim(ls_cz_ch),
                                          trim(ls_crbz),
                                          to_date(v_mlrq,'YYYYMMDD'),
                                          trim(v_mlh),
                                          trim(v_mlxh),
                                          to_number(trim(v_zrxh)));
                         end loop;
                         close c_temp_cz_ch;
                         if vb_grbz then
                            li_count:=li_count + 1;
                         end if;
                         if vb_yzcd then
                            li_count:=li_count + li_cdzs;
                         end if;
                         li_count:=li_count+ 1;
                      end loop;
                   end if;--zdz_jjk2!=' '
                end if;--zdz_jjk1!=' '

             end if;
          end if;--v_qtlh!=' '
       end if;--v_zy!=' '
    end if;--v_gcz != ' '
    delete from k_temp_cz_ch;
    --p_rtnstring:=p_rtnstring||'令：'||v_mlhm||'！'||chr(10);
    <<continue>>
    li_num:=0;--废语句
  end loop;
  <<break>>
  delete from k_temp_cz_ch;
  close c_cgkdl;
  if b_successful then
     p_rtnstring:=p_rtnstring||'生成车辆出入情况结束！'||chr(10)||'<br>';
     v_successful:='true';
     commit;
  else
     p_rtnstring:=p_rtnstring||'生成车辆出入情况失败！'||chr(10)||'<br>';
     v_successful:='false';
     rollback;
  end if;
  /*exception
  When others then
     p_rtnstring:=p_rtnstring||'sfdsfsd'||chr(10);
  */
end Create_Jjkclcrb;
/

