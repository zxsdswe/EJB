create view V_ADD_LKCMD as
  select rawtohex(sys_guid()) as guid,t.cmd_date,cmd_id,item_id,item_sort,takeon_bur,train_no,st_sta_name,ar_sta_name,star_date,stop_date,running_rule,running_rule_chn,running_cycle from add_lkcmd t
/

