create procedure PRO_YXSJ_SFZDFJK is
  /*本存储过程用于从T/D结合数据库xd_train_tt表中采集客调车次字典库YXSJ_LJZD_CC表中所维护的列车在路局的始发站、终到站、分界口的明细数据*/

  v_tmp  varchar(10); /*临时日期，用以判断是否已经取数*/
  v_has1 number(1) := 0; /*临时变量，取数时用*/

  v_tdcfsj yxsj_xd_traintt.tdcfsj%type; /*图定出发时间，对应于yxsj_xd_traintt表中的图定出发时间*/
  v_cfsj   yxsj_xd_traintt.cfsj%type; /*实际出发时间，对应于yxsj_xd_traintt表中的实际出发时间*/
  v_cfwd   yxsj_ljlcyxmx.sf_wd%type;
  v_cfid   yxsj_xd_traintt.id%type;

  v_tdddsj yxsj_xd_traintt.tdddsj%type; /*图定到达时间，对应于yxsj_xd_traintt表中的图定到达时间*/
  v_ddsj   yxsj_xd_traintt.ddsj%type; /*实际到达时间，对应于yxsj_xd_traintt表中的实际到达时间*/
  v_ddwd   yxsj_ljlcyxmx.sf_wd%type;
  v_ddid   yxsj_xd_traintt.id%type;

  v_tdsfrq yxsj_ljlcyxmx.sfrq%type; /*图定始发日期，由图定交出日期减去交出天数 或者 图定终到日期减去终到天数得到*/
  v_tdjrrq varchar(10); /*图定接入日期，由图定始发日期加上接入天数得到*/
  v_tdjcrq varchar(10); /*图定交出日期，根据图定交出时间截出的日期*/
  v_tdzdrq varchar(10); /*图定终到日期，根据图定终到时间截出的日期*/

  SFZD_FJK_DDT varchar(20);

  /*定义游标1——d: 遍历车次字典表YXSJ_LJZD_CC ---start*/
  cursor d is
    select LJ_JC,
           LJDM,
           LCLX,
           LCLX_XH,
           CC,
           QCC,
           LJ_XH,
           YXFS,
           SF_ZM,
           JR_ZM,
           JR_TS,
           JC_ZM,
           JC_TS,
           ZD_ZM,
           ZD_TS
      from YXSJ_LJZD_CC;
  d_rec d%rowtype;
  /*定义游标1——d: 遍历车次字典表YXSJ_LJZD_CC ---end*/

  /*定义游标2——select_ddzm: 到达游标---start*/
  /*以到达站名和全车次为参数，取出当天18点区段内，该车次在该到达站报点的数据，没报点时记录数为0，一个台报点时记录为1，遇有两天晚点在一个18点区段内时记录数再加1，
  这里的语句中使用了和取数结果 yxsj_ljlcyxmx 表中比较日期，当天已取过则不再取，所以多次执行本存储过程时不会重复取，另外遇有两个行调台同时报同一天的数据时，只取第一条数据。
  这里返回数据集，按照图定到达时间倒排序*/
  cursor select_ddzm(v_node varchar, v_qcc varchar) is
    select id,
           ddsj,
           tdddsj,
           trim(to_char((trunc((ddsj - tdddsj) * 24) +
                        ((ddsj - tdddsj) * 24 -
                        trunc((ddsj - tdddsj) * 24)) * 60 / 100),
                        '999.99')) dd_wd
      from yxsj_xd_traintt
     where instr('-' || v_qcc, '-' || ddcc || '-') > 0
       and ddsj >
           to_date(to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd HH24:MI:SS') - 0.25
       and ddsj <=
           to_date(to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd HH24:MI:SS') + 0.75
       and to_char(tdddsj, 'yyyy-mm-dd') > '2014-01-01'
       and trim(node) = trim(v_node)
       and to_char(tdddsj, 'yyyymmdd') not in
           (select to_char(tdsj, 'yyyymmdd')
              from yxsj_sfzd_fjk
             where to_char(tbrq, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')
               and instr('-' || qcc, '-' || yxsj_xd_traintt.ddcc || '-') > 0
               and trim(zm) = trim(v_node))
     order by tdddsj;
  dd_rec select_ddzm%rowtype;
  /*定义游标2——select_ddzm: 到达游标---end*/

  /*定义游标3——select_cfzm: 出发游标---start*/
  /*以出发站名和全车次为参数，取出当天18点区段内，该车次在该出发站报点的数据，没报点时记录数为0，一个台报点时记录为1，遇有两天晚点在一个18点区段内时记录数再加1，
  这里的语句中使用了和取数结果 yxsj_ljlcyxmx 表中比较日期，当天已取过则不再取，所以多次执行本存储过程时不会重复取，另外遇有两个行调台同时报同一天的数据时，只取第一条数据。
  这里返回数据集，按照图定出发时间倒排序*/
  cursor select_cfzm(v_node varchar, v_qcc varchar) is
    select id,
           cfsj,
           tdcfsj,
           trim(to_char((trunc((cfsj - tdcfsj) * 24) +
                        ((cfsj - tdcfsj) * 24 -
                        trunc((cfsj - tdcfsj) * 24)) * 60 / 100),
                        '999.99')) cf_wd
      from yxsj_xd_traintt
     where instr('-' || v_qcc, '-' || cfcc || '-') > 0
       and cfsj >
           to_date(to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd HH24:MI:SS') - 0.25
       and cfsj <=
           to_date(to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd HH24:MI:SS') + 0.75
       and to_char(tdcfsj, 'yyyy-mm-dd') > '2014-01-01'
       and trim(node) = trim(v_node)
       and to_char(tdcfsj, 'yyyymmdd') not in
           (select to_char(tdsj, 'yyyymmdd')
              from yxsj_sfzd_fjk
             where to_char(tbrq, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')
               and instr('-' || qcc, '-' || yxsj_xd_traintt.cfcc || '-') > 0
               and trim(zm) = trim(v_node))
     order by tdcfsj;
  cf_rec select_cfzm%rowtype;
  /*定义游标3——select_cfzm: 出发游标---end*/

  /*定义游标4——取调度台: 游标---start*/
  cursor f is
    select sfzd_fjk_id, nvl(lcid, 0) lcid
      from yxsj_sfzd_fjk
     where to_char(tbrq, 'yyyy-mm-dd') = to_char(sysdate, 'yyyy-mm-dd')
       and ddt is null;
  f_rec f%rowtype;
  /*定义游标4——取调度台: 游标---end*/

  /*定义游标5——取映射站名: 游标---start*/
  cursor select_zm1 is
    select SFZD_FJK_ID, tdms_zm
      from YXSJ_SFZD_FJK t, yxsj_ljzd_zmys m
     where to_char(tbrq, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')
       and trim(t.zm) = trim(m.tdcs_node)
       and zm_show is null;
  rec_zm1 select_zm1%rowtype;

  cursor select_zm2 is
    select SFZD_FJK_ID, zm
      from YXSJ_SFZD_FJK t, yxsj_ljzd_zmys m
     where to_char(tbrq, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')
       and trim(t.zm) != trim(m.tdcs_node)
       and zm_show is null;
  rec_zm2 select_zm2%rowtype;
  /*定义游标5——取映射站名: 游标---end*/

  errormessage exception;

  /*开始取数*/
begin

  /*从xd_train_tt表取出最近4天的数插入临时表yxsj_xd_traintt---start*/
  insert into yxsj_xd_traintt
    select ID, node, ddsj, cfsj, ddcc, cfcc, tdddsj, tdcfsj
      from xd_train_tt
     where (dfd_falg = 3 or
           (node = '茂名' and (dfd_falg = 1 or dfd_falg = 2)))
       and tdddsj >
           to_date(to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd HH24:MI:SS') - 4;
  /*从xd_train_tt表取出最近4天的数插入临时表yxsj_xd_traintt---end*/

  open d;

  /*第一步：循环遍历车次字典表YXSJ_LJZD_CC*/
  loop
    fetch d
      into d_rec;
    exit when d%notfound;
  
    /*类型1-----终到*/
    if (d_rec.yxfs = '始发终到') or (d_rec.yxfs = '接入终到') then
      v_tmp := '2000-01-01';
      open select_ddzm(d_rec.zd_zm, d_rec.qcc); /*这里将遍历车次字典表YXSJ_LJZD_CC得到的一行记录中的终到站名和全车次作为参数，传入游标2，返回0行到多行数据集*/
      /*循环遍历返回的数据集*/
      loop
        <<go_zd>>
        fetch select_ddzm
          into dd_rec;
        exit when select_ddzm%notfound; /*这里说明返回数据集记录数为0，即终到站在该18点区段内没有报点，则跳出循环*/
        if (v_tmp = to_char(dd_rec.tdddsj, 'yyyy-mm-dd')) then
          /*continue; /*这里说明出现了同一天内的多条数据，说明是多个行调台报同一天的数，只取一次，不再重复取，跳出循环*/
          goto go_zd;
        else
          /*这里说明有不同日期的车未取过，则开始取数*/
          v_tdzdrq := to_char(dd_rec.tdddsj, 'yyyy-mm-dd'); /*图定终到日期*/
          v_tdsfrq := to_date(v_tdzdrq, 'yyyy-mm-dd') - d_rec.zd_ts; /*根据终到日期，减去终到天数，得到图定始发日期*/
          v_tdddsj := dd_rec.tdddsj; /*图定终到时间*/
          v_ddsj   := dd_rec.ddsj; /*实际终到时间*/
          v_ddwd   := dd_rec.dd_wd; /*终到晚点时间*/
          v_ddid   := dd_rec.id; /*终到列车ID*/
          /*开始向 YXSJ_SFZD_FJK 表插入记录*/
          insert into yxsj_sfzd_fjk
            (sfzd_fjk_id,
             tbrq,
             sfrq,
             lj_jc,
             ljdm,
             lclx,
             lclx_xh,
             cc,
             qcc,
             lj_xh,
             yxfs,
             czlx,
             zm,
             tdsj,
             sjsj,
             wdsj,
             lcid)
          values
            (SEQ_YXSJ_SFZD_FJK.nextval,
             sysdate,
             v_tdsfrq,
             d_rec.lj_jc,
             d_rec.ljdm,
             d_rec.lclx,
             d_rec.lclx_xh,
             d_rec.cc,
             d_rec.qcc,
             d_rec.lj_xh,
             d_rec.yxfs,
             '终到',
             d_rec.zd_zm,
             v_tdddsj,
             v_ddsj,
             v_ddwd,
             v_ddid);
          v_tmp := to_char(dd_rec.tdddsj, 'yyyy-mm-dd'); /*将日期填入v_tmp，以供比较下一条数据集的日期*/
        end if;
      end loop;
      close select_ddzm;
    end if;
  
    /*类型2-----始发*/
    if (d_rec.yxfs = '始发终到') or (d_rec.yxfs = '始发交出') then
      v_tmp := '2000-01-01';
      open select_cfzm(d_rec.sf_zm, d_rec.qcc); /*这里将遍历车次字典表YXSJ_LJZD_CC得到的一行记录中的始发站名和全车次作为参数，传入游标3，返回0行到多行数据集*/
      /*循环遍历返回的数据集*/
      loop
        <<go_sf>>
        fetch select_cfzm
          into cf_rec;
        exit when select_cfzm%notfound; /*这里说明返回数据集记录数为0，即出发站在该18点区段内没有报点，则跳出循环*/
        if (v_tmp = to_char(cf_rec.tdcfsj, 'yyyy-mm-dd')) then
          /*continue; /*这里说明出现了同一天内的多条数据，说明是多个行调台报同一天的数，只取一次，不再重复取，跳出循环*/
          goto go_sf;
        else
          /*这里说明有不同日期的车未取过，则开始取数*/
          v_tdsfrq := to_date(to_char(cf_rec.tdcfsj, 'yyyy-mm-dd'),
                              'yyyy-mm-dd'); /*图定始发日期*/
          v_tdcfsj := cf_rec.tdcfsj; /*图定出发时间*/
          v_cfsj   := cf_rec.cfsj; /*实际出发时间*/
          v_cfwd := cf_rec.cf_wd; /*出发晚点时间*/
          v_cfid := cf_rec.id; /*出发列车ID*/
          /*开始向 YXSJ_SFZD_FJK 表插入记录*/
          insert into yxsj_sfzd_fjk
            (sfzd_fjk_id,
             tbrq,
             sfrq,
             lj_jc,
             ljdm,
             lclx,
             lclx_xh,
             cc,
             qcc,
             lj_xh,
             yxfs,
             czlx,
             zm,
             tdsj,
             sjsj,
             wdsj,
             lcid)
          values
            (SEQ_YXSJ_SFZD_FJK.nextval,
             sysdate,
             v_tdsfrq,
             d_rec.lj_jc,
             d_rec.ljdm,
             d_rec.lclx,
             d_rec.lclx_xh,
             d_rec.cc,
             d_rec.qcc,
             d_rec.lj_xh,
             d_rec.yxfs,
             '始发',
             d_rec.sf_zm,
             v_tdcfsj,
             v_cfsj,
             v_cfwd,
             v_cfid);
          v_tmp := to_char(cf_rec.tdcfsj, 'yyyy-mm-dd'); /*将日期填入v_tmp，以供比较下一条数据集的日期*/
        end if;
      end loop;
      close select_cfzm;
    end if;
  
    /*类型3-----接入*/
    if (d_rec.yxfs = '接入终到') or (d_rec.yxfs = '接入交出') then
      v_tmp := '2000-01-01';
      /*判断接入站是否为本局管辖，本局管则接入取到达时间，邻局管则接入取出发时间*/
      /*3.1 接入站为本局管辖*/
      v_has1 := 0;
      select count(*)
        into v_has1
        from v_yxsj_ljzdfjk1
       where trim(fjk_name) = trim(d_rec.jr_zm);
      if (v_has1 > 0) then
        /*接入站为本局管辖*/
        open select_ddzm(d_rec.jr_zm, d_rec.qcc); /*这里将遍历车次字典表YXSJ_LJZD_CC得到的一行记录中的终到站名和全车次作为参数，传入游标2，返回0行到多行数据集*/
        /*循环遍历返回的数据集*/
        loop
          <<go_jr1>>
          fetch select_ddzm
            into dd_rec;
          exit when select_ddzm%notfound; /*这里说明返回数据集记录数为0，即终到站在该18点区段内没有报点，则跳出循环*/
          if (v_tmp = to_char(dd_rec.tdddsj, 'yyyy-mm-dd')) then
            /*continue; /*这里说明出现了同一天内的多条数据，说明是多个行调台报同一天的数，只取一次，不再重复取，跳出循环*/
            goto go_jr1;
          else
            /*这里说明有不同日期的车未取过，则开始取数*/
            v_tdjrrq := to_char(dd_rec.tdddsj, 'yyyy-mm-dd'); /*图定接入日期*/
            v_tdsfrq := to_date(v_tdjrrq, 'yyyy-mm-dd') - d_rec.jr_ts; /*根据接入日期，减去接入天数，得到图定始发日期*/
            v_tdddsj := dd_rec.tdddsj; /*图定接入时间*/
            v_ddsj   := dd_rec.ddsj; /*实际接入时间*/
            v_ddwd   := dd_rec.dd_wd; /*接入晚点时间*/
            v_ddid   := dd_rec.id; /*接入列车ID*/
            /*开始向 YXSJ_SFZD_FJK 表插入记录*/
            insert into yxsj_sfzd_fjk
              (sfzd_fjk_id,
               tbrq,
               sfrq,
               lj_jc,
               ljdm,
               lclx,
               lclx_xh,
               cc,
               qcc,
               lj_xh,
               yxfs,
               czlx,
               zm,
               tdsj,
               sjsj,
               wdsj,
               lcid)
            values
              (SEQ_YXSJ_SFZD_FJK.nextval,
               sysdate,
               v_tdsfrq,
               d_rec.lj_jc,
               d_rec.ljdm,
               d_rec.lclx,
               d_rec.lclx_xh,
               d_rec.cc,
               d_rec.qcc,
               d_rec.lj_xh,
               d_rec.yxfs,
               '接入',
               d_rec.jr_zm,
               v_tdddsj,
               v_ddsj,
               v_ddwd,
               v_ddid);
            v_tmp := to_char(dd_rec.tdddsj, 'yyyy-mm-dd'); /*将日期填入v_tmp，以供比较下一条数据集的日期*/
          end if;
        end loop;
        close select_ddzm;
      end if;
    
      /*3.2 接入站为邻局管辖*/
      v_has1 := 0;
      select count(*)
        into v_has1
        from v_yxsj_ljzdfjk2
       where trim(fjk_name) = trim(d_rec.jr_zm);
      if (v_has1 > 0) then
        /*说明接入站为邻局管辖*/
        open select_cfzm(d_rec.jr_zm, d_rec.qcc); /*这里将遍历车次字典表YXSJ_LJZD_CC得到的一行记录中的始发站名和全车次作为参数，传入游标3，返回0行到多行数据集*/
        /*循环遍历返回的数据集*/
        loop
          <<go_jr2>>
          fetch select_cfzm
            into cf_rec;
          exit when select_cfzm%notfound; /*这里说明返回数据集记录数为0，即出发站在该18点区段内没有报点，则跳出循环*/
          if (v_tmp = to_char(cf_rec.tdcfsj, 'yyyy-mm-dd')) then
            /*continue; /*这里说明出现了同一天内的多条数据，说明是多个行调台报同一天的数，只取一次，不再重复取，跳出循环*/
            goto go_jr2;
          else
            /*这里说明有不同日期的车未取过，则开始取数*/
            v_tdjrrq := to_char(cf_rec.tdcfsj, 'yyyy-mm-dd'); /*图定接入日期*/
            v_tdsfrq := to_date(v_tdjrrq, 'yyyy-mm-dd') - d_rec.jr_ts; /*根据接入日期，减去接入天数，得到图定始发日期*/
            v_tdcfsj := cf_rec.tdcfsj; /*图定出发时间*/
            v_cfsj   := cf_rec.cfsj; /*实际出发时间*/
            v_cfwd   := cf_rec.cf_wd; /*出发晚点时间*/
            v_cfid   := cf_rec.id; /*出发列车ID*/
            /*开始向 YXSJ_SFZD_FJK 表插入记录*/
            insert into yxsj_sfzd_fjk
              (sfzd_fjk_id,
               tbrq,
               sfrq,
               lj_jc,
               ljdm,
               lclx,
               lclx_xh,
               cc,
               qcc,
               lj_xh,
               yxfs,
               czlx,
               zm,
               tdsj,
               sjsj,
               wdsj,
               lcid)
            values
              (SEQ_YXSJ_SFZD_FJK.nextval,
               sysdate,
               v_tdsfrq,
               d_rec.lj_jc,
               d_rec.ljdm,
               d_rec.lclx,
               d_rec.lclx_xh,
               d_rec.cc,
               d_rec.qcc,
               d_rec.lj_xh,
               d_rec.yxfs,
               '接入',
               d_rec.jr_zm,
               v_tdcfsj,
               v_cfsj,
               v_cfwd,
               v_cfid);
            v_tmp := to_char(cf_rec.tdcfsj, 'yyyy-mm-dd'); /*将日期填入v_tmp，以供比较下一条数据集的日期*/
          end if;
        end loop;
        close select_cfzm;
      
      end if;
    end if;
  
    /*类型4-----交出*/
    if (d_rec.yxfs = '始发交出') or (d_rec.yxfs = '接入交出') then
      v_tmp := '2000-01-01';
      /*判断交出站是否为本局管辖，本局管则交出取出发时间，邻局管则交出取到达时间*/
      /*4.1 交出站为本局管辖*/
      v_has1 := 0;
      select count(*)
        into v_has1
        from v_yxsj_ljzdfjk1
       where trim(fjk_name) = trim(d_rec.jc_zm);
      if (v_has1 > 0) then
        /*交出站为本局管辖*/
        open select_cfzm(d_rec.jc_zm, d_rec.qcc); /*这里将遍历车次字典表YXSJ_LJZD_CC得到的一行记录中的始发站名和全车次作为参数，传入游标3，返回0行到多行数据集*/
        /*循环遍历返回的数据集*/
        loop
          <<go_jc1>>
          fetch select_cfzm
            into cf_rec;
          exit when select_cfzm%notfound; /*这里说明返回数据集记录数为0，即出发站在该18点区段内没有报点，则跳出循环*/
          if (v_tmp = to_char(cf_rec.tdcfsj, 'yyyy-mm-dd')) then
            /*continue; /*这里说明出现了同一天内的多条数据，说明是多个行调台报同一天的数，只取一次，不再重复取，跳出循环*/
            goto go_jc1;
          else
            /*这里说明有不同日期的车未取过，则开始取数*/
            v_tdjcrq := to_char(cf_rec.tdcfsj, 'yyyy-mm-dd'); /*图定交出日期*/
            v_tdsfrq := to_date(v_tdjcrq, 'yyyy-mm-dd') - d_rec.jc_ts; /*根据交出日期，减去交出天数，得到图定始发日期*/
            v_tdcfsj := cf_rec.tdcfsj; /*图定交出时间*/
            v_cfsj   := cf_rec.cfsj; /*实际交出时间*/
            v_cfwd   := cf_rec.cf_wd; /*交出晚点时间*/
            v_cfid   := cf_rec.id; /*交出列车ID*/
            /*开始向 YXSJ_SFZD_FJK 表插入记录*/
            insert into yxsj_sfzd_fjk
              (sfzd_fjk_id,
               tbrq,
               sfrq,
               lj_jc,
               ljdm,
               lclx,
               lclx_xh,
               cc,
               qcc,
               lj_xh,
               yxfs,
               czlx,
               zm,
               tdsj,
               sjsj,
               wdsj,
               lcid)
            values
              (SEQ_YXSJ_SFZD_FJK.nextval,
               sysdate,
               v_tdsfrq,
               d_rec.lj_jc,
               d_rec.ljdm,
               d_rec.lclx,
               d_rec.lclx_xh,
               d_rec.cc,
               d_rec.qcc,
               d_rec.lj_xh,
               d_rec.yxfs,
               '交出',
               d_rec.jc_zm,
               v_tdcfsj,
               v_cfsj,
               v_cfwd,
               v_cfid);
            v_tmp := to_char(cf_rec.tdcfsj, 'yyyy-mm-dd'); /*将日期填入v_tmp，以供比较下一条数据集的日期*/
          end if;
        end loop;
        close select_cfzm;
      end if;
    
      /*4.2 交出站为邻局管辖*/
      v_has1 := 0;
      select count(*)
        into v_has1
        from v_yxsj_ljzdfjk2
       where trim(fjk_name) = trim(d_rec.jc_zm);
      if (v_has1 > 0) then
        /*交出站为邻局管辖*/
        open select_ddzm(d_rec.jc_zm, d_rec.qcc); /*这里将遍历车次字典表YXSJ_LJZD_CC得到的一行记录中的终到站名和全车次作为参数，传入游标2，返回0行到多行数据集*/
        /*循环遍历返回的数据集*/
        loop
          <<go_jc2>>
          fetch select_ddzm
            into dd_rec;
          exit when select_ddzm%notfound; /*这里说明返回数据集记录数为0，即终到站在该18点区段内没有报点，则跳出循环*/
          if (v_tmp = to_char(dd_rec.tdddsj, 'yyyy-mm-dd')) then
            /*continue; /*这里说明出现了同一天内的多条数据，说明是多个行调台报同一天的数，只取一次，不再重复取，跳出循环*/
            goto go_jc2;
          else
            /*这里说明有不同日期的车未取过，则开始取数*/
            v_tdzdrq := to_char(dd_rec.tdddsj, 'yyyy-mm-dd'); /*图定交出日期*/
            v_tdsfrq := to_date(v_tdzdrq, 'yyyy-mm-dd') - d_rec.jc_ts; /*根据交出日期，减去交出天数，得到图定始发日期*/
            v_tdddsj := dd_rec.tdddsj; /*图定终到时间*/
            v_ddsj   := dd_rec.ddsj; /*实际终到时间*/
            v_ddwd   := dd_rec.dd_wd; /*终到晚点时间*/
            v_ddid   := dd_rec.id; /*终到列车ID*/
            /*开始向 YXSJ_SFZD_FJK 表插入记录*/
            insert into yxsj_sfzd_fjk
              (sfzd_fjk_id,
               tbrq,
               sfrq,
               lj_jc,
               ljdm,
               lclx,
               lclx_xh,
               cc,
               qcc,
               lj_xh,
               yxfs,
               czlx,
               zm,
               tdsj,
               sjsj,
               wdsj,
               lcid)
            values
              (SEQ_YXSJ_SFZD_FJK.nextval,
               sysdate,
               v_tdsfrq,
               d_rec.lj_jc,
               d_rec.ljdm,
               d_rec.lclx,
               d_rec.lclx_xh,
               d_rec.cc,
               d_rec.qcc,
               d_rec.lj_xh,
               d_rec.yxfs,
               '交出',
               d_rec.jc_zm,
               v_tdddsj,
               v_ddsj,
               v_ddwd,
               v_ddid);
            v_tmp := to_char(dd_rec.tdddsj, 'yyyy-mm-dd'); /*将日期填入v_tmp，以供比较下一条数据集的日期*/
          end if;
        end loop;
        close select_ddzm;
      
      end if;
    end if;
  
    commit;
  end loop;
  close d;

  /* 填写调度台名称----start*/
  open f;
  loop
    fetch f
      into f_rec;
    exit when f%notfound;
    if (f_rec.lcid != 0) then
      /*    修改2013-01-18      begin     */
      begin
        select tm
          into SFZD_FJK_DDT
          from V_YXSJ_LCID_DDT
         where id = f_rec.lcid;
      exception
        when no_data_found then
          null;
      end;
      if (not SFZD_FJK_DDT is null) then
        /*    修改2013-01-18     end      */
        update yxsj_sfzd_fjk
           set ddt = SFZD_FJK_DDT
         where sfzd_fjk_id = f_rec.sfzd_fjk_id;
      end if;
    end if;
  
  end loop;
  close f;
  commit;
  /* 填写调度台名称----end*/

  /* 填写站名映射    begin           */
  open select_zm1;
  loop
    fetch select_zm1
      into rec_zm1;
    exit when select_zm1%notfound;
    update YXSJ_SFZD_FJK
       set zm_show = rec_zm1.tdms_zm
     where SFZD_FJK_ID = rec_zm1.SFZD_FJK_ID;
  end loop;
  close select_zm1;
  commit;

  open select_zm2;
  loop
    fetch select_zm2
      into rec_zm2;
    exit when select_zm2%notfound;
  
    update YXSJ_SFZD_FJK
       set zm_show = zm
     where SFZD_FJK_ID = rec_zm2.SFZD_FJK_ID;
  end loop;
  close select_zm2;
  commit;
  /* 填写站名映射    end */

  /*删除临时表yxsj_xd_traintt里的数据---start*/
  execute immediate 'truncate table yxsj_xd_traintt';
  /*删除临时表yxsj_xd_traintt里的数据---end*/

  /*向表 YXSJ_QSBS_SJ 中填写取数时间---start*/
  insert into YXSJ_QSBS_SJ
  values
    (SEQ_YXSJ_QSBS_SJ.nextval,
     (select lj_jc from yxsj_ljzd_jm),
     (select ljdm from yxsj_ljzd_jm),
     '按车站取数',
     sysdate,
     Trunc(sysdate));
  commit;
  /*向表 YXSJ_QSBS_SJ 中填写取数时间---end*/

  /* 异常处理,提示错误信息*/
exception
  when errormessage then
    dbms_output.put_line('没找到');
end PRO_YXSJ_SFZDFJK;
/

