create procedure backup_data_p
AS
curtime char(2);
date3YearAgo char(8);
date2YearAgo char(8);
date1YearAgo char(8);
date18MonthAgo char(8);
date2MonthAgo char(8);
date1MonthAgo char(8);
date2WeekAgo char(8);
tmpBln boolean;
rows number;
BEGIN
select to_char(sysdate,'HH24') into curtime from dual;
if curtime>'22' then
  rows:=0;
  select count(*) into rows from users_log where to_char(log_time,'yyyymmdd')=to_char(sysdate,'yyyymmdd') and user_id='DB' and name='OracleDB' and logtype='KdzhDataBachupRefresh';
  if rows=0 then
    select to_char(sysdate-(365*3),'yyyymmdd') into date3YearAgo from dual;
    select to_char(sysdate-(365*2),'yyyymmdd') into date2YearAgo from dual;
    select to_char(sysdate-365,'yyyymmdd') into date1YearAgo from dual;
    select to_char(sysdate-(30*18),'yyyymmdd') into date18MonthAgo from dual;
    select to_char(sysdate-(30*2),'yyyymmdd') into date2MonthAgo from dual;
    select to_char(sysdate-30,'yyyymmdd') into date1MonthAgo from dual;
    select to_char(sysdate-15,'yyyymmdd') into date2WeekAgo from dual;
    --备份
    insert into count_ljklktj_backup select * from count_ljklktj where rq<date2YearAgo;
    delete from count_ljklktj where rq<date2YearAgo;
    insert into users_log(log_time,user_id,note,name,logtype) values(sysdate,'DB','数据备份[5-1]count_ljklktj表','OracleDB','KdzhDataBachupRefresh');
    commit;
    --
    insert into car_bcgjb_backup select * from car_bcgjb where to_char(bzgxsj,'yyyymmdd')<date2MonthAgo;
    delete from car_bcgjb where to_char(bzgxsj,'yyyymmdd')<date2MonthAgo;
    insert into users_log(log_time,user_id,note,name,logtype) values(sysdate,'DB','数据备份[5-2]car_bcgjb表','OracleDB','KdzhDataBachupRefresh');
    commit;
    --
    insert into cross_log_backup select * from cross_log where to_char(systemdat,'yyyymmdd')<date2MonthAgo;
    delete from cross_log where to_char(systemdat,'yyyymmdd')<date2MonthAgo;
    insert into users_log(log_time,user_id,note,name,logtype) values(sysdate,'DB','数据备份[5-3]cross_log表','OracleDB','KdzhDataBachupRefresh');
    commit;
    --
    tmpBln:=false;
    tmpBln:=backup_cross_graphics(date2MonthAgo);
    if tmpBln then
      insert into users_log(log_time,user_id,note,name,logtype) values(sysdate,'DB','数据备份[5-4]cross_graphics系列工作表','OracleDB','KdzhDataBachupRefresh');
      commit;
    end if;
    --
    tmpBln:=false;
    tmpBln:=backup_cross_graphics_log(date2WeekAgo);
    if tmpBln then
      insert into users_log(log_time,user_id,note,name,logtype) values(sysdate,'DB','数据备份[5-5]cross_graphics_log系列工作表','OracleDB','KdzhDataBachupRefresh');
      commit;
    end if;
    --//
    --整理
    delete from count_ljklktj_backup where rq<date3YearAgo;
    insert into users_log(log_time,user_id,note,name,logtype) values(sysdate,'DB','历史清理[5-1]count_ljklktj_backup表','OracleDB','KdzhDataBachupRefresh');
    commit;
    --
    delete from car_bcgjb_backup where to_char(bzgxsj,'yyyymmdd')<date1YearAgo;
    insert into users_log(log_time,user_id,note,name,logtype) values(sysdate,'DB','历史清理[5-2]car_bcgjb_backup表','OracleDB','KdzhDataBachupRefresh');
    commit;
    --
    delete from cross_log_backup where to_char(systemdat,'yyyymmdd')<date1YearAgo;
    insert into users_log(log_time,user_id,note,name,logtype) values(sysdate,'DB','历史清理[5-3]cross_log_backup表','OracleDB','KdzhDataBachupRefresh');
    commit;
    --
    tmpBln:=false;
    tmpBln:=clear_cross_graphics_backup(date1YearAgo);
    if tmpBln then
      insert into users_log(log_time,user_id,note,name,logtype) values(sysdate,'DB','历史清理[5-4]cross_graphics_backup系列工作表','OracleDB','KdzhDataBachupRefresh');
      commit;
    end if;
    --
    --tmpBln:=false;
    --tmpBln:=clear_crossgraphicslog_backup(date1YearAgo);
    --if tmpBln then
    --  insert into users_log(log_time,user_id,note,name,logtype) values(sysdate,'DB','历史清理[5-5]cross_graphics_log_backup系列工作表','OracleDB','KdzhDataBachupRefresh');
    --  commit;
    --end if;
    --通用数据整理
    tmpBln:=false;
    tmpBln:=backup_common_data(date18MonthAgo);
    if tmpBln then
      insert into users_log(log_time,user_id,note,name,logtype) values(sysdate,'DB','通用数据清理','OracleDB','KdzhDataBachupRefresh');
      commit;
    end if;
  end if;
end if;
END;


/

