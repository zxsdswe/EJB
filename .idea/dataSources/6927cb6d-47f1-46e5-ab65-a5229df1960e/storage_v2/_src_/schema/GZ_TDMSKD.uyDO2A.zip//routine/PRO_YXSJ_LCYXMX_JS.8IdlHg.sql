create procedure PRO_YXSJ_LCYXMX_JS is
  /*本存储过程用于从T/D结合数据库xd_train_tt表中采集列车运行明细的第二部分，主要功能是
  计算增晚和赶点时间，根据列车ID填写调度台，根据站名映射填写显示站名*/

  v_sfwd yxsj_ljlcyxmx.jr_wd%type;
  v_jcwd yxsj_ljlcyxmx.jr_wd%type;
  v_jrwd yxsj_ljlcyxmx.jr_wd%type;
  v_zdwd yxsj_ljlcyxmx.jr_wd%type;
  v_zwsj yxsj_ljlcyxmx.zwsj%type;
  v_gdsj yxsj_ljlcyxmx.gdsj%type;

  cursor d is
    select lcyxmx_id, yxfs, jc_wd, zd_wd, jr_wd, sf_wd
      from yxsj_ljlcyxmx
     where to_char(tbrq, 'yyyy-mm-dd') = to_char(sysdate, 'yyyy-mm-dd')
       and zwjsbj is null;
  d_rec d%rowtype;

  cursor c_sfddt is
    select lcyxmx_id, sf_trainid, tm

      from yxsj_ljlcyxmx a, V_YXSJ_LCID_DDT b
     where to_char(tbrq, 'yyyy-mm-dd') = to_char(sysdate, 'yyyy-mm-dd')
       and sf_ddt is null
       and a.sf_trainid = b.id;

  sfddt_rec c_sfddt %rowtype;

  cursor c_zdddt is
    select lcyxmx_id, zd_trainid, tm
      from yxsj_ljlcyxmx a, V_YXSJ_LCID_DDT b
     where to_char(tbrq, 'yyyy-mm-dd') = to_char(sysdate, 'yyyy-mm-dd')
       and zd_ddt is null
       and a.zd_trainid = b.id;

  zdddt_rec c_zdddt %rowtype;
  cursor c_jrddt is
    select lcyxmx_id, jr_trainid, tm

      from yxsj_ljlcyxmx a, V_YXSJ_LCID_DDT b
     where to_char(tbrq, 'yyyy-mm-dd') = to_char(sysdate, 'yyyy-mm-dd')
       and jr_ddt is null
       and a.jr_trainid = b.id;

  jrddt_rec c_jrddt %rowtype;

  cursor c_jcddt is
    select lcyxmx_id, jc_trainid, tm

      from yxsj_ljlcyxmx a, V_YXSJ_LCID_DDT b
     where to_char(tbrq, 'yyyy-mm-dd') = to_char(sysdate, 'yyyy-mm-dd')
       and jc_ddt is null
       and a.jc_trainid = b.id;

  jcddt_rec c_jcddt %rowtype;

  /* 2012-01-21       end*/

  cursor select_zdzm1 is
    select lcyxmx_id, tdms_zm
      from yxsj_ljlcyxmx t, yxsj_ljzd_zmys m
     where to_char(tbrq, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')
       and trim(t.zd_zm) = trim(m.tdcs_node)
       and zd_zm_show is null;
  rec_zdzm1 select_zdzm1%rowtype;

  cursor select_zdzm2 is
    select lcyxmx_id, zd_zm
      from yxsj_ljlcyxmx t, yxsj_ljzd_zmys m
     where to_char(tbrq, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')
       and trim(t.zd_zm) != trim(m.tdcs_node)
       and zd_zm_show is null;
  rec_zdzm2 select_zdzm2%rowtype;

  cursor select_sfzm1 is
    select lcyxmx_id, tdms_zm
      from yxsj_ljlcyxmx t, yxsj_ljzd_zmys m
     where to_char(tbrq, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')
       and trim(t.sf_zm) = trim(m.tdcs_node)
       and sf_zm_show is null;
  rec_sfzm1 select_sfzm1%rowtype;

  cursor select_sfzm2 is
    select lcyxmx_id, sf_zm
      from yxsj_ljlcyxmx t, yxsj_ljzd_zmys m
     where to_char(tbrq, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')
       and trim(t.sf_zm) != trim(m.tdcs_node)
       and sf_zm_show is null;
  rec_sfzm2 select_sfzm2%rowtype;

  cursor select_jrzm1 is
    select lcyxmx_id, tdms_zm
      from yxsj_ljlcyxmx t, yxsj_ljzd_zmys m
     where to_char(tbrq, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')
       and trim(t.jr_zm) = trim(m.tdcs_node)
       and jr_zm_show is null;
  rec_jrzm1 select_jrzm1%rowtype;

  cursor select_jrzm2 is
    select lcyxmx_id, jr_zm
      from yxsj_ljlcyxmx t, yxsj_ljzd_zmys m
     where to_char(tbrq, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')
       and trim(t.jr_zm) != trim(m.tdcs_node)
       and jr_zm_show is null;
  rec_jrzm2 select_jrzm2%rowtype;

  cursor select_jczm1 is
    select lcyxmx_id, tdms_zm
      from yxsj_ljlcyxmx t, yxsj_ljzd_zmys m
     where to_char(tbrq, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')
       and trim(t.jc_zm) = trim(m.tdcs_node)
       and jc_zm_show is null;
  rec_jczm1 select_jczm1%rowtype;

  cursor select_jczm2 is
    select lcyxmx_id, jc_zm
      from yxsj_ljlcyxmx t, yxsj_ljzd_zmys m
     where to_char(tbrq, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')
       and trim(t.jc_zm) != trim(m.tdcs_node)
       and jc_zm_show is null;
  rec_jczm2 select_jczm2%rowtype;

begin
  open d;
  loop
    fetch d
      into d_rec;
    exit when d%notfound;

    /* 2013-04-28      调用存储过程来计算增晚和           ***************/
    PRO_YXSJ_JSWD(d_rec.yxfs,
             d_rec.sf_wd,
             d_rec.jr_wd,
             d_rec.jc_wd,
             d_rec.zd_wd,
             v_zwsj,
             v_gdsj,
             v_sfwd,
             v_jrwd,
             v_jcwd,
             v_zdwd);
    if (d_rec.yxfs = '始发交出') then
      update yxsj_ljlcyxmx
         set sf_wd  = v_sfwd,
             jc_wd  = v_jcwd,
             zwsj   = v_zwsj,
             gdsj   = v_gdsj,
             zwjsbj = 1
       where lcyxmx_id = d_rec.lcyxmx_id;
    end if;

    if (d_rec.yxfs = '接入交出') then
      update yxsj_ljlcyxmx
         set jr_wd  = v_jrwd,
             jc_wd  = v_jcwd,
             zwsj   = v_zwsj,
             gdsj   = v_gdsj,
             zwjsbj = 1
       where lcyxmx_id = d_rec.lcyxmx_id;
    end if;

     if (d_rec.yxfs = '接入终到') then
      update yxsj_ljlcyxmx
         set jr_wd  = v_jrwd,
             zd_wd  = v_zdwd,
             zwsj   = v_zwsj,
             gdsj   = v_gdsj,
             zwjsbj = 1
       where lcyxmx_id = d_rec.lcyxmx_id;
    end if;

     if (d_rec.yxfs = '始发终到') then
      update yxsj_ljlcyxmx
         set sf_wd  = v_sfwd,
             zd_wd  = v_zdwd,
             zwsj   = v_zwsj,
             gdsj   = v_gdsj,
             zwjsbj = 1
       where lcyxmx_id = d_rec.lcyxmx_id;
    end if;

  end loop;
  close d;
  commit;

  /* 填写调度台名称*/
  /*----------------------modified --2013--01-21       begin          -------------*/
  open c_sfddt;
  loop
    fetch c_sfddt
      into sfddt_rec;
    exit when c_sfddt%notfound;

    update yxsj_ljlcyxmx
       set sf_ddt = sfddt_rec.tm
     where lcyxmx_id = sfddt_rec.lcyxmx_id;
  end loop;
  open c_zdddt;
  loop
    fetch c_zdddt
      into zdddt_rec;
    exit when c_zdddt%notfound;
    update yxsj_ljlcyxmx
       set zd_ddt = zdddt_rec.tm
     where lcyxmx_id = zdddt_rec.lcyxmx_id;
  end loop;
  open c_jrddt;
  loop
    fetch c_jrddt
      into jrddt_rec;
    exit when c_jrddt%notfound;

    update yxsj_ljlcyxmx
       set jr_ddt = jrddt_rec.tm
     where lcyxmx_id = jrddt_rec.lcyxmx_id;
  end loop;

  open c_jcddt;
  loop
    fetch c_jcddt
      into jcddt_rec;
    exit when c_jcddt%notfound;

    update yxsj_ljlcyxmx
       set jc_ddt = jcddt_rec.tm
     where lcyxmx_id = jcddt_rec.lcyxmx_id;
  end loop;

  close c_sfddt;
  close c_zdddt;
  close c_jrddt;
  close c_jcddt;
  commit;
  /*------------------------2013--01-21            end      -------------*/
  /* 1 填写终到站名映射    begin           */
  open select_zdzm1;
  loop
    fetch select_zdzm1
      into rec_zdzm1;
    exit when select_zdzm1%notfound;
    update yxsj_ljlcyxmx
       set zd_zm_show = rec_zdzm1.tdms_zm
     where lcyxmx_id = rec_zdzm1.lcyxmx_id;
  end loop;
  close select_zdzm1;
  commit;

  open select_zdzm2;
  loop
    fetch select_zdzm2
      into rec_zdzm2;
    exit when select_zdzm2%notfound;

    update yxsj_ljlcyxmx
       set zd_zm_show = zd_zm
     where lcyxmx_id = rec_zdzm2.lcyxmx_id;
  end loop;
  close select_zdzm2;
  commit;
  /* 1 填写终到站名映射*    end */

  /* 2 填写始发站名映射    begin           */
  open select_sfzm1;
  loop
    fetch select_sfzm1
      into rec_sfzm1;
    exit when select_sfzm1%notfound;
    update yxsj_ljlcyxmx
       set sf_zm_show = rec_sfzm1.tdms_zm
     where lcyxmx_id = rec_sfzm1.lcyxmx_id;
  end loop;
  close select_sfzm1;
  commit;

  open select_sfzm2;
  loop
    fetch select_sfzm2
      into rec_sfzm2;
    exit when select_sfzm2%notfound;
    update yxsj_ljlcyxmx
       set sf_zm_show = rec_sfzm2.sf_zm
     where lcyxmx_id = rec_sfzm2.lcyxmx_id;
  end loop;
  close select_sfzm2;
  commit;
  /* 2 填写始发站名映射    end           */

  /* 3 填写接入站名映射    begin           */

  open select_jrzm1;
  loop
    fetch select_jrzm1
      into rec_jrzm1;
    exit when select_jrzm1%notfound;
    update yxsj_ljlcyxmx
       set jr_zm_show = rec_jrzm1.tdms_zm
     where lcyxmx_id = rec_jrzm1.lcyxmx_id;
  end loop;
  close select_jrzm1;
  commit;

  open select_jrzm2;
  loop
    fetch select_jrzm2
      into rec_jrzm2;
    exit when select_jrzm2%notfound;
    update yxsj_ljlcyxmx
       set jr_zm_show = rec_jrzm2.jr_zm
     where lcyxmx_id = rec_jrzm2.lcyxmx_id;
  end loop;
  close select_jrzm2;
  commit;
  /* 3 填写接入站名映射    end          */

  /* 4 填写接出站名映射    begin           */
  open select_jczm1;
  loop
    fetch select_jczm1
      into rec_jczm1;
    exit when select_jczm1%notfound;
    update yxsj_ljlcyxmx
       set jc_zm_show = rec_jczm1.tdms_zm
     where lcyxmx_id = rec_jczm1.lcyxmx_id;
  end loop;
  close select_jczm1;
  commit;

  open select_jczm2;
  loop
    fetch select_jczm2
      into rec_jczm2;
    exit when select_jczm2%notfound;
    update yxsj_ljlcyxmx
       set jc_zm_show = jc_zm
     where lcyxmx_id = rec_jczm2.lcyxmx_id;
  end loop;
  close select_jczm2;
  /* 5 填写交出站名映射    end           */

  commit;
end PRO_YXSJ_LCYXMX_JS;
/

