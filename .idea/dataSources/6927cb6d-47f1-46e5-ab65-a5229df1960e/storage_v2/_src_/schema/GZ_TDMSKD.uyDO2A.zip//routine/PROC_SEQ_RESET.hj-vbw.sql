create procedure proc_seq_reset(p_seqname in varchar2)
as
   vn_number       number;
   vr_sequence  user_sequences%rowtype;
Begin
select * into vr_sequence from user_sequences t where t.sequence_name=upper(p_seqname);

    execute immediate 'alter sequence '||p_seqname||' increment by '||(1-vr_sequence.last_number)|| ' nocache';
    execute immediate 'select ' || p_seqname|| '.nextval from dual' into vn_number;
    execute immediate 'alter sequence '||p_seqname||' increment by 1 nocache';

exception
   when others then
      null;

end proc_seq_reset;
/

