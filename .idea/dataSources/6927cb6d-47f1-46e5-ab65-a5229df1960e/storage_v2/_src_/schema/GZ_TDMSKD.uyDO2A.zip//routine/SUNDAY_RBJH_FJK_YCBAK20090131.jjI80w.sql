create procedure sunday_rbjh_fjk_ycbak20090131(dnum  in number) is
rqstr       varchar2(8);
runid    number(10);
rid      number(10);
id       number(10);
qid      number(10);
sfddid   number(10);
bid      varchar2(10);
hid      varchar2(10);
sfbz     varchar2(10);
runcc    varchar2(16);
lcc      varchar2(5);
tjn      varchar2(16);
zm       varchar2(16);
gsj      varchar2(16);
grq      varchar2(16);
hrq      varchar2(20);
str_sfz  varchar2(20);
str_dzd  varchar2(20);
sta_sj   varchar2(20);
end_sj   varchar2(20);
sta_d   varchar2(20);
end_d   varchar2(20);
nfjkz   varchar2(20);
ii       number(5);
DAY1    varchar2(16);
DAY2    varchar2(16);
kct1    number(5);
kcl1    number(5);
kch1    number(5);
kct2    number(5);
kcl2    number(5);
kch2    number(5);
kct3    number(5);
kcl3    number(5);
kch3    number(5);
kct4    number(5);
kcl4    number(5);
kch4    number(5);
kct5    number(5);
kcl5    number(5);
kch5    number(5);
wno     varchar2(16);
------读出发车次
--CURSOR read_run_line IS
--SELECT  runline_id,cc,sfz,zdz
--    FROM run_line a, run_point b
--   WHERE a.ID = b.runline_id
--     AND TRUNC (TO_DATE (go_date || go_time, 'yyyymmddhh24mi') + 0.25 - 1 / 1440) = TRUNC (SYSDATE +dnum)
--     AND b.xh = 1
--     AND (cc NOT LIKE '0%')  AND (cc NOT LIKE 'X%') AND (cc NOT LIKE 'DJ%')
--     AND (cc NOT LIKE '8%')  AND (STOPFLAg = 1)
 --    and station_name in (select station_name from b_station where bureau_code='Q')  ORDER BY cc  ; 
CURSOR read_run_line IS
SELECT  id,cc,sfz,zdz    FROM run_line 
   WHERE id in (select  runline_id from run_point where arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj 
        and station_name in (select station_name from b_station where bureau_code='Q' and station_name<>'九龙')  and xh=1 )
       AND (cc NOT LIKE 'X%') AND (cc NOT LIKE 'DJ%') AND (cc NOT LIKE '57%')
     AND (cc NOT LIKE '8%')  AND (STOPFLAg = 1)  ORDER BY cc  ; 
------读终到车次
CURSOR read_run_line_zd IS
SELECT  id,cc,sfz,zdz    FROM run_line 
   WHERE  id in (select  runline_id from run_point where arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj 
        and station_name in (select station_name from b_station where bureau_code='Q')  and arr_time<>'-100')
         AND (cc NOT LIKE 'X%') AND (cc NOT LIKE 'DJ%')   AND (cc NOT LIKE '8%') AND (cc NOT LIKE '57%')  AND (STOPFLAg = 1)
       ORDER BY cc  ; 
-------读分界口车次数据
CURSOR read_run_point_fjk IS
SELECT  runline_id,station_name,arr_date||arr_time,go_date||go_time,xh    FROM run_point 
   WHERE  runline_id in (select  id from run_line where STOPFLAG = 1 
           AND cc NOT LIKE 'X%' AND cc NOT LIKE 'DJ%'   AND cc NOT LIKE '8%')
   and arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj  and arr_time<>'-100' 
   and station_name in ( '蒲圻','西斋','秀山','大龙','牙屯堡','滩头湾','定南','茂名','琥市','塘口') ; 
   
 ------读深圳口车次数据
CURSOR read_run_point_sz IS
SELECT  runline_id,station_name,arr_date||arr_time,go_date||go_time,xh    FROM run_point 
   WHERE  runline_id in (select  id from run_line where STOPFLAG = 1 
           AND cc NOT LIKE 'X%' AND cc NOT LIKE 'DJ%'   AND cc NOT LIKE '8%')
   and arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj  and arr_time<>'-100' 
   and station_name in ( '深圳') ; 
   
-------读分界口车次数据
CURSOR read_run_point_zzk IS
SELECT  runline_id,station_name,arr_date||arr_time,go_date||go_time,xh    FROM run_point 
   WHERE  runline_id in (select  id from run_line where STOPFLAG = 1 
          AND  cc NOT LIKE 'X%' AND cc NOT LIKE 'DJ%'   AND cc NOT LIKE '8%')
   and arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj  and arr_time<>'-100'   
   and station_name in ( '株洲') ; 
-------读坪石口车次数据
CURSOR read_run_point_psk IS
SELECT  runline_id,station_name,arr_date||arr_time,go_date||go_time,xh    FROM run_point 
   WHERE  runline_id in (select  id from run_line where STOPFLAG = 1 
          AND  cc NOT LIKE 'X%' AND cc NOT LIKE 'DJ%'   AND cc NOT LIKE '8%' and  cc NOT LIKE '576%') 
   and arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj  and arr_time<>'-100' 
   and station_name ='坪石北' ; 
-----读出发车次分析数据----
CURSOR read_dds_start_kc_data IS
SELECT  distinct(station)    FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz order by station; 
begin
    select to_char(sysdate + dnum,'yyyymmdd') into rqstr  from dual;
    select to_char(sysdate + dnum -1,'yyyymmdd') into sta_sj  from dual;
    DAY1 :=sta_sj;
    DAY2 :=rqstr;
    sta_d :=sta_sj;
    end_d :=end_sj;
    sta_sj :=sta_sj||'1800';
    end_sj :=rqstr||'1800'; 
    delete from dds_start_kc_data where rq = rqstr;
    delete from dds_start_kc_tj where rq = rqstr;
    delete from dds_start_kc_tj_zlw where rq = rqstr;
    commit;
    rid := 0;
  OPEN read_run_line;
       LOOP
       FETCH read_run_line INTO runid,runcc,str_sfz,str_dzd;
       EXIT WHEN read_run_line%NOTFOUND;
 ---      select count(*) into id  from run_line where cc=rqstr;
       select station_name,go_date,go_time into zm,grq,gsj  from run_point where runline_id=runid and xh=1;
       hrq:=grq||gsj;
       rid := rid + 1;
       lcc := substr(runcc,1,1);
       select count(*) into sfddid from dds_start_kc_data_qj where (end_station = zm AND start_station=str_dzd) or (end_station = str_dzd AND start_station=zm);
        if (sfddid>0 and lcc ='0') or runcc ='57001' or runcc ='57002'  THEN 
           str_dzd:='不写';
        ELSE
           insert into dds_start_kc_data values (rqstr,'始发',rid,runid,zm,runcc,hrq,zm,str_dzd);
         END IF;
      commit;
      end loop;
      CLOSE read_run_line;
 -------终到数据统计-------  
 rid := 0;   
OPEN read_run_line_zd;
       LOOP
       FETCH read_run_line_zd INTO runid,runcc,str_sfz,str_dzd;
       EXIT WHEN read_run_line_zd%NOTFOUND;
        select station_name,arr_date,arr_time into zm,grq,gsj  from run_point where runline_id=runid and xh in (
        select max(xh) from run_point where runline_id = runid );
        select count(*) into id from b_station where station_name = zm AND bureau_code='Q' and station_name<>'九龙';
        select station_name into str_sfz from run_point where runline_id = runid and xh=1;
        
        hrq:=grq||gsj;
        if id > 0 and hrq >sta_sj and hrq <= end_sj then 
            rid := rid + 1;
 --------dds_start_kc_data_qj在不在统计区段内的数
          lcc := substr(runcc,1,1);
          select count(*) into sfddid from dds_start_kc_data_qj where (end_station = zm AND start_station=str_sfz) or (end_station = str_sfz AND start_station=zm);
             if (sfddid>0 and lcc ='0') or runcc ='57001' or runcc ='57002' THEN 
                str_sfz:='不写';
              else
                 insert into dds_start_kc_data values (rqstr,'终到',rid,runid,zm,runcc,hrq,str_sfz,zm);
             end if;
        end if;
      commit; 
  end loop;
  CLOSE read_run_line_zd;
  -------交出接入统计
  rid := 0;   
OPEN read_run_point_fjk;
       LOOP
       FETCH read_run_point_fjk INTO runid,zm,sta_d,end_d,id;
       EXIT WHEN read_run_point_fjk%NOTFOUND;
        select cc,sfz,zdz into runcc,str_sfz,str_dzd  from run_line where id=runid ;
         id :=id + 1;
        select station_name  into nfjkz from run_point  where runline_id = runid and xh = id;
        select count(*) into id from b_station where station_name = nfjkz AND bureau_code='Q' and station_name<>'九龙';
        hrq:=end_d;
         
        select station_name  into str_sfz from run_point  where runline_id = runid and xh = 1;
        select station_name  into str_dzd from run_point  where runline_id = runid and xh in (select max(xh) from run_point where runline_id = runid);
            if id > 0 then 
            nfjkz :='接入';
             else
             nfjkz :='交出';
            end if;
           if  nfjkz ='接入'  then  
              if  (ZM  = '滩头湾' or  ZM = '株洲' or  ZM = '琥市' ) then
                   hrq:=sta_d;
                else
                   hrq:=end_d;
                end if;
           end if;
          if  nfjkz ='交出'  then  
              if  (ZM  = '滩头湾' or  ZM = '株洲' or  ZM = '琥市' ) then
                  hrq:=end_d;
                else
                  hrq:=sta_d;
                end if;
           end if;
           if  hrq >sta_sj and hrq <= end_sj then
               rid := rid + 1;
             insert into dds_start_kc_data values (rqstr,nfjkz,rid,runid,zm,runcc,hrq,str_sfz,str_dzd);
        end if;
      commit; 
  end loop;
  CLOSE read_run_point_fjk;
  
  
  
-------交出接入统计
  rid := 0;   
OPEN read_run_point_sz;
       LOOP
       FETCH read_run_point_sz INTO runid,zm,sta_d,end_d,id;
       EXIT WHEN read_run_point_sz%NOTFOUND;
        select cc,sfz,zdz into runcc,str_sfz,str_dzd  from run_line where id=runid ;
        select max(xh) into id from run_point  where runline_id = runid;
 ------ id :=id + 1;-----下一个车站-----最后一个站
        select station_name  into nfjkz from run_point  where runline_id = runid and xh = id;
        if nfjkz='九龙' THEN 
        hrq:=end_d;
        select station_name  into str_sfz from run_point  where runline_id = runid and xh = 1;
        select station_name  into str_dzd from run_point  where runline_id = runid and xh in (select max(xh) from run_point where runline_id = runid);
             nfjkz :='交出';
             hrq:=end_d;
           if  hrq >sta_sj and hrq <= end_sj then
               rid := rid + 1;
             insert into dds_start_kc_data values (rqstr,nfjkz,rid,runid,zm,runcc,hrq,str_sfz,str_dzd);
        end if;
        end if;
      commit; 
  end loop;
  CLOSE read_run_point_sz;
  
-------交出接入统计------株洲口
 rid := 0;   
  OPEN read_run_point_zzk;
      LOOP
       FETCH read_run_point_zzk INTO runid,zm,sta_d,end_d,id;
       EXIT WHEN read_run_point_zzk%NOTFOUND;
        select cc,sfz,zdz into runcc,str_sfz,str_dzd  from run_line where id=runid ;
         qid :=id;
         id :=id + 1;----下一站
         hid :='';
         bid :='';
         begin
        select station_name  into nfjkz from run_point  where runline_id = runid and xh = id;
        EXCEPTION 
        WHEN OTHERS THEN 
            id :=id - 1;
           select station_name  into nfjkz from run_point  where runline_id = runid and xh = id;
       ROLLBACK;
       end;
        select bureau_code into hid from b_station where station_name = nfjkz  and station_name<>'九龙';
        if hid ='Q' then 
             id := 1;
          else
             id := 0;
          end if;
         if qid > 1 then   
              qid :=qid - 1;----前一站
         end if;
         
        select station_name  into nfjkz from run_point  where runline_id = runid and xh = qid;
        select bureau_code into bid from b_station where station_name = nfjkz  and station_name<>'九龙';
        tjn := 'y';
        if bid='Q' AND hid='Q' then 
           tjn:='n';
        end if;
        if bid<>'Q' AND hid<>'Q' then 
           tjn :='n';
         end if;
        hrq:=end_d;
    if tjn ='y' then     
        select station_name  into str_sfz from run_point  where runline_id = runid and xh = 1;
        select station_name  into str_dzd from run_point  where runline_id = runid and xh in (select max(xh) from run_point where runline_id = runid);
            if id > 0 then 
            nfjkz :='接入';
             else
             nfjkz :='交出';
            end if;
           if  nfjkz ='接入'  then  
              if  (ZM  = '滩头湾' or  ZM = '株洲' or  ZM = '琥市' ) then
                   hrq:=sta_d;
                else
                   hrq:=end_d;
                end if;
           end if;
            if  nfjkz ='交出'  then  
               if  (ZM  = '滩头湾' or  ZM = '株洲' or  ZM = '琥市' ) then
                   hrq:=end_d;
                else
                   hrq:=sta_d;
                end if;
           end if;
           if  hrq >sta_sj and hrq <= end_sj then
                 rid := rid + 1;
                insert into dds_start_kc_data values (rqstr,nfjkz,rid,runid,zm,runcc,hrq,str_sfz,str_dzd);
           end if;
    end if;
      commit; 
  end loop;
  CLOSE read_run_point_zzk;  
  
------管内株洲口的统计方法  

rid := 0;   
  OPEN read_run_point_zzk;
      LOOP
       FETCH read_run_point_zzk INTO runid,zm,sta_d,end_d,id;
       EXIT WHEN read_run_point_zzk%NOTFOUND;
        select cc,sfz,zdz into runcc,str_sfz,str_dzd  from run_line where id=runid ;
         qid :=id;
         id :=id + 1;----下一站
         hid :='';
         bid :='';
         tjn := 'y';
         begin
        select station_name  into nfjkz from run_point  where runline_id = runid and xh = id;
        EXCEPTION 
        WHEN OTHERS THEN 
            id :=id - 1;
           select station_name  into nfjkz from run_point  where runline_id = runid and xh = id;
           tjn :='y';----不统计，是株洲站终止
 ----      ROLLBACK;
       end;
        hid :='下一站';
        begin
        select bureau_code into hid from b_station_gnzzk where station_name = nfjkz  and station_name<>'九龙';
        EXCEPTION 
        WHEN OTHERS THEN 
           hid :='下一站';
        END;
        -----没有下一个站
         if qid > 1 then   
              qid :=qid - 1;----前一站
         end if;
        select station_name  into nfjkz from run_point  where runline_id = runid and xh = qid;
        bid:='前一站';
        begin
        select bureau_code into bid from b_station_gnzzk where station_name = nfjkz  and station_name<>'九龙';
        EXCEPTION 
        WHEN OTHERS THEN 
           bid :='前一站';
        END;
        if (bid='前一站' or bid =null) AND (hid='下一站' or hid=null) then 
           tjn:='n';
        end if;
        hrq:=end_d;
    if tjn ='y' then     
        select station_name  into str_sfz from run_point  where runline_id = runid and xh = 1;
        select station_name  into str_dzd from run_point  where runline_id = runid and xh in (select max(xh) from run_point where runline_id = runid);
            if bid<>'前一站' AND hid='下一站' then 
            nfjkz :='交出';
             else
             nfjkz :='接入';
            end if;
           if  nfjkz ='交出'  then  
                   hrq:=sta_d;
                else
                   hrq:=end_d;
           end if;
         
           if  hrq >sta_sj and hrq <= end_sj then
                 rid := rid + 1;
                 begin
                insert into dds_start_kc_data values (rqstr,nfjkz,rid,runid,'管内株洲',runcc,hrq,str_sfz,str_dzd);
                EXCEPTION 
            WHEN OTHERS THEN 
               ROLLBACK;
             END;
           end if;
    end if;
      commit; 
  end loop;
  CLOSE read_run_point_zzk;    
  

  
  
 -----统计坪石口数---- 
  rid := 0;   
OPEN read_run_point_psk;
       LOOP
       FETCH read_run_point_psk INTO runid,zm,sta_d,end_d,id;
       EXIT WHEN read_run_point_psk%NOTFOUND;
        select cc,sfz,zdz into runcc,str_sfz,str_dzd  from run_line where id=runid ;
         --if runid='1181217' then   
         -- dbms_output.put_line(runcc);
         --  end if;
         id :=id + 1;
        select station_name  into nfjkz from run_point  where runline_id = runid and xh = id;--下一站
        select count(*) into id from b_station where station_name = nfjkz AND bureau_code='Q' and ((subbureau_code='63' and station_name<>'九龙') or station_name='广州西');
         if id > 0 then -----下行
            hrq:=sta_d;
            nfjkz :='交出';
         else
            hrq:=end_d;
            nfjkz :='接入';
         end if;
        if  hrq >sta_sj and hrq <= end_sj then ------时间范围内
        select station_name  into str_sfz from run_point  where runline_id = runid and xh = 1;--始发站
        select station_name  into str_dzd from run_point  where runline_id = runid and xh in (select max(xh) from run_point where runline_id = runid);
             rid := rid + 1;
              begin
             insert into dds_start_kc_data values (rqstr,nfjkz,rid,runid,zm,runcc,hrq,str_sfz,str_dzd);
             EXCEPTION 
            WHEN OTHERS THEN 
               ROLLBACK;
             END;
        end if;
      commit; 
  end loop;
  CLOSE read_run_point_psk; 
  
  
----统计出发情况分析-----
ii := 0;
loop 
ii := ii+ 1;
if ii = 1 then 
 sfbz:='始发';
end if;
if ii = 2 then 
 sfbz:='终到';
end if;
if ii = 3 then 
 sfbz:='接入';
end if;
if ii = 4 then 
 sfbz:='交出';
end if;
EXIT WHEN ii > 4 ;
rid := 0;  
kct1 :=0;
kcl1  :=0;
kch1  :=0;
kct2  :=0;
kcl2  :=0;
kch2   :=0;
kct3  :=0;
kcl3   :=0;
kch3   :=0;
kct4  :=0;
kcl4   :=0;
kch4   :=0;
kct5   :=0;
kcl5   :=0;
kch5  :=0;
OPEN read_dds_start_kc_data;
       LOOP
       FETCH read_dds_start_kc_data INTO ZM;
       EXIT WHEN read_dds_start_kc_data%NOTFOUND;
       ----第一阶段
       sta_sj := DAY1||'1800' ;
       end_sj := DAY2||'0000';
        SELECT  count(*) into kct1 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                      cc not like 'A%' and cc not like '0%' and cc not like 'L%' and cc not like 'Y%' and
                      tsj >sta_sj and tsj <= end_sj;
        SELECT  count(*) into kcl1 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                        (cc  like 'A%' or cc  like '0%' or cc  like 'L%' or cc  like 'Y%') and 
                        tsj >sta_sj and tsj <= end_sj ;
           kch1:=kct1+kcl1; 
       -----第二阶段
        sta_sj := DAY2||'0000' ;
        end_sj := DAY2||'0600';
        SELECT  count(*) into kct2 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                      cc not like 'A%' and cc not like '0%' and cc not like 'L%' and cc not like 'Y%' and 
                      tsj >sta_sj and tsj <=end_sj;
        SELECT  count(*) into kcl2 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                        (cc  like 'A%' or cc  like '0%' or cc  like 'L%' or cc  like 'Y%') AND
                        tsj >sta_sj and tsj <=end_sj;
           kch2:=kct2+kcl2;    
       ------第三阶段
       sta_sj := DAY2||'0600' ;
       end_sj := DAY2||'1200';
        SELECT  count(*) into kct3 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                      cc not like 'A%' and cc not like '0%' and cc not like 'L%' and cc not like 'Y%' AND
                      tsj >sta_sj and tsj <=end_sj;
        SELECT  count(*) into kcl3 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                        (cc  like 'A%' or cc  like '0%' or cc  like 'L%' or cc  like 'Y%') AND 
                        tsj >sta_sj and tsj <=end_sj;
           kch3:=kct3+kcl3;     
         ---第四阶段
         sta_sj := DAY2||'1200' ;
         end_sj := DAY2||'1800';
        SELECT  count(*) into kct4 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                      cc not like 'A%' and cc not like '0%' and cc not like 'L%' and cc not like 'Y%' AND 
                        tsj >sta_sj and tsj <=end_sj;
        SELECT  count(*) into kcl4 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                        (cc  like 'A%' or cc  like '0%' or cc  like 'L%' or cc  like 'Y%') AND 
                        tsj >sta_sj and tsj <=end_sj;
         kch4:=kct4+kcl4; 
         
         kct5:=kct1+kct2+kct3+kct4;
         kcl5:=kcl1+kcl2+kcl3+kcl4;
         kch5:=kch1+kch2+kch3+kch4;              
             rid := rid + 1;
             insert into dds_start_kc_tj values (rqstr,sfbz,rid,zm,kct1,kcl1,kch1,kct2,kcl2,kch2,kct3,kcl3,kch3,kct4,kcl4,kch4,kct5,kcl5,kch5,1);
        
      commit; 
  end loop;
CLOSE read_dds_start_kc_data;
end loop;

----统计出发情况分析(按调度所统计)-----
ii := 0;
loop 
ii := ii+ 1;
if ii = 1 then 
 sfbz:='始发';
end if;
if ii = 2 then 
 sfbz:='终到';
end if;
if ii = 3 then 
 sfbz:='接入';
end if;
if ii = 4 then 
 sfbz:='交出';
end if;
EXIT WHEN ii > 4 ;
rid := 0;  
kct1 :=0;
kct2 :=0;
kct3 :=0;
kct4 :=0;
kct5 :=0;

OPEN read_dds_start_kc_data;
       LOOP
       FETCH read_dds_start_kc_data INTO ZM;
       EXIT WHEN read_dds_start_kc_data%NOTFOUND;
       sta_sj := DAY1||'1800' ;
       end_sj := DAY2||'1800';
       ----图定客车
        SELECT  count(*) into kct1 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                      cc not like 'A%' and cc not like '0%' and cc not like 'L%' and cc not like 'Y%' and
                      tsj >sta_sj and tsj <= end_sj;
        -----临客-----
        SELECT  count(*) into kct2 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                        (cc  like 'A%'  or cc  like 'L%' or cc  like 'Y%') and  cc not like '0%' and
                        tsj >sta_sj and tsj <= end_sj ;
          ------车底----------            
         SELECT  count(*) into kct3 FROM dds_start_kc_data WHERE rq=rqstr and ren=sfbz and station=zm and 
                         cc  like '0%'  and   tsj >sta_sj and tsj <= end_sj ;              
                     
             kct4:=kct1+kct2+kct3;         
             rid := rid + 1;
             insert into dds_start_kc_tj_zlw values (rqstr,sfbz,rid,zm,kct1,kct2,kct3,kct4,kct5);
        
      commit; 
  end loop;
CLOSE read_dds_start_kc_data;
end loop;



commit;
end sunday_rbjh_fjk_ycbak20090131;
/

