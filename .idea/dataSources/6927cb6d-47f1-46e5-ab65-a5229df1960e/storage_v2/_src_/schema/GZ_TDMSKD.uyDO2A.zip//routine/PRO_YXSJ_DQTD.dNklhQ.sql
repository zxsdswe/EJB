create procedure PRO_YXSJ_DQTD is
  /*本存储过程用于从T/D结合数据库xd_train_tt表中采集始发、接入、交出、终到站的图定时间，填写到客调车次字典库YXSJ_LJZD_CC表中*/

  v_has1 number(1) := 0; /*临时变量，用以判断分界口是否为本局管辖*/
  v_sfsj number(6, 2); /*始发时间*/
  v_jrsj number(6, 2); /*接入时间*/
  v_jcsj number(6, 2); /*交出时间*/
  v_zdsj number(6, 2); /*终到时间*/

  /*定义游标1——d: 遍历车次字典表YXSJ_LJZD_CC ---start*/
  cursor d is
    select LJ_JC,
           LJDM,
           LCLX,
           LCLX_XH,
           CC,
           QCC,
           LJ_XH,
           YXFS,
           nvl(SF_ZM, '0') sf_zm,
           nvl(JR_ZM, '0') jr_zm,
           JR_TS,
           nvl(JC_ZM, '0') jc_zm,
           JC_TS,
           nvl(ZD_ZM, '0') zd_zm,
           ZD_TS
      from YXSJ_LJZD_CC;
  d_rec d%rowtype;
  /*定义游标1——d: 遍历车次字典表YXSJ_LJZD_CC ---end*/
  errormessage exception;

  /*开始取数*/
begin

  /*从xd_train_tt表取出最近4天的数插入临时表yxsj_xd_traintt---start*/
  insert into yxsj_xd_traintt
    select ID, node, ddsj, cfsj, ddcc, cfcc, tdddsj, tdcfsj
      from xd_train_tt
     where (dfd_falg = 3 or (node = '茂名' and (dfd_falg=1 or dfd_falg=2)))
       and tdddsj >=
           to_date(to_char(sysdate, 'yyyy-mm-dd'), 'yyyy-mm-dd HH24:MI:SS') - 4;
  /*从xd_train_tt表取出最近4天的数插入临时表yxsj_xd_traintt---end*/

  open d;

  /*第一步：循环遍历车次字典表YXSJ_LJZD_CC*/
  loop
    fetch d
      into d_rec;
    exit when d%notfound;

    /*类型1-----终到*/
    if (((d_rec.yxfs = '始发终到') or (d_rec.yxfs = '接入终到')) and
       (d_rec.zd_zm != '0')) then

      select to_char(max(tdddsj), 'hh24.mi')
        into v_zdsj
        from yxsj_xd_traintt
       where instr('-' || d_rec.qcc, '-' || ddcc || '-') > 0
         and trim(node) = trim(d_rec.zd_zm);

      if not v_zdsj is null then
        update yxsj_ljzd_cc set zd_td = v_zdsj where cc = d_rec.cc;
      end if;
      /*      end if;*/
    end if;

    /*类型2-----始发*/
    if (((d_rec.yxfs = '始发终到') or (d_rec.yxfs = '始发交出')) and
       (d_rec.sf_zm != '0')) then

      select to_char(max(tdcfsj), 'hh24.mi')
        into v_sfsj
        from yxsj_xd_traintt
       where instr('-' || d_rec.qcc, '-' || cfcc || '-') > 0
         and trim(node) = trim(d_rec.sf_zm);

      if not v_sfsj is null then
        update yxsj_ljzd_cc set sf_td = v_sfsj where cc = d_rec.cc;
      end if;
    end if;

    /*类型3-----接入*/
    if (((d_rec.yxfs = '接入终到') or (d_rec.yxfs = '接入交出')) and
       (d_rec.jr_zm != '0')) then
      /*判断接入站是否为本局管辖，本局管则接入取到达时间，邻局管则接入取出发时间*/
      /*3.1 接入站为本局管辖*/
      v_has1 := 0;
      select count(*)
        into v_has1
        from v_yxsj_ljzdfjk1
       where trim(fjk_name) = trim(d_rec.jr_zm);
      if (v_has1 > 0) then
        /*接入站为本局管辖*/

        select to_char(max(tdddsj), 'hh24.mi')
          into v_jrsj
          from yxsj_xd_traintt
         where instr('-' || d_rec.qcc, '-' || ddcc || '-') > 0
           and trim(node) = trim(d_rec.jr_zm);

        if not v_jrsj is null then
          update yxsj_ljzd_cc set jr_td = v_jrsj where cc = d_rec.cc;
        end if;
      end if;
      /*3.2 接入站为邻局管辖*/
      v_has1 := 0;
      select count(*)
        into v_has1
        from v_yxsj_ljzdfjk2
       where trim(fjk_name) = trim(d_rec.jr_zm);
      if (v_has1 > 0) then
        /*说明接入站为邻局管辖*/

        select to_char(max(tdcfsj), 'hh24.mi')
          into v_jrsj
          from yxsj_xd_traintt
         where instr('-' || d_rec.qcc, '-' || cfcc || '-') > 0
           and trim(node) = trim(d_rec.jr_zm);

        if not v_jrsj is null then
          update yxsj_ljzd_cc set jr_td = v_jrsj where cc = d_rec.cc;
        end if;
      end if;
    end if;

    /*类型4-----交出*/
    if (((d_rec.yxfs = '始发交出') or (d_rec.yxfs = '接入交出')) and
       (d_rec.jc_zm != '0')) then
      /*判断交出站是否为本局管辖，本局管则交出取出发时间，邻局管则交出取到达时间*/
      /*4.1 交出站为本局管辖*/
      v_has1 := 0;
      select count(*)
        into v_has1
        from v_yxsj_ljzdfjk1
       where trim(fjk_name) = trim(d_rec.jc_zm);
      if (v_has1 > 0) then
        /*交出站为本局管辖*/

        select to_char(max(tdcfsj), 'hh24.mi')
          into v_jcsj
          from yxsj_xd_traintt
         where instr('-' || d_rec.qcc, '-' || cfcc || '-') > 0
           and trim(node) = trim(d_rec.jc_zm);
        if not v_jcsj is null then
          update yxsj_ljzd_cc set jc_td = v_jcsj where cc = d_rec.cc;
        end if;
      end if;

      /*4.2 交出站为邻局管辖*/
      v_has1 := 0;
      select count(*)
        into v_has1
        from v_yxsj_ljzdfjk2
       where trim(fjk_name) = trim(d_rec.jc_zm);
      if (v_has1 > 0) then
        /*交出站为邻局管辖*/

        select to_char(max(tdddsj), 'hh24.mi')
          into v_jcsj
          from yxsj_xd_traintt
         where instr('-' || d_rec.qcc, '-' || ddcc || '-') > 0
           and trim(node) = trim(d_rec.jc_zm);
        if not v_jcsj is null then
          update yxsj_ljzd_cc set jc_td = v_jcsj where cc = d_rec.cc;
        end if;
      end if;
    end if;
    commit;
  end loop;
  close d;

/*删除临时表yxsj_xd_traintt里的数据---start*/
  execute immediate 'truncate table yxsj_xd_traintt';
/*删除临时表yxsj_xd_traintt里的数据---end*/

  /*向表 YXSJ_QSBS_SJ 中填写取数时间---start*/
  insert into YXSJ_QSBS_SJ
  values
    (SEQ_YXSJ_QSBS_SJ.nextval,
     (select lj_jc from yxsj_ljzd_jm),
     (select ljdm from yxsj_ljzd_jm),
     '读取图定',
     sysdate,
     Trunc(sysdate));
  commit;
  /*向表 YXSJ_QSBS_SJ 中填写取数时间---end*/

  /* 异常处理,提示错误信息*/
exception
  when errormessage then
    dbms_output.put_line('没找到');
end PRO_YXSJ_DQTD;
/

