create procedure hyc_srbb_pro_1(rq in varchar2, dwmc in  varchar2,dwdbm varchar2,xh varchar2,njh number,nrj number,dlnjh number,fjs number) is
zcs1  number(15);
zcs2   number(15);
zcs3   number(15);
zcs4   number(15);
zcs5   number(15);
zcs6   number(15);
zcs7   number(15);
zcs8   number(15);
zcs9   number(15);
zcs10   number(15,2);
zcs11   number(15,2);
zcs12   number(15,2);
zcs13   number(15,2);
zcs14   number(15,2);
zcs15   number(15,2);
zcs16   number(15,2);

tmp1    number(15);
tmp2    number(15);
tmp3     number(15);
ts      number(15);
ts1     number(15);
nts     number(15);
nts1    number(15);
y varchar2(10);
m varchar2(10);
d varchar2(10);
y1 varchar2(10);  --同比日期
m1 varchar2(10);
d1 varchar2(10);
y2 varchar2(10);   --环比日期
m2 varchar2(10);
d2 varchar2(10);
rq_m varchar2(2);   --货票月份替换
sql_tmp varchar2(1000);
czm  varchar2(10);
dbm  varchar2(10);
unit  varchar2(10);
id varchar2(10);
mc  varchar2(30);

begin
  y:=substr(rq,1,4);
 m:=substr(rq,5,2);
 d:=substr(rq,7,2);
 y1:=to_char(to_number(y)-1);
 --y1:='2013';
 m1:=m;
 d1:=d;
 y2:=y;
 m2:=to_char(to_number(m)-1);
 if length(m2)=1 then 
   m2:='0'||m2;
 end if;
 d2:=d;
 if m='01' then   --如果当前日期为1月则为去年12月
   m2:='12';
   y2:=y1;
 end if;
 if d='31' then 
   d2:=to_char(last_day(to_date(y2||m2,'yyyymm')),'dd') ;
   --d2:='30';
 end if;
 select to_char(last_day(to_date(rq,'yyyymmdd')),'dd') into ts from dual; --获取本月天数
 ts1:=ts;
 --判断是否润年
 select to_char(last_day(to_date(y||'0201','yyyymmdd')),'dd') into nts from dual; --获取2月天数
 if nts=29 then 
     nts:=366;  --润年
   else
     nts:=365;  --非润年
 end if;
 select to_char(last_day(to_date(y1||'0201','yyyymmdd')),'dd') into nts1 from dual; --获取2月天数
 if nts1=29 then 
     nts1:=366;  --润年
   else
     nts1:=365;  --非润年
  end if;
  --判断是否润年 end
 if m||d='0229' then 
   d1:='28';
   ts1:=28;
   d2:='28';
 end if; 

 
 --开始计算前十项指标
 zcs1:=njh;
 zcs2:=nrj;
 select round((entry023)/10000,0) into zcs3 from data_date@jt18d t where t.report_name='CBZ' and t.unit=dwdbm and t.d18_date=y||m||d;
 zcs4:=zcs3-zcs2;
 select  round(sum(entry023)/10000,0)  into zcs5 from data_date@jt18d t where t.report_name='CBZ' and t.unit=dwdbm and t.d18_date>=y||m||'01' and  t.d18_date<=y||m||d;
 select  round(sum(entry023)/10000,0)  into zcs6 from data_date@jt18d t where t.report_name='CBZ' and t.unit=dwdbm and t.d18_date>=y1||m1||'01' and  t.d18_date<=y1||m1||d1;
 zcs6:=zcs5-zcs6;  --今年减去去年
 --计算今年累计
 select sum(entry023)  into tmp1 from data_date@jt18d t where t.report_name='CBZ' and t.unit=dwdbm and t.d18_date like 'JD'||y||'%' and  t.d18_date<'JD'||y||m;
 select max(d18_date)  into sql_tmp from data_date@jt18d t where t.report_name='CBZ' and t.unit=dwdbm and t.d18_date like 'JD'||y||'%' and  t.d18_date<'JD'||y||m order by  d18_date desc;
 sql_tmp:=substr(sql_tmp,7,2);
 tmp3:=to_number(sql_tmp)+1;
 sql_tmp:=to_char(tmp3);
 if length(sql_tmp)=1 then 
    sql_tmp:='0'||sql_tmp;
 end if;
 select sum(entry023)  into tmp2 from data_date@jt18d t where t.report_name='CBZ' and t.unit=dwdbm and t.d18_date>=y||sql_tmp||'01' and    t.d18_date<=y||m||d;
 zcs7:= round((tmp1+tmp2)/10000,0);
 --计算去年累计
 select sum(entry023)  into tmp1 from data_date@jt18d t where t.report_name='CBZ' and t.unit=dwdbm and t.d18_date like 'JD'||y1||'%' and  t.d18_date<'JD'||y1||m1;
 select max(d18_date)  into sql_tmp from data_date@jt18d t where t.report_name='CBZ' and t.unit=dwdbm and t.d18_date like 'JD'||y1||'%' and  t.d18_date<'JD'||y1||m1 order by  d18_date desc;
 sql_tmp:=substr(sql_tmp,7,2);
 tmp3:=to_number(sql_tmp)+1;
 sql_tmp:=to_char(tmp3);
 if length(sql_tmp)=1 then 
    sql_tmp:='0'||sql_tmp;
 end if;
 select sum(entry023)  into tmp2 from data_date@jt18d t where t.report_name='CBZ' and t.unit=dwdbm and t.d18_date>=y1||sql_tmp||'01' and    t.d18_date<=y1||m1||d1;
 zcs8:=zcs7- round((tmp1+tmp2)/10000,0);   --年累计今年减去去年
 zcs9:=zcs7-round(zcs1/nts*((to_date(y||m||d,'yyyymmdd')-to_date( y||'01'||'01','yyyymmdd')+1)),0);
 zcs10:=round(zcs7/(zcs2*(to_date(y||m||d,'yyyymmdd')-to_date( y||'01'||'01','yyyymmdd')+1))*100,3);
 --结束前十项指标计算
 --开始计算堵漏保收指标
 zcs11:=dlnjh;
 
 select round((entry019)/10000,1) into zcs12 from data_date@jt18d t where t.report_name='CBDL' and t.unit=dwdbm and t.d18_date=y||m||d;
 zcs13:=zcs12-round(zcs11/nts,1);
 select  round(sum(entry019)/10000,1)  into zcs14 from data_date@jt18d t where t.report_name='CBDL' and t.unit=dwdbm and t.d18_date>=y||m||'01' and  t.d18_date<=y||m||d;

 --计算今年累计
 select sum(entry019)  into tmp1 from data_date@jt18d t where t.report_name='CBDL' and t.unit=dwdbm and t.d18_date like 'JD'||y||'%' and  t.d18_date<'JD'||y||m  and  t.d18_date>='JD201505';
 select max(d18_date)  into sql_tmp from data_date@jt18d t where t.report_name='CBDL' and t.unit=dwdbm and t.d18_date like 'JD'||y||'%' and  t.d18_date<'JD'||y||m  and  t.d18_date>='JD201505' order by  d18_date desc;
 sql_tmp:=substr(sql_tmp,7,2);
 tmp3:=to_number(sql_tmp)+1;
 sql_tmp:=to_char(tmp3);
 if length(sql_tmp)=1 then 
    sql_tmp:='0'||sql_tmp;
 end if;
 select sum(entry019)  into tmp2 from data_date@jt18d t where t.report_name='CBDL' and t.unit=dwdbm and t.d18_date>=y||sql_tmp||'01' and    t.d18_date<=y||m||d  and t.d18_date>='20150501';
 zcs15:= round((tmp1+tmp2)/10000,1)+fjs;
 zcs16:=zcs15-round(zcs11/nts*((to_date(y||m||d,'yyyymmdd')-to_date( y||'01'||'01','yyyymmdd')+1)),1);
 --zcs10:=round(zcs7/(zcs2*(to_date(y||m||d,'yyyymmdd')-to_date( y||'01'||'01','yyyymmdd')+1))*100,3);
 
 
 --结束堵漏保收指标
 --insert into  hyc_srbb_1 (rq,id,mc,sj1,sj2,sj3,sj4,sj5,sj6,sj7,sj8,sj9,sj10,sj11,sj12,sj13,sj14,sj15,sj16)  values  (rq,xh,dwmc,zcs1,zcs2,zcs3,zcs4,zcs5,zcs6,zcs7,zcs8,zcs9,zcs10,zcs11,zcs12,zcs13,zcs14,zcs15,zcs16);
 --commit;
 --end  
 
  
end hyc_srbb_pro_1;
/

