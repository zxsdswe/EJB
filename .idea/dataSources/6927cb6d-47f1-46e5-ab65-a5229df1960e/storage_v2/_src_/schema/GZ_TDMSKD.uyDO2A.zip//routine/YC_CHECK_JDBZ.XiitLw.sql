create procedure yc_check_jdbz(jbtid  varchar2  ) is

hjc1 varchar2(30);
hsj1 varchar2(30);
cc  varchar2(30);
czm  varchar2(30);
cc1  varchar2(30);
czm1  varchar2(30);
hjc varchar2(30);
hsj varchar2(30);
id varchar2(30);
zx varchar2(30);
cs number(3);
 


CURSOR check_cc  IS  select  base_line_id,train_num1 from  dic_base_lineBAK  where    chartid=jbtid and train_kind<9  and ( train_num1 not like 'G%' and   train_num1 not like 'D%' and   train_num1 not like 'C%'  and   train_num1 not like 'X%') order by  base_line_id desc  ; 
CURSOR check_bz  IS  select  b.stn,b.node_order,b.change_driver,b.change_loco from dic_base_line_nodeBAK b where base_line_id=id  and (change_driver<>'0' or change_loco<>'0'）  order by node_order;

begin
  OPEN check_cc;
   LOOP
      FETCH check_cc INTO id,cc;
      EXIT WHEN check_cc%NOTFOUND; 
         OPEN check_bz;
           dbms_output.put_line(cc);
         LOOP
            FETCH check_bz INTO czm,zx,hsj,hjc;
            EXIT WHEN check_bz%NOTFOUND;  
             if hsj='1'  and hjc='0' then   
                   select count(*) into cs from train_schedule where train_id in (select train_id from train_info where  base_id=id  and plan='2018春运普铁节前' ) and sta_name=czm  and sta_type like '%5%';
                   if cs<1 then
                      insert into yc_log (plan1,cc1,czm1,log) values(id,cc,czm,cc||'次在'||czm||'站找不到换司机标志！');
                      commit;
                   end if;
             end if;
           
            if hsj='1'  and hjc='1' then 
                  select count(*) into cs from train_schedule where   train_id in (select train_id from train_info where  base_id=id and plan='2018春运普铁节前')  and sta_name=czm  and sta_type like '%3%';
                   if cs<1 then
                      insert into yc_log (plan1,cc1,czm1,log) values(id,cc,czm,cc||'次在'||czm||'站找不到换机车标志！');
                      commit;
                   end if;
            end if;
           
           
           /* if zx='0' then 
                   hjc1:=hjc;
                   hsj1:=hsj;
                 
               else
                 
                 if hsj1<>hsj and hjc1=hjc  then --换司机标志
                   select count(*) into cs from train_schedule where train_id in (select train_id from train_info where  base_id=id) and sta_name=czm  and sta_type like '%5%';
                   if cs<1 then
                      insert into yc_log (plan1,cc1,czm1,log) values(id,cc,czm,cc||'次在'||czm||'站找不到换司机标志！');
                      commit;
                   end if;
                 end if;
              
                 if hjc1<>hjc or jx1<>jx   then --换机车标志
                   select count(*) into cs from train_schedule where train_id in (select train_id from train_info where  base_id=id) and sta_name=czm  and sta_type like '%3%';
                   if cs<1 then
                      insert into yc_log (plan1,cc1,czm1,log) values(id,cc,czm,cc||'次在'||czm||'站找不到换机车标志！');
                      commit;
                   end if;
                 end if;
                 
               end if;
               hjc1:=hjc;
               hsj1:=hsj;
               czm1:=czm;
               jx1:=jx;
               */
        end loop; 
        close check_bz; 
      
      end loop; 
     close check_cc;    --关闭游标
  
end yc_check_jdbz;
/

