create procedure KCBZ_APPLICATION_FORM_RESET as n number(10);
tsql  varchar2(100);
begin
  execute immediate 'select kcbz_application_form_s.nextval from dual' into n;
  n:=-(n);
  tsql:='alter sequence kcbz_application_form_s increment by '|| n;
  execute immediate tsql;
 execute immediate 'select kcbz_application_form_s.nextval from dual' into n;
  tsql:='alter sequence kcbz_application_form_s increment by 1';
 execute immediate tsql;
end KCBZ_APPLICATION_FORM_RESET;
/

