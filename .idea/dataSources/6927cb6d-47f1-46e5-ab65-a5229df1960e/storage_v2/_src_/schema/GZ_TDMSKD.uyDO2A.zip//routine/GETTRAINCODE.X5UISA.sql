create FUNCTION GETTRAINCODE (Train_id in
    Varchar2) return varchar2 is
  Result varchar2(4);
  v_train_code Varchar2(4);
  v_count number(1);
begin
  v_train_code := substr(train_id,3,4);
    for v_count in 1..4 loop
       if substr(v_train_code,1,1) ='0' then
          v_train_code := substr(v_train_code,2);
       end if;
    end loop;
    result:=v_train_code;
  return(Result);
end GetTrainCode;
/

