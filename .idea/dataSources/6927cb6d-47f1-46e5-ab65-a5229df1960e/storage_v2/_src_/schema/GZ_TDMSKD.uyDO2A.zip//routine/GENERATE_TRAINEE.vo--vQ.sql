create PROCEDURE GENERATE_TRAINEE
IS
	CURSOR j_plan IS 
    	SELECT * FROM army_start_Plan ORDER BY jyh;
	cPlan J_PLAN%ROWTYPE;
	trainDate VARCHAR2(20);
	traineeID NUMBER(10);
	endStation VARCHAR2(20);
	
	CURSOR J_PASS(tNum VARCHAR,tDate DATE) IS 
		SELECT QJ,ZY,FJU,DJU FROM ARMY_PASSENGER_USE WHERE CHE=tNum AND DAT=tDate;
	
	station VARCHAR2(40);
	seatUseType VARCHAR2(40);
	tmpIDx NUMBER;
	fBur VARCHAR2(40);
	tBur VARCHAR2(40);
	
	CURSOR J_Trainee IS
		SELECT * FROM MARTIAL_TRAINEE FOR UPDATE;
	trainee J_Trainee%ROWTYPE;
BEGIN
	DELETE MARTIAL_TRAINEE;
	OPEN J_PLAN;
	traineeId := 1;	
	LOOP 
		FETCH J_PLAN INTO cPlan;
		EXIT WHEN J_PLAN%NOTFOUND;
		IF cPlan.LJM_0 = '广州' THEN	
			IF cPlan.LJM_1 IS NULL OR cPlan.LJM_1 = '' THEN
				endStation := cPlan.ZDZ_4;
			ELSE
				endStation := cPlan.ZZZ_1;
			END IF;
			INSERT INTO MARTIAL_TRAINEE VALUES(traineeId, cPlan.FDAT_0, cPlan.FCHE_0,'',
					cPlan.SCZ_0,endStation,cPlan.JYH,cPlan.HJ,cPlan.bz,10);
			traineeId := traineeID + 1;
		END IF;
		IF cPlan.LJM_1 = '广州' THEN	
			IF cPlan.LJM_2 IS NULL OR cPlan.LJM_2 = '' THEN
				endStation := cPlan.ZDZ_4;
			ELSE
				endStation := cPlan.ZZZ_2;
			END IF;
			INSERT INTO MARTIAL_TRAINEE VALUES(traineeId, cPlan.FDAT_1, cPlan.FCHE_1,'',
					cPlan.ZZZ_1,endStation,cPlan.JYH,cPlan.HJ,cPlan.bz,10);
			traineeId := traineeID + 1;
		END IF;
		IF cPlan.LJM_2 = '广州' THEN
			IF cPlan.LJM_3 IS NULL OR cPlan.LJM_3 = '' THEN
				endStation := cPlan.ZDZ_4;
			ELSE
				endStation := cPlan.ZZZ_3;
			END IF;
			INSERT INTO MARTIAL_TRAINEE VALUES(traineeId, cPlan.FDAT_2, cPlan.FCHE_2,'',
					cPlan.ZZZ_2,endStation,cPlan.JYH,cPlan.HJ,cPlan.bz,10);
			traineeId := traineeID + 1;
		END IF;
		IF cPlan.LJM_3 = '广州' THEN	
			endStation := cPlan.ZDZ_4;
			INSERT INTO MARTIAL_TRAINEE VALUES(traineeId, cPlan.FDAT_3, cPlan.FCHE_3,'',
					cPlan.ZZZ_3,endStation,cPlan.JYH,cPlan.HJ,cPlan.bz,10);
			traineeId := traineeID + 1;
		END IF;
	END LOOP;
	CLOSE J_PLAN;
	
	OPEN J_TRAINEE;
	LOOP
		FETCH J_TRAINEE INTO trainee;
		EXIT WHEN J_TRAINEE%NOTFOUND;
		
		OPEN J_PASS(trainee.TRAINNUM, trainee.STARTTIME);
		FETCH J_PASS INTO station,seatUseType,fBur,tBur;
		IF J_PASS%FOUND THEN
			tmpIDX := INSTR(station,'→')-1;
			station := SUBSTR(station,0,tmpIdx);
			tmpIDX := 10;
			IF fBur = tBur THEN
				IF seatUseType = '留座' THEN 
					tmpIDX := 4;
				ELSE
					tmpIDX := 2;
				END IF;
			ELSE 
				IF seatUseType = '留座' THEN 
					tmpIDX := 3;
				ELSE
					tmpIDX := 1;
				END IF;			
			END IF;
			UPDATE MARTIAL_TRAINEE SET FIRSTSTATION = station, seatUseType = tmpIDX WHERE CURRENT OF J_TRAINEE;
		END IF;
		CLOSE J_PASS;
	END LOOP;
	CLOSE J_TRAINEE;
	
	COMMIT;
END;
/

