create view C_CC as
  (Select a.train_id,a.train_no,b.sta_name FZ,b.arrive_time,c.sta_name DZ,c.start_time From train_info a,train_schedule b,train_schedule c
Where a.train_id=b.train_id And a.train_id=c.train_id And a.begin_sta_name=b.sta_name And a.end_sta_name=c.sta_name)
/

