create view V_KDMLJB as
  select distinct mlrq,rq,mlh,mlxh from k_kdjhb union select distinct mlrq,rq,mlh,mlxh from k_jjkclcrb
/

