create procedure hyc_srbb_pro_2(rq in varchar2) is
a1 varchar2(30);
a2 varchar2(30);
a3 varchar2(30);
a4 number(10);
a5 number(10);
a6 number(10);
a7 number(10,1);


CURSOR srbb  IS  select dbm,unit,xh,njh12,nrj1,dlnjh1,dlljs from HYC_SCBB_2 t order by to_number(xh);

begin
--delete  from hyc_srbb_1  where  rq=rq;
commit;
OPEN srbb;
   LOOP
      FETCH srbb INTO a1,a2,a3,a4,a5,a6,a7;
      EXIT WHEN srbb%NOTFOUND;
      hyc_srbb_pro_1(rq,a1,a2,a3,a4,a5,a6,a7);

   end loop;
   close srbb;
end hyc_srbb_pro_2;
/

