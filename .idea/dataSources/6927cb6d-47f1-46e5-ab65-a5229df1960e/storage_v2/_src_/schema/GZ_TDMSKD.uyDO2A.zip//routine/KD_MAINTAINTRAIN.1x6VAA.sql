create PROCEDURE        "KD_MAINTAINTRAIN" (
 p_begin_id in number,
 p_train_info_tab in varchar2,
 P_train_schedule_tab in varchar2,
 v_successful out varchar2) IS

 sqlStr varchar2(200);
 type ref_cursor_type is ref cursor;
 c_train_id1 ref_cursor_type;
 c_info1 ref_cursor_type;
 c_max_sort1 ref_cursor_type;
/*定义游标*/
--cursor c_train_id is select train_id,train_kpid from train_info_0705 where train_id >= p_begin_id;


 --cursor c_info(pc_train_id number) is select sta_sort,start_time,STATION_TELECODE,SUBBUREAU_CODE,b.BUREAU_CODE from train_schedule_0705 t,b_station b where t.sta_name = b.station_name and train_id = pc_train_id order by sta_sort;

 --cursor c_max_sort(pc_train_id number) is select max(sta_sort) from train_schedule_0705 where train_id = pc_train_id;

/*定义变量*/
 l_train_id number;
 l_train_kpid varchar2(10);
 l_sta_sort varchar2(2);
 l_start_time varchar2(4);
 li_start_time varchar2(4);
 l_station_telecode varchar2(5);
 l_subbureau_code varchar2(3);
 l_bureau_code varchar2(1);
 l_max_sort varchar2(2);
 l_sta_type2 varchar2(1);
 l_run_days number(1):=0;

BEGIN
sqlStr := 'select train_id,train_kpid from '||p_train_info_tab||' where train_id >='|| p_begin_id;

 open c_train_id1 for sqlStr;
 loop
  fetch c_train_id1 into l_train_id,l_train_kpid;
  exit when c_train_id1%notfound;
  sqlStr := 'select max(sta_sort) from '|| p_train_schedule_tab ||' where train_id = '||l_train_id;
  open c_max_sort1 for sqlStr;
  fetch c_max_sort1 into l_max_sort;
  exit when c_max_sort1%notfound;
  sqlStr:= 'select sta_sort,start_time,STATION_TELECODE,SUBBUREAU_CODE,b.BUREAU_CODE from '|| p_train_schedule_tab || ' t,b_station b where t.sta_name = b.station_name and train_id = '||l_train_id||' order by sta_sort';
  open c_info1 for sqlStr;
  loop
   fetch c_info1 into l_sta_sort,l_start_time,l_station_telecode,l_subbureau_code,l_bureau_code;
   exit when c_info1%notfound;
   if l_sta_sort = '1' then 
      l_run_days := 0;
      l_sta_type2 := '1';
   elsif l_sta_sort != l_max_sort then
     if l_start_time < li_start_time then
       l_run_days := l_run_days+1;
       end if;
       l_sta_type2 := '4';
   elsif l_sta_sort = l_max_sort then
     if l_start_time < li_start_time then
       l_run_days := l_run_days+1;
       end if;
       l_sta_type2 := '2';
     end if; 
  --update train_schedule_0717 set train_kpid =l_train_kpid,sta_code = l_station_telecode,subbur_code = l_subbureau_code,bureau_code = l_bureau_code,run_days = l_run_days,sta_type2 = l_sta_type2 where train_id = l_train_id and sta_sort = l_sta_sort;
  sqlStr:= 'update '||p_train_schedule_tab||' set train_kpid ='''||l_train_kpid||''',sta_code = '''||l_station_telecode||''',subbur_code = '''||l_subbureau_code||''',bureau_code = '''||l_bureau_code||''',run_days = '||l_run_days||',sta_type2 = '''||l_sta_type2||''' where train_id = '||l_train_id||' and sta_sort = '||l_sta_sort;
  execute immediate sqlStr;
  li_start_time := l_start_time;
  end loop;
 close c_info1;
 close c_max_sort1;
 li_start_time := '';
 l_run_days := 0;
 end loop;
 close c_train_id1;
 v_successful := '1';
EXCEPTION
   WHEN OTHERS THEN
   ROLLBACK;
v_successful := '0';
   RETURN;
end kd_maintaintrain;
/

