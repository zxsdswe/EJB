create procedure GET_SBK_TEST (p_rtnstring out varchar2)is
l_train_no varchar2(20);
l_train_qno varchar2(20);
l_sf_station varchar2(20);
l_jr_station varchar2(20);
l_jc_station varchar2(20);
l_zd_station varchar2(20);
flag number(1) := 0;
num number(1) := 0;

cursor c_xh is select cc,qcc,nvl(DW_SF,'1'),nvl(DW_JR,'1'),nvl(DW_JC,'1'),nvl(DW_DD,'1') from kd_dic_ddzwd_test;
begin
 flag := 0;
dbms_output.put_line(flag);
open c_xh;
loop
fetch c_xh into l_train_no,l_train_qno,l_sf_station,l_jr_station,l_jc_station,l_zd_station;
exit when c_xh%notfound;
if l_train_no = 'D203' then
num := 9;
end if;
select count(*) into num from dic_base_line_node_zwd where arr_train_num1 = l_train_no and stn = l_sf_station;
if num > 0 then
update kd_dic_ddzwd_test set TD_SF = (select distinct to_number(replace(dep_time,':','.')) from dic_base_line_node_zwd where base_line_id = (select max(base_line_id) from dic_base_line_node_zwd where arr_train_num1 = l_train_no and stn = l_sf_station) and stn = l_sf_station) where cc = l_train_no and dw_sf = l_sf_station;
flag := flag +1;
end if;
select count(*) into num from dic_base_line_node_zwd where arr_train_num1 = substr(l_train_qno,instr(l_train_qno,'-')+1,instr(l_train_qno,'-')-1) and stn = l_sf_station;
if num > 0 then
update kd_dic_ddzwd_test set TD_SF = (select distinct to_number(replace(dep_time,':','.')) from dic_base_line_node_zwd where base_line_id = (select max(base_line_id) from dic_base_line_node_zwd where arr_train_num1 = substr(l_train_qno,instr(l_train_qno,'-')+1,instr(l_train_qno,'-')-1) and stn = l_sf_station) and stn = l_sf_station) where cc = l_train_no and dw_sf = l_sf_station;
flag := flag +1;
end if;
select count(*) into num from dic_base_line_node_zwd where arr_train_num1 = l_train_no and stn = l_jr_station;
if num > 0 then
if l_jr_station = '株洲' or l_jr_station = '滩头湾' or l_jr_station = '琥市' then
update kd_dic_ddzwd_test set TD_JR = (select distinct to_number(replace(arr_time,':','.')) from dic_base_line_node_zwd where base_line_id = (select max(base_line_id) from dic_base_line_node_zwd where arr_train_num1 = l_train_no and stn = l_jr_station) and stn = l_jr_station) where cc = l_train_no and dw_jr = l_jr_station;
else
update kd_dic_ddzwd_test set TD_JR = (select distinct to_number(replace(dep_time,':','.')) from dic_base_line_node_zwd where base_line_id = (select max(base_line_id) from dic_base_line_node_zwd where arr_train_num1 = l_train_no and stn = l_jr_station) and stn = l_jr_station) where cc = l_train_no and dw_jr = l_jr_station; 
end if;
flag := flag +1;
end if;
select count(*) into num from dic_base_line_node_zwd where arr_train_num1 = substr(l_train_qno,instr(l_train_qno,'-')+1,instr(l_train_qno,'-')-1) and stn = l_jr_station;
if num > 0 then
if l_jr_station = '株洲' or l_jr_station = '滩头湾' or l_jr_station = '琥市' then
update kd_dic_ddzwd_test set TD_JR = (select distinct to_number(replace(arr_time,':','.')) from dic_base_line_node_zwd where base_line_id = (select max(base_line_id) from dic_base_line_node_zwd where arr_train_num1 = substr(l_train_qno,instr(l_train_qno,'-')+1,instr(l_train_qno,'-')-1) and stn = l_jr_station) and stn = l_jr_station) where cc = l_train_no and dw_jr = l_jr_station;
else
update kd_dic_ddzwd_test set TD_JR = (select distinct to_number(replace(dep_time,':','.')) from dic_base_line_node_zwd where base_line_id = (select max(base_line_id) from dic_base_line_node_zwd where arr_train_num1 = substr(l_train_qno,instr(l_train_qno,'-')+1,instr(l_train_qno,'-')-1) and stn = l_jr_station) and stn = l_jr_station) where cc = l_train_no and dw_jr = l_jr_station;
end if;
flag := flag +1;
end if;
select count(*) into num from dic_base_line_node_zwd where arr_train_num1 = l_train_no and stn = l_jc_station;
if num > 0 then
if l_jc_station = '株洲' or l_jc_station = '滩头湾' or l_jc_station = '琥市' then
update kd_dic_ddzwd_test set TD_JC = (select distinct to_number(replace(dep_time,':','.')) from dic_base_line_node_zwd where base_line_id = (select max(base_line_id) from dic_base_line_node_zwd where arr_train_num1 = l_train_no and stn = l_jc_station) and stn = l_jc_station) where cc = l_train_no and dw_jc = l_jc_station;
else
update kd_dic_ddzwd_test set TD_JC = (select distinct to_number(replace(arr_time,':','.')) from dic_base_line_node_zwd where base_line_id = (select max(base_line_id) from dic_base_line_node_zwd where arr_train_num1 = l_train_no and stn = l_jc_station) and stn = l_jc_station) where cc = l_train_no and dw_jc = l_jc_station;
end if;
flag := flag +1;
end if;
select count(*) into num from dic_base_line_node_zwd where arr_train_num1 = substr(l_train_qno,instr(l_train_qno,'-')+1,instr(l_train_qno,'-')-1) and stn = l_jc_station;
if num > 0 then
if l_jc_station = '株洲' or l_jc_station = '滩头湾' or l_jc_station = '琥市' then
update kd_dic_ddzwd_test set TD_JC = (select distinct to_number(replace(dep_time,':','.')) from dic_base_line_node_zwd where base_line_id = (select max(base_line_id) from dic_base_line_node_zwd where arr_train_num1 = substr(l_train_qno,instr(l_train_qno,'-')+1,instr(l_train_qno,'-')-1) and stn = l_jc_station) and stn = l_jc_station) where cc = l_train_no and dw_jc = l_jc_station;
else
update kd_dic_ddzwd_test set TD_JC = (select distinct to_number(replace(arr_time,':','.')) from dic_base_line_node_zwd where base_line_id = (select max(base_line_id) from dic_base_line_node_zwd where arr_train_num1 = substr(l_train_qno,instr(l_train_qno,'-')+1,instr(l_train_qno,'-')-1) and stn = l_jc_station) and stn = l_jc_station) where cc = l_train_no and dw_jc = l_jc_station;
end if;
flag := flag +1;
end if;
select count(*) into num from dic_base_line_node_zwd where arr_train_num1 = l_train_no and stn = l_zd_station;
if num > 0 then
update kd_dic_ddzwd_test set TD_DD = (select distinct to_number(replace(arr_time,':','.')) from dic_base_line_node_zwd where base_line_id = (select max(base_line_id) from dic_base_line_node_zwd where arr_train_num1 = l_train_no and stn = l_zd_station) and stn = l_zd_station) where cc = l_train_no and dw_dd = l_zd_station;
flag := flag +1;
end if;
select count(*) into num from dic_base_line_node_zwd where arr_train_num1 = substr(l_train_qno,instr(l_train_qno,'-')+1,instr(l_train_qno,'-')-1) and stn = l_zd_station;
if num > 0 then
update kd_dic_ddzwd_test set TD_DD = (select distinct to_number(replace(arr_time,':','.')) from dic_base_line_node_zwd where base_line_id = (select max(base_line_id) from dic_base_line_node_zwd where arr_train_num1 = substr(l_train_qno,instr(l_train_qno,'-')+1,instr(l_train_qno,'-')-1) and stn = l_zd_station) and stn = l_zd_station) where cc = l_train_no and dw_dd = l_zd_station;
flag := flag +1;
end if;
if flag != 2 then
 p_rtnstring:=p_rtnstring||l_train_no||'成功!';
end if;
flag :=0;
end loop;
commit;
EXCEPTION
   WHEN OTHERS THEN
    p_rtnstring:=l_train_no||'失败!'||chr(10)||'<br>';
   ROLLBACK; 
end GET_SBK_TEST;
/

