create procedure PRO_YXSJ_JSWD(yxfs   in yxsj_ljlcyxmx.yxfs%type,
                                          sf_wd  in yxsj_ljlcyxmx.sf_wd%type,
                                          jr_wd  in yxsj_ljlcyxmx.jr_wd%type,
                                          jc_wd  in yxsj_ljlcyxmx.jc_wd%type,
                                          zd_wd  in yxsj_ljlcyxmx.zd_wd%type,
                                          zwsj   out yxsj_ljlcyxmx.zwsj%type,
                                          gdsj   out yxsj_ljlcyxmx.gdsj%type,
                                          v_sfwd out yxsj_ljlcyxmx.sf_wd%type,
                                          v_jrwd out yxsj_ljlcyxmx.jr_wd%type,
                                          v_jcwd out yxsj_ljlcyxmx.jc_wd%type,
                                          v_zdwd out yxsj_ljlcyxmx.zd_wd%type) is

begin
  /* 一、始发交出：1 ---------发正交正*/
  if (yxfs = '始发交出') then
    if (sf_wd = 0 and jc_wd = 0) then
      v_sfwd := sf_wd;
      v_jcwd := jc_wd;
      zwsj   := 0;
      gdsj   := 0;
    end if;
    /* 2 ---------发正交早*/
    if (sf_wd = 0 and jc_wd < 0) then
      v_sfwd := sf_wd;
      v_jcwd := 0;
      zwsj   := 0;
      gdsj   := 0;
    end if;
    /* 3 ---------发正交晚*/
    if (sf_wd = 0 and jc_wd > 0) then
      v_sfwd := sf_wd;
      v_jcwd := jc_wd;
      zwsj   := jc_wd;
      gdsj   := 0;
    end if;
    /* 4---------发早交正*/
    if (sf_wd < 0 and jc_wd = 0) then
      v_sfwd := -sf_wd;
      v_jcwd := jc_wd;
      zwsj   := 0;
      gdsj   := 0;
    end if;
    /* 5---------发早交早*/
    if (sf_wd < 0 and jc_wd < 0) then
      v_sfwd := -sf_wd;
      v_jcwd := 0;
      zwsj   := 0;
      gdsj   := 0;
    end if;
    /* 6---------发早交晚*/
    if (sf_wd < 0 and jc_wd > 0) then
      v_sfwd := -sf_wd;
      v_jcwd := jc_wd;
      zwsj   := jc_wd;
      gdsj   := 0;
    end if;
    /* 7---------发晚交正*/
    if (sf_wd > 0 and jc_wd = 0) then
      v_sfwd := sf_wd;
      v_jcwd := jc_wd;
      zwsj   := 0;
      gdsj   := sf_wd;
    end if;
    /* 8---------发晚交早*/
    if (sf_wd > 0 and jc_wd < 0) then
      v_sfwd := sf_wd;
      v_jcwd := 0;
      zwsj   := 0;
      gdsj   := sf_wd;
    end if;
    /* 9--------发晚交晚*/
    if (sf_wd > 0 and jc_wd > 0) then
      if (sf_wd >= jc_wd) then
        zwsj := 0;
        gdsj := floor(((floor(sf_wd) * 60 + mod(sf_wd, 1) * 100) -
                      (floor(jc_wd) * 60 + mod(jc_wd, 1) * 100)) / 60) +
                mod(((floor(sf_wd) * 60 + mod(sf_wd, 1) * 100) -
                    (floor(jc_wd) * 60 + mod(jc_wd, 1) * 100)),
                    60) * 0.01;
      else
        zwsj := floor(((floor(jc_wd) * 60 + mod(jc_wd, 1) * 100) -
                      (floor(sf_wd) * 60 + mod(sf_wd, 1) * 100)) / 60) +
                mod(((floor(jc_wd) * 60 + mod(jc_wd, 1) * 100) -
                    (floor(sf_wd) * 60 + mod(sf_wd, 1) * 100)),
                    60) * 0.01;
        gdsj := 0;
      end if;
      v_sfwd := sf_wd;
      v_jcwd := jc_wd;
    end if;
  end if;

  /* 二、接入交出：1 ---------接正交正*/
  if (yxfs = '接入交出') then
    if (jr_wd = 0 and jc_wd = 0) then
      v_jrwd := jr_wd;
      v_jcwd := jc_wd;
      zwsj   := 0;
      gdsj   := 0;
    end if;
    /* 2 ---------接正交早*/
    if (jr_wd = 0 and jc_wd < 0) then
      v_jrwd := jr_wd;
      v_jcwd := 0;
      zwsj   := 0;
      gdsj   := 0;
    end if;
    /* 3 ---------接正交晚*/
    if (jr_wd = 0 and jc_wd > 0) then
      v_jrwd := jr_wd;
      v_jcwd := jc_wd;
      zwsj   := jc_wd;
      gdsj   := 0;
    end if;
    /* 4---------接早交正*/
    if (jr_wd < 0 and jc_wd = 0) then
      v_jrwd := 0;
      v_jcwd := jc_wd;
      zwsj   := 0;
      gdsj   := 0;
    end if;
    /* 5---------接早交早*/
    if (jr_wd < 0 and jc_wd < 0) then
      v_jrwd := 0;
      v_jcwd := 0;
      zwsj   := 0;
      gdsj   := 0;
    end if;
    /* 6---------接早交晚*/
    if (jr_wd < 0 and jc_wd > 0) then
      v_jrwd := 0;
      v_jcwd := jc_wd;
      zwsj   := jc_wd;
      gdsj   := 0;
    end if;
    /* 7---------接晚交正*/
    if (jr_wd > 0 and jc_wd = 0) then
      v_jrwd := jr_wd;
      v_jcwd := jc_wd;
      zwsj   := 0;
      gdsj   := jr_wd;
    end if;
    /* 8---------接晚交早*/
    if (jr_wd > 0 and jc_wd < 0) then
      v_jrwd := jr_wd;
      v_jcwd := 0;
      zwsj   := 0;
      gdsj   := jr_wd;
    end if;
    /* 9--------接晚交晚*/
    if (jr_wd > 0 and jc_wd > 0) then
      if (jr_wd >= jc_wd) then
        zwsj := 0;
        gdsj := floor(((floor(jr_wd) * 60 + mod(jr_wd, 1) * 100) -
                      (floor(jc_wd) * 60 + mod(jc_wd, 1) * 100)) / 60) +
                mod(((floor(jr_wd) * 60 + mod(jr_wd, 1) * 100) -
                    (floor(jc_wd) * 60 + mod(jc_wd, 1) * 100)),
                    60) * 0.01;
      else
        zwsj := floor(((floor(jc_wd) * 60 + mod(jc_wd, 1) * 100) -
                      (floor(jr_wd) * 60 + mod(jr_wd, 1) * 100)) / 60) +
                mod(((floor(jc_wd) * 60 + mod(jc_wd, 1) * 100) -
                    (floor(jr_wd) * 60 + mod(jr_wd, 1) * 100)),
                    60) * 0.01;
        gdsj := 0;
      end if;
      v_jrwd := jr_wd;
      v_jcwd := jc_wd;
    end if;
  end if;

  /* 三、接入终到：1 ---------接正到正*/
  if (yxfs = '接入终到') then
    if (jr_wd = 0 and zd_wd = 0) then
      v_jrwd := jr_wd;
      v_zdwd := zd_wd;
      zwsj   := 0;
      gdsj   := 0;
    end if;
    /* 2 ---------接正到早*/
    if (jr_wd = 0 and zd_wd < 0) then
      v_jrwd := jr_wd;
      v_zdwd := 0;
      zwsj   := 0;
      gdsj   := 0;
    end if;
    /* 3 ---------接正到晚*/
    if (jr_wd = 0 and zd_wd > 0) then
      v_jrwd := jr_wd;
      v_zdwd := zd_wd;
      zwsj   := zd_wd;
      gdsj   := 0;
    end if;
    /* 4---------接早到正*/
    if (jr_wd < 0 and zd_wd = 0) then
      v_jrwd := 0;
      v_zdwd := zd_wd;
      zwsj   := 0;
      gdsj   := 0;
    end if;
    /* 5---------接早到早*/
    if (jr_wd < 0 and zd_wd < 0) then
      v_jrwd := 0;
      v_zdwd := 0;
      zwsj   := 0;
      gdsj   := 0;
    end if;
    /* 6---------接早到晚*/
    if (jr_wd < 0 and zd_wd > 0) then
      v_jrwd := 0;
      v_zdwd := zd_wd;
      zwsj   := zd_wd;
      gdsj   := 0;
    end if;
    /* 7---------接晚到正*/
    if (jr_wd > 0 and zd_wd = 0) then
      v_jrwd := jr_wd;
      v_zdwd := zd_wd;
      zwsj   := 0;
      gdsj   := jr_wd;
    end if;
    /* 8---------接晚到早*/
    if (jr_wd > 0 and zd_wd < 0) then
      v_jrwd := jr_wd;
      v_zdwd := 0;
      zwsj   := 0;
      gdsj   := jr_wd;
    end if;
    /* 9--------接晚到晚*/
    if (jr_wd > 0 and zd_wd > 0) then
      if (jr_wd >= zd_wd) then
        zwsj := 0;
        gdsj := floor(((floor(jr_wd) * 60 + mod(jr_wd, 1) * 100) -
                      (floor(zd_wd) * 60 + mod(zd_wd, 1) * 100)) / 60) +
                mod(((floor(jr_wd) * 60 + mod(jr_wd, 1) * 100) -
                    (floor(zd_wd) * 60 + mod(zd_wd, 1) * 100)),
                    60) * 0.01;
      else
        zwsj := floor(((floor(zd_wd) * 60 + mod(zd_wd, 1) * 100) -
                      (floor(jr_wd) * 60 + mod(jr_wd, 1) * 100)) / 60) +
                mod(((floor(zd_wd) * 60 + mod(zd_wd, 1) * 100) -
                    (floor(jr_wd) * 60 + mod(jr_wd, 1) * 100)),
                    60) * 0.01;
        gdsj := 0;
      end if;
      v_jrwd := jr_wd;
      v_zdwd := zd_wd;
    end if;
  end if;

  /* 四、始发终到--管内：1 ---------发正到正*/
  if (yxfs = '始发终到') then
    if (sf_wd = 0 and zd_wd = 0) then
      v_sfwd := sf_wd;
      v_zdwd := zd_wd;
      zwsj   := 0;
      gdsj   := 0;
    end if;
    /* 2 ---------发正到早*/
    if (sf_wd = 0 and zd_wd < 0) then
      v_sfwd := sf_wd;
      v_zdwd := 0;
      zwsj   := 0;
      gdsj   := 0;
    end if;
    /* 3 ---------发正到晚*/
    if (sf_wd = 0 and zd_wd > 0) then
      v_sfwd := sf_wd;
      v_zdwd := zd_wd;
      zwsj   := zd_wd;
      gdsj   := 0;
    end if;
    /* 4---------发早到正*/
    if (sf_wd < 0 and zd_wd = 0) then
      v_sfwd := -sf_wd;
      v_zdwd := zd_wd;
      zwsj   := 0;
      gdsj   := 0;
    end if;
    /* 5---------发早到早*/
    if (sf_wd < 0 and zd_wd < 0) then
      v_sfwd := -sf_wd;
      v_zdwd := 0;
      zwsj   := 0;
      gdsj   := 0;
    end if;
    /* 6---------发早到晚*/
    if (sf_wd < 0 and zd_wd > 0) then
      v_sfwd := -sf_wd;
      v_zdwd := zd_wd;
      zwsj   := zd_wd;
      gdsj   := 0;
    end if;
    /* 7---------发晚到正*/
    if (sf_wd > 0 and zd_wd = 0) then
      v_sfwd := sf_wd;
      v_zdwd := zd_wd;
      zwsj   := 0;
      gdsj   := sf_wd;
    end if;
    /* 8---------发晚到早*/
    if (sf_wd > 0 and zd_wd < 0) then
      v_sfwd := sf_wd;
      v_zdwd := 0;
      zwsj   := 0;
      gdsj   := sf_wd;
    end if;
    /* 9--------发晚到晚*/
    if (sf_wd > 0 and zd_wd > 0) then
      if (sf_wd >= zd_wd) then
        zwsj := 0;
        gdsj := floor(((floor(sf_wd) * 60 + mod(sf_wd, 1) * 100) -
                      (floor(zd_wd) * 60 + mod(zd_wd, 1) * 100)) / 60) +
                mod(((floor(sf_wd) * 60 + mod(sf_wd, 1) * 100) -
                    (floor(zd_wd) * 60 + mod(zd_wd, 1) * 100)),
                    60) * 0.01;
      else
        zwsj := floor(((floor(zd_wd) * 60 + mod(zd_wd, 1) * 100) -
                      (floor(sf_wd) * 60 + mod(sf_wd, 1) * 100)) / 60) +
                mod(((floor(zd_wd) * 60 + mod(zd_wd, 1) * 100) -
                    (floor(sf_wd) * 60 + mod(sf_wd, 1) * 100)),
                    60) * 0.01;
        gdsj := 0;
      end if;
      v_sfwd := sf_wd;
      v_zdwd := zd_wd;
    end if;
  end if;

end PRO_YXSJ_JSWD;
/

