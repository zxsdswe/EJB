create procedure yc_check_jdbz2  is

hjc1 varchar2(30);
hsj1 varchar2(30);
cc  varchar2(30);
czm  varchar2(30);
cc1  varchar2(30);
czm1  varchar2(30);
hjc varchar2(30);
hsj varchar2(30);
id varchar2(30);
zx varchar2(30);
cs number(3);

/*
DROP TABLE dic_base_lineBAK;
DROP TABLE  dic_base_line_nodeBAK;
create table  dic_base_lineBAK as select * from dic_base_line where chartid=18;
create table dic_base_line_nodeBAK as select * from dic_base_line_node where chartid=18;
commit;
*/

CURSOR check_cc  IS  select  base_id,train_code from  train_info  where  plan='19春运节后普'     and ( train_code not like 'G%' and   train_code not like 'D%' and   train_code not like 'C%'  and   train_code not like 'X%') order by  base_id desc  ;
CURSOR check_bz  IS  select  b.stn,b.node_order,b.change_driver,b.change_loco from dic_base_line_nodeBAK b where base_line_id=id  and (change_driver<>'0' or change_loco<>'0'）  order by node_order;

begin
  OPEN check_cc;
   LOOP
      FETCH check_cc INTO id,cc;
      EXIT WHEN check_cc%NOTFOUND;
         OPEN check_bz;
           dbms_output.put_line(cc);
         LOOP
            FETCH check_bz INTO czm,zx,hsj,hjc;
            EXIT WHEN check_bz%NOTFOUND;
             if hsj='1'  and hjc='0' then
                   select count(*) into cs from train_schedule where train_id in (select train_id from train_info where  base_id=id  and plan='19春运节后普' ) and sta_name=czm  and sta_type like '%5%';
                   if cs<1 then
                      insert into yc_log (plan1,cc1,czm1,log) values(id,cc,czm,cc||'次在'||czm||'站找不到换司机标志！');
                      commit;
                   end if;
             end if;

            if hsj='1'  and hjc='1' then
                  select count(*) into cs from train_schedule where   train_id in (select train_id from train_info where  base_id=id and plan='19春运节后普')  and sta_name=czm  and sta_type like '%3%';
                   if cs<1 then
                      insert into yc_log (plan1,cc1,czm1,log) values(id,cc,czm,cc||'次在'||czm||'站找不到换机车标志！');
                      commit;
                   end if;
            end if;


        end loop;
        close check_bz;

      end loop;
     close check_cc;    --关闭游标

end yc_check_jdbz2;
/

