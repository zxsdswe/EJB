create function del_runline(dt date) return integer is
  Result integer;
Begin
Result:=0;
For x In (Select Id From run_line Where run_date<to_char(dt-40,'yyyymmdd')) Loop
Begin
Delete From run_line Where Id =x.Id;
Commit;
End;
End Loop;  

  return(Result);
end del_runline;
/

