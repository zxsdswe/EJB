create procedure      setCrossLine1(cid integer) as
  pid integer;
  nid integer; 
begin
  pid:=-1;
  nid:=-1;
for c in (
  select e.train_id,e.id,d.time from unit_run_line e,
  (select * from 
  (select a.train_id,run_date||start_time time 
    from unit_run_line a,train_schedule b  
    where a.train_id=b.train_id and b.sta_sort=1 and crossgraphics_id=cid 
    group by a.train_id,run_date||start_time
  )) d
    where e.train_id=d.train_id
  order by d.time
) loop
  begin
    update unit_run_line 
    set 
      prerunline_id =pid
    where id = c.id ;
      pid:=c.id;
  end;
end loop;

for c in (
  select e.train_id,e.id,d.time from unit_run_line e,
  (select * from 
  (select a.train_id,run_date||start_time time 
    from unit_run_line a,train_schedule b  
    where a.train_id=b.train_id and b.sta_sort=1 and crossgraphics_id=cid 
    group by a.train_id,run_date||start_time
  )) d
    where e.train_id=d.train_id
  order by d.time desc
) loop
  begin
    update unit_run_line 
    set 
      nextrunline_id=nid
    where id = c.id ;
      nid:=c.id;
  end;
end loop;
  
  commit;

end;
/

