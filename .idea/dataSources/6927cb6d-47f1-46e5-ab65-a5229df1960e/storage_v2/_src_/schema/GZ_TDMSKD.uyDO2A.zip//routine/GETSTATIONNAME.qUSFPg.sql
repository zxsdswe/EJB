create FUNCTION GETSTATIONNAME (p_train_cc
    in train_schedule.train_kpid%type, p_station_no in
    train_schedule.sta_sort%type) return varchar2 is
  Result varchar2(12);
begin
  select sta_name into result from train_schedule
    where trim(train_kpid)=trim(p_train_cc) and to_number(trim(sta_sort))=to_number(trim(p_station_no));
  return(trim(result));
end getStationName;
/

