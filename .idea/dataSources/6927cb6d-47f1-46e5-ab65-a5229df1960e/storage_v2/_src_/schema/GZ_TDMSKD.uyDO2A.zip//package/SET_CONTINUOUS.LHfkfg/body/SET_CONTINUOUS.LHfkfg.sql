create Package Body Set_Continuous Is
	Function Mainrun(Cc0 In Varchar2, Cc1 In Varchar2) Return Integer Is
		Pragma Autonomous_Transaction;
	Begin
    Set_Ids(Cc0, Cc1);
    Return(0);
  End;

  Procedure Set_Ids(Cc0 In Varchar2, Cc1 In Varchar2) Is
    --V_ERRMSG Varchar2(500);
    Tsql Varchar2(500);
  Begin
  
    For x In (Select Tsql
                From (Select 'Update run_line Set nextrunline_id=' || b.Id ||
                             ' Where Id=' || a.Id || ';'
                        From (Select * From Run_Line Where Cc In (Cc0)) a,
                             (Select * From Run_Line Where Cc In (Cc1)) b
                       Where b.Begin_Time - a.End_Time > 0
                         And b.Begin_Time - a.End_Time < 1)) Loop
      Begin
        Execute Immediate x.Tsql;
        Insert Into Log_Continuous Values (Sysdate, x.Tsql);
        Commit;
      Exception
        When Others Then
          Begin
            Rollback;
            --V_ERRMSG:=SQLERRM;
            Commit;
          End;
      End;
    End Loop;
  
    For x In (Select Tsql
                From (Select 'Update run_line Set prerunline_id=' || a.Id ||
                             ' Where Id=' || b.Id || ';'
                        From (Select * From Run_Line Where Cc In (Cc0)) a,
                             (Select * From Run_Line Where Cc In (Cc1)) b
                       Where b.Begin_Time - a.End_Time > 0
                         And b.Begin_Time - a.End_Time < 1)) Loop
      Begin
        Execute Immediate x.Tsql;
        Insert Into Log_Continuous Values (Sysdate, x.Tsql);
        Commit;
      Exception
        When Others Then
          Begin
            Rollback;
            --V_ERRMSG:=V_ERRMSG+'-->'+SQLERRM;
            Commit;
          
          End;
      End;
    End Loop;
  
  End;

End Set_Continuous;
/

