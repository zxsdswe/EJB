create procedure sunday_rbjh_newgt(dnum  in number) is
-----567
rqstr    varchar2(8);
brq      varchar2(8);
runid    number(12);
rid      number(10);
id       number(10);
sfddid   number(10);
sfbz     varchar2(10);
runcc    varchar2(16);
lcc      varchar2(5);
zm       varchar2(46);
gsj      varchar2(16);
grq      varchar2(16);
hrq      varchar2(20);
str_sfz  varchar2(20);
str_dzd  varchar2(50);
sta_sj   varchar2(20);
end_sj   varchar2(20);
sta_d    varchar2(20);
end_d    varchar2(20);
nfjkz    varchar2(20);
yzzm     varchar2(20);
qcc      varchar2(16);
ii       number(5);
DAY1     varchar2(16);
DAY2     varchar2(16);
yzid     number(4);
pxh      number(4);
tkid     number(5);
kct1     number(5);
kcl1     number(5);
kch1    number(5);
kct2    number(5);
kcl2    number(5);
kch2    number(5);
kct3    number(5);
kcl3    number(5);
kch3    number(5);
kct4    number(5);
kcl4    number(5);
kch4    number(5);
kct5    number(5);
kcl5    number(5);
kch5    number(5);
zmzdhz  varchar2(16);
lc      number(5);
lklx    varchar2(10);
lkcc    varchar2(16);
trainkind varchar2(20);
cclong  number(5);
fid     number(5);
ccline  varchar2(16);
fxstr   varchar2(60);
rtid    varchar2(60);
xbid    varchar2(12);
endcc   varchar2(10);
ptid    varchar2(30);
newrq   varchar2(8);
nextid  varchar2(12);
endtime varchar2(20);
newst1  varchar2(20);
newst2  varchar2(20);
newst3  varchar2(20);
newst4  varchar2(20);
newst5  varchar2(20);

------读出发车次
CURSOR read_run_line IS
SELECT  id,cc,sfz,zdz,train_kind    FROM run_line 
   WHERE id in (select  runline_id from run_point where go_date||go_time>sta_sj and  go_date||go_time <= end_sj 
        and station_name in (select ZM from zmzdb where ljdm='Q' )  and xh=1 )
       and multipro_flag='H' and  cc NOT LIKE 'DJ%' and  cc NOT LIKE '0%' and  cc NOT LIKE '5%' AND STOPFLAg = 1
       and   (cc like 'D%' or   cc like 'G%' or   cc like 'C%' or   cc like 'S%'); 
------读终到车次
CURSOR read_run_line_zd IS
SELECT  id,cc,sfz,zdz,train_kind    FROM run_line 
   WHERE  id in (select  runline_id from run_point where arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj 
        and station_name in (select ZM from zmzdb where ljdm='Q')  and arr_time<>'-100')
        and multipro_flag='H' and  cc NOT LIKE 'DJ%' and  cc NOT LIKE '0%' and  cc NOT LIKE '5%'  AND (STOPFLAg = 1)  ; 
-------读分界口车次数据
CURSOR read_run_point_fjk IS
SELECT  runline_id,station_name,arr_date||arr_time,go_date||go_time,xh    FROM run_point 
   WHERE  runline_id in (select  id from run_line where STOPFLAG = 1 
          and multipro_flag='H' and  cc NOT LIKE 'DJ%' and  cc NOT LIKE '0%' and  cc NOT LIKE '5%'  and  cc NOT LIKE 'K%' and  cc NOT LIKE 'Z%' and  cc NOT LIKE 'T%')
   and ((arr_date||arr_time>sta_sj and  arr_date||arr_time <= end_sj) or 
        (go_date||go_time>sta_sj and  go_date||go_time <= end_sj))  and arr_time<>'-100' 
   and station_name in ( '赤壁北','醴陵东','永州','诏安','郁南','怀集','新晃西','铜仁铜玉场','福田','黔江渝怀场') ; 
   
-------读区段数据2015-02-15
-------读区段数据2015-02-15 
-------读区段数据2021-09-27
CURSOR read_run_point_qd IS
select id,t1.station_name,to_char(arr_sj,'yyyymmddhh24mi'),to_char(go_sj,'yyyymmddhh24mi'),xh,cc,sfz,zdz,train_kind,station_name from RUN_LINE t,RUN_POINT_DETAIL t1 where run_date>=brq and run_date<=rqstr and stopflag=1 and (cc like '%G%'or  cc like '%D%' or cc like '%C%' or cc like '%S%') and
runline_id=t.id and arr_sj>=to_date(sta_sj,'yyyymmddhh24mi') 
and arr_sj<=to_date(end_sj,'yyyymmddhh24mi')  and  t1.station_name in (select zm from DDS_START_KCQB_ZD where dcs='N');

-------读动车段进出库数据2016-02-10
CURSOR read_run_point_dc IS
SELECT  train_id,stn,to_char(arr_time,'yyyymmddhh24mi'),to_char(dep_time,'yyyymmddhh24mi'),node_order    FROM tdmsdayplan.gb_train_line_node 
   where    to_char(dep_time,'yyyymmddhh24mi') > sta_sj 
    and  to_char(dep_time,'yyyymmddhh24mi') <= end_sj 
   and stn in ('广州动车段','长沙动车所武广场','深圳动车运用所') ; 

CURSOR read_run_point_sqq IS
SELECT  train_id,stn,to_char(arr_time,'yyyymmddhh24mi'),to_char(dep_time,'yyyymmddhh24mi'),node_order    FROM tdmsdayplan.gb_train_line_node 
   where    to_char(dep_time,'yyyymmddhh24mi') > sta_sj 
    and  to_char(dep_time,'yyyymmddhh24mi') <= end_sj 
   and stn in ('盐步所') ; 
 
-----读出发车次分析数据----
CURSOR read_dds_start_kc_data IS
SELECT  distinct(station)    FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz order by station; 
--------过程开始
begin
    select to_char(sysdate ,'yyyymmdd') into newrq  from dual;
    select to_char(sysdate + dnum +1,'yyyymmdd') into rqstr  from dual;
    select to_char(sysdate + dnum,'yyyymmdd') into sta_sj  from dual;
    
--   rqstr:='20150129';
--    sta_sj:='20150128';
    DAY1 :=sta_sj;
    DAY2 :=rqstr;
    
    sta_d :=sta_sj;
    end_d :=end_sj;
--    sta_sj :=sta_sj||'1800';
--    end_sj :=rqstr||'1800'; 
    sta_sj :=sta_sj||'0000';
    end_sj :=rqstr ||'0000';
    ------2023-01-12增加
    --delete from RUN_POINT_TJS;
    --commit;
    --insert into   RUN_POINT_TJS  select   runline_id,station_name,arr_sj,arr_date||arr_time as arrstr,xh,runline_id||station_name as run_zm  from tdmskd.RUN_POINT_DETAIL t  where t.arr_sj>=to_date(sta_sj,'yyyymmddhh24mi') and t.arr_sj<=to_date(end_sj,'yyyymmddhh24mi')
    --and  t.station_name in (select zm from DDS_START_KCQB_ZD where dcs='N');
    --commit;
    
    
    select to_char(sysdate + dnum,'yyyymmdd') into rqstr  from dual;
    select to_char(sysdate + dnum -1,'yyyymmdd') into brq  from dual;
    
    delete from dds_start_kc_data_gt where rq = rqstr  and ren like '过车%';
    delete from dds_start_kc_tj_gt where rq = rqstr    and ren like '过车%';
    delete from dds_start_kc_tj_zlwgt where rq = rqstr and sfbz like '过车%';
    commit;
    rid := 0;
 

  rid := 0;   
OPEN read_run_point_qd;
       LOOP
       FETCH read_run_point_qd INTO runid,zm,sta_d,end_d,id,runcc,str_sfz,str_dzd,trainkind,ptid;
       EXIT WHEN read_run_point_qd%NOTFOUND;
------       select train_num,sfz,zdz,stat_kind,pt_id  into runcc,str_sfz,str_dzd,trainkind,ptid  from tdmsdayplan.gb_train_line where train_id=runid ;
       endtime:='';
       nextid:='';

     if runid='10569938' then 
       nfjkz:='过车';
     end if;
       --------上下行
       fid := id + 1;
       zmzdhz:='';
       begin
       select station_name into  zmzdhz from tdmskd.RUN_POINT_DETAIL where runline_id=runid and xh = fid; 
       EXCEPTION 
        WHEN OTHERS THEN 
            zmzdhz:='';  
       ROLLBACK;
       end;
       yzzm:='';
       fid :=id - 1;
       begin
       ------select stn into  yzzm from tdmsdayplan.gb_train_line_node where train_id=runid and node_order = fid;
       select station_name into  yzzm from tdmskd.RUN_POINT_DETAIL where runline_id=runid and xh = fid;
       EXCEPTION
        WHEN OTHERS THEN
             yzzm:='';
           ROLLBACK;
        end;
       fxstr:=yzzm || zm ||  zmzdhz;
       begin
       select fx into  nfjkz from dds_start_kc_gtfx where jlm=fxstr ; 
       EXCEPTION 
        WHEN OTHERS THEN 
           ROLLBACK;
           insert into dds_start_kc_gtfx(jlm,fx,zm,rid) values (fxstr,'过车x',zm,runid);
           commit;
       end; 
       
          lkcc:=substr(runcc,1,1);
          lklx:='图客';
          if lkcc ='A' or lkcc= '0' or lkcc = 'L' or lkcc = 'Y' then
           lklx:='临客';
          end if;
            fid :=INSTR(runcc,'/',1,1);
            ccline:=runcc;
           if fid> 0 then
              ccline:=substr(runcc,1,fid - 1); 
           end if;
           cclong:=length(ccline);
           if cclong>= 5  then  
              lkcc:=ccline;
              if  (lkcc >='G4001' and lkcc<='G4998') or (lkcc >='G9001' and lkcc<='G9998') or (lkcc >='C9001' and lkcc<='C9998')  or (lkcc >'D4001' and lkcc<='D4998') or (lkcc >'D9001' and lkcc<='D9998') or (lkcc >'K5001' and lkcc<='K6998') then
                   lklx:='临客';
              end if;
           end if;
           qcc:=runcc;
           if fid > 0 then 
              qcc:=substr(runcc,1,fid - 1);
           end if;
           if qcc >='3001' and qcc<='3998' and length(qcc)=4 then 
              lklx:='临客';
           end if;
       
       
       
        fid :=INSTR(trainkind,'LK',1,1);
        if fid > 0 then 
       ---          lklx:='临客';
         ---      fid := 0;
         fid:=fid;
        end if;
       hrq:=end_d;
       if nfjkz<>'过车x' then  
           insert into dds_start_kc_data_gt(RQ,REN,ID,RID,STATION,CC,TSJ,SFZ,ZDZ,LX,kind,pt_id,endsj,endid) values (rqstr,nfjkz,rid,runid,zm,runcc,hrq,str_sfz,str_dzd,lklx,trainkind,ptid,endtime,nextid);
           commit;
       end if;
 end loop;
  
  CLOSE read_run_point_qd;


  
----统计出发情况分析-----
 delete from dds_start_kc_tj_gt where rq = rqstr;
 COMMIT;
 
ii := 4;
loop 
ii := ii+ 1;
if ii = 1 then 
 sfbz:='始发';
end if;
if ii = 2 then 
 sfbz:='终到';
end if;
if ii = 3 then 
 sfbz:='接入';
end if;
if ii = 4 then 
 sfbz:='交出';
end if;


if ii = 5 then 
 sfbz:='过车上';
end if;

if ii = 6 then 
 sfbz:='过车下';
end if;




EXIT WHEN ii > 6 ;
rid := 0;  
kct1 :=0;
kcl1  :=0;
kch1  :=0;
kct2  :=0;
kcl2  :=0;
kch2   :=0;
kct3  :=0;
kcl3   :=0;
kch3   :=0;
kct4  :=0;
kcl4   :=0;
kch4   :=0;
kct5   :=0;
kcl5   :=0;
kch5  :=0;

OPEN read_dds_start_kc_data;
       LOOP
       FETCH read_dds_start_kc_data INTO ZM;
       EXIT WHEN read_dds_start_kc_data%NOTFOUND;
       ----第一阶段
       sta_sj := DAY2||'0000' ;
       end_sj := DAY2||'0600';
        SELECT  count(*) into kct1 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx ='图客' and      tsj >sta_sj and tsj <= end_sj;
        SELECT  count(*) into kcl1 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx ='临客' and   tsj >sta_sj and tsj <= end_sj ;
           kch1:=kct1+kcl1; 
       -----第二阶段
        sta_sj := DAY2||'0600' ;
        end_sj := DAY2||'1200';
        SELECT  count(cc) into kct2 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx ='图客' and     tsj >sta_sj and tsj <=end_sj;
        SELECT  count(cc) into kcl2 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                        lx ='临客' AND   tsj >sta_sj and tsj <=end_sj;
           kch2:=kct2+kcl2;    
       ------第三阶段
       sta_sj := DAY2||'1200' ;
       end_sj := DAY2||'1800';
        SELECT  count(cc) into kct3 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                     lx ='图客' AND        tsj >sta_sj and tsj <=end_sj;
        SELECT  count(cc) into kcl3 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                        lx ='临客' AND    tsj >sta_sj and tsj <=end_sj;
           kch3:=kct3+kcl3;     
         ---第四阶段
         sta_sj := DAY2||'1800' ;
         end_sj := DAY1||'0000';
        SELECT  count(cc) into kct4 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx ='图客' AND    tsj >sta_sj and tsj <=end_sj;
        SELECT  count(cc) into kcl4 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx ='临客' AND  tsj >sta_sj and tsj <=end_sj;
             kch4:=kct4+kcl4; 
             kct5:=kct1+kct2+kct3+kct4;
             kcl5:=kcl1+kcl2+kcl3+kcl4;
             kch5:=kch1+kch2+kch3+kch4;              
             rid := rid + 1;
             insert into dds_start_kc_tj_gt values (rqstr,sfbz,rid,zm,kct1,kcl1,kch1,kct2,kcl2,kch2,kct3,kcl3,kch3,kct4,kcl4,kch4,kct5,kcl5,kch5,1);
        
      commit; 
  end loop;
CLOSE read_dds_start_kc_data;
end loop;


----统计出发情况分析(按调度所统计)-----
delete from dds_start_kc_tj_zlwgt where rq = rqstr;
COMMIT;
 
ii := 0;
loop 
ii := ii+ 1;
if ii = 1 then 
 sfbz:='始发';
end if;
if ii = 2 then 
 sfbz:='终到';
end if;
if ii = 3 then 
 sfbz:='接入';
end if;
if ii = 4 then 
 sfbz:='交出';
end if;

if ii = 5 then 
 sfbz:='过车上';
end if;

if ii = 6 then 
 sfbz:='过车下';
end if;

EXIT WHEN ii > 6 ;
rid := 0;  
kct1 :=0;
kct2 :=0;
kct3 :=0;
kct4 :=0;
kct5 :=0;
 
OPEN read_dds_start_kc_data;
       LOOP
       FETCH read_dds_start_kc_data INTO ZM;
       EXIT WHEN read_dds_start_kc_data%NOTFOUND;
       sta_sj := DAY1||'0000' ;
       end_sj := DAY2||'0000';
       
       ----图定客车
        SELECT  count(cc) into kct1 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                      lx='图客' and   tsj >sta_sj and tsj <= end_sj;
        -----临客-----
        
        SELECT  count(cc) into kct2 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                        lx='临客' and  cc not like '0%' and  tsj >sta_sj and tsj <= end_sj ;
          ------车底----------  
                    
         SELECT  count(cc) into kct3 FROM dds_start_kc_data_gt WHERE rq=rqstr and ren=sfbz and station=zm and 
                         lx='临客'  and  cc  like '0%'  and   tsj >sta_sj and tsj <= end_sj ;              
                     
             kct4:=kct1+kct2+kct3;         
             rid := rid + 1;
             insert into dds_start_kc_tj_zlwgt values (rqstr,sfbz,rid,zm,kct1,kct2,kct3,kct4,kct5);
        
      commit; 
  end loop;
CLOSE read_dds_start_kc_data;
end loop;
  delete from  DDS_START_KCGT_TIME where tren='高速铁路';
  insert into  DDS_START_KCGT_TIME select '高速铁路',to_char(sysdate ,'yyyy-mm-dd hh24:mi')   from dual;
commit;
end sunday_rbjh_newgt;
/

