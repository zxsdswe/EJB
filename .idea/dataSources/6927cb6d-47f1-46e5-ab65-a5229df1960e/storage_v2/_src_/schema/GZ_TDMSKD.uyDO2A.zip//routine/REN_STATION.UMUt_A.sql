create function ren_station(old_station in varchar2,new_station in varchar2,new_pym In Varchar2) return Varchar2 is
  V_ERRMSG Varchar2(200)  ;
begin
BEGIN
update ZMZDB set ZM=new_station,pym=new_pym where ZM=old_station;
update b_station set station_name=new_station,station_shortcode=new_pym where station_name=old_station;
update train_info set BEGIN_STA_NAME=new_station where BEGIN_STA_NAME=old_station;
update train_info set end_STA_NAME=new_station where end_STA_NAME=old_station;
update train_schedule set STA_NAME=new_station where STA_NAME=old_station;
update run_line set sfz=new_station where sfz=old_station;
update run_line set zdz=new_station where zdz=old_station;
update run_point set station_name=new_station where station_name=old_station;
update stations_list set station_name=new_station where station_name=old_station;
update unit_run_line set sfz=new_station where sfz=old_station;
update unit_run_line set zdz=new_station where zdz=old_station;
update unit_run_point set station_name=new_station where station_name=old_station;
update unit_stations_list set station_name=new_station where station_name=old_station;

update dic_ljkb set zm=new_station where zm=old_station;
update CMD_OTHER set zm=new_station where zm=old_station;

update SGML set gczm=new_station where gczm=old_station;
update SGML set sczm=new_station where sczm=old_station;
update SGML set zczm=new_station where zczm=old_station;
update SGML set fsczm=new_station where fsczm=old_station;
update SGML set dwczm1=new_station where dwczm1=old_station;
update SGML set dwczm2=new_station where dwczm2=old_station;
update SGML set sczm=new_station where sczm=old_station;



update SGML_CHANGED set gczm=new_station where gczm=old_station;
update SGML_CHANGED set sczm=new_station where sczm=old_station;
update SGML_CHANGED set zczm=new_station where zczm=old_station;
update SGML_CHANGED set fsczm=new_station where fsczm=old_station;
update SGML_CHANGED set dwczm1=new_station where dwczm1=old_station;
update SGML_CHANGED set dwczm2=new_station where dwczm2=old_station;
update SGML_CHANGED set sczm=new_station where sczm=old_station;
update SGML_CHANGED set ARRSTA_NAME=new_station where ARRSTA_NAME=old_station;

update SG_ACTION set zm=new_station where zm=old_station;

update SGML_LZ_SIGN set zm=new_station where zm=old_station;

update SGML_CLAIM set gczm=new_station where gczm=old_station;
update SGML_CLAIM set sczm=new_station where sczm=old_station;
update SGML_CLAIM set zczm=new_station where zczm=old_station;
update SGML_CLAIM set fsczm=new_station where fsczm=old_station;
update SGML_CLAIM set dwczm1=new_station where dwczm1=old_station;
update SGML_CLAIM set dwczm2=new_station where dwczm2=old_station;
update SGML_CLAIM set sczm=new_station where sczm=old_station;
update SGML_CLAIM set ARRSTA_NAME=new_station where ARRSTA_NAME=old_station;

update DIC_LJKKCJJ set zm=new_station where zm=old_station;

update CHANGE_RECORD set zm=new_station where zm=old_station;

update CROSS_ALTERNATE_TRAIN_KYZL set sfzm=new_station where sfzm=old_station;
update CROSS_ALTERNATE_TRAIN_KYZL set zdzm=new_station where zdzm=old_station;

update STATION_LIST_KYZL set zm=new_station where zm=old_station;

update EMPHASIS_CONTENT set zm=new_station where zm=old_station;

update UNIT_HOLD_POINT set STATION_NAME=new_station where STATION_NAME=old_station;

update HOLD_POINT_log set STATION_NAME=new_station where STATION_NAME=old_station;

update RUN_POINT_CHANGE set STATION_NAME=new_station where STATION_NAME=old_station;

update RUN_POINT_LOG set STATION_NAME=new_station where STATION_NAME=old_station;
update STATIONS_LIST_LOG set STATION_NAME=new_station where STATION_NAME=old_station;

update ADD_LKCMD set ST_STA_NAME=new_station where ST_STA_NAME=old_station;
update ADD_LKCMD set AR_STA_NAME=new_station where AR_STA_NAME=old_station;

update STOP_LKCMD set ST_STA_NAME=new_station where ST_STA_NAME=old_station;

update STATION_LIST_KYZL set zm=new_station where zm=old_station;


Commit;
  RETURN old_station||'更改为=>'||new_station||'成功执行!';
  EXCEPTION 
    WHEN OTHERS THEN 
    V_ERRMSG:=SQLERRM;
    Return v_errmsg;
    Rollback;
  END;
end ren_station;
/

