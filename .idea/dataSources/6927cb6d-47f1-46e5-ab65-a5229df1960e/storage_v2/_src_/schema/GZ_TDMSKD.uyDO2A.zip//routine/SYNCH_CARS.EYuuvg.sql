create function synch_cars
(days in number)
return boolean
is
  type carsFileHeadMess is record
  (
  TRAIN_NO cars.TRAIN_NO%type,
  SZDUTY_UNIT cars.SZDUTY_UNIT%type,
  SZORG_STN cars.SZORG_STN%type,
  SZORG_TIME cars.SZORG_TIME%type,
  MQFILENAME cars.MQFILENAME%type,
  ORG_YMD cars.ORG_YMD%type,
  ORG_HMS cars.ORG_HMS%type
  );
  type carsFileValidRecord is record
  (
  TRAIN_NO cars.TRAIN_NO%type,
  SZORG_STN cars.SZORG_STN%type,
  ORG_YMD cars.ORG_YMD%type,
  valid_flag car_marshalling_head.valid_flag%type,
  files number
  );
  type carsFileHeadArray is table of carsFileHeadMess index by binary_integer;
  type carsFileValidArray is table of carsFileValidRecord index by binary_integer;
  --
  fileHeadMess carsFileHeadMess;
  fileValidRecord carsFileValidRecord;
  fileHeadArr carsFileHeadArray;
  fileHeadNowArr carsFileHeadArray;
  fileHeadNewArr carsFileHeadArray;
  fileValidArr carsFileValidArray;
  trainFileValidArr carsFileValidArray;
  --
  i number;
  j number;
  k number;
  tmpNum number;
  tmpBln boolean;
  tmpDate date;
  arrLeng number;
  --
  trainNOStr varchar2(32);
  szOrgStnStr varchar2(32);
  mqFileNameStr varchar2(32);
  szOrgTimeStr varchar2(32);
  lastTrainNOStr varchar2(32);
  lastSzOrgStnStr varchar2(32);
  --
  cursor carsFileHeadCur is
    select distinct TRAIN_NO,SZDUTY_UNIT,SZORG_STN,SZORG_TIME,MQFILENAME,ORG_YMD,ORG_HMS from cars
      where to_date(szorg_time,'yyyymmddhh24miss')>(sysdate-days) order by to_date(szorg_time,'yyyymmddhh24miss'),mqfilename;
  cursor marshallingHeadCur is
    select distinct TRAIN_NO,SZDUTY_UNIT,SZORG_STN,SZORG_TIME,MQFILENAME,ORG_YMD,ORG_HMS from car_marshalling_head
      order by to_date(szorg_time,'yyyymmddhh24miss'),mqfilename;
  cursor marshallingHeadValidCur is
    select TRAIN_NO,SZORG_STN,ORG_YMD,valid_flag,count(*) from car_marshalling_head
      group by TRAIN_NO,SZORG_STN,ORG_YMD,valid_flag having valid_flag='0' order by TRAIN_NO,SZORG_STN,ORG_YMD;
begin
  i:=1;
  open marshallingHeadCur;
  loop
    fetch marshallingHeadCur into
      fileHeadMess.TRAIN_NO,fileHeadMess.SZDUTY_UNIT,fileHeadMess.SZORG_STN,fileHeadMess.SZORG_TIME,fileHeadMess.MQFILENAME,fileHeadMess.ORG_YMD,fileHeadMess.ORG_HMS;
    exit when marshallingHeadCur%notfound;
    fileHeadNowArr(i):=fileHeadMess;
    i:=i+1;
  end loop;
  close marshallingHeadCur;
  i:=1;
  open carsFileHeadCur;
  loop
    fetch carsFileHeadCur into
      fileHeadMess.TRAIN_NO,fileHeadMess.SZDUTY_UNIT,fileHeadMess.SZORG_STN,fileHeadMess.SZORG_TIME,fileHeadMess.MQFILENAME,fileHeadMess.ORG_YMD,fileHeadMess.ORG_HMS;
    exit when carsFileHeadCur%notfound;
    fileHeadArr(i):=fileHeadMess;
    i:=i+1;
  end loop;
  close carsFileHeadCur;
  --
  tmpNum:=1;
  for i in 1..fileHeadArr.count loop
    mqFileNameStr:=fileHeadArr(i).mqfilename;szOrgTimeStr:=fileHeadArr(i).szorg_time;tmpBln:=true;
    for j in 1..fileHeadNowArr.count loop
      if mqFileNameStr=fileHeadNowArr(j).mqfilename and szOrgTimeStr=fileHeadNowArr(j).szorg_time then
      	tmpBln:=false;
      	exit;
      end if;
    end loop;
    if tmpBln then
      fileHeadMess.TRAIN_NO:=fileHeadArr(i).TRAIN_NO;
      fileHeadMess.SZDUTY_UNIT:=fileHeadArr(i).SZDUTY_UNIT;
      fileHeadMess.SZORG_STN:=fileHeadArr(i).SZORG_STN;
      fileHeadMess.SZORG_TIME:=fileHeadArr(i).SZORG_TIME;
      fileHeadMess.MQFILENAME:=fileHeadArr(i).MQFILENAME;
      fileHeadMess.ORG_YMD:=fileHeadArr(i).ORG_YMD;
      fileHeadMess.ORG_HMS:=fileHeadArr(i).ORG_HMS;
      fileHeadNewArr(tmpNum):=fileHeadMess;
      tmpNum:=tmpNum+1;
    end if;
  end loop;
  --
  j:=1;
  for i in 1..fileHeadNewArr.count loop
    select cars_id_s.nextval into tmpNum from dual;
    insert into car_marshalling_head(cars_id,TRAIN_NO,SZDUTY_UNIT,SZORG_STN,SZORG_TIME,MQFILENAME,ORG_YMD,ORG_HMS)
      values(tmpNum,fileHeadNewArr(i).TRAIN_NO,fileHeadNewArr(i).SZDUTY_UNIT,fileHeadNewArr(i).SZORG_STN,fileHeadNewArr(i).SZORG_TIME,fileHeadNewArr(i).MQFILENAME,fileHeadNewArr(i).ORG_YMD,fileHeadNewArr(i).ORG_HMS);
    insert into car_marshalling_mess(cars_id,CAR_SEQNO,CAR_KIND,CAR_NO,PSNG_LIMIT,SELF_WGT,LOAD_WGT,CNVT_LEN,POS_UNIT,USE_UNIT,PICK_OFF_FLAG,NEW_EXPR_FLAG,ORDER_NO,NOTE)
      select tmpNum,CAR_SEQNO,CAR_KIND,CAR_NO,PSNG_LIMIT,SELF_WGT,LOAD_WGT,CNVT_LEN,POS_UNIT,USE_UNIT,PICK_OFF_FLAG,NEW_EXPR_FLAG,ORDER_NO,NOTE from cars
        --where TO_DATE(SZORG_TIME,'yyyymmddhh24miss')=TO_DATE(fileHeadNewArr(i).SZORG_TIME,'yyyymmddhh24miss') and MQFILENAME=fileHeadNewArr(i).MQFILENAME;
        where TRAIN_NO=fileHeadNewArr(i).TRAIN_NO and MQFILENAME=fileHeadNewArr(i).MQFILENAME;
    insert into car_marshalling(cars_id,PSNG_CAR_NBR,BASE_NBR,ADD_CODE1,ADD_NBR1,ADD_CODE2,ADD_NBR2,ADD_CODE3,ADD_NBR3,FREIGHT_NBR,OTHER_NBR,TOTAL_NBR,SELF_WGT,LOAD_WGT,GROSS_WGT,CNVT_LEN,NOTE)
      select tmpNum,PSNG_CAR_NBR,BASE_NBR,ADD_CODE1,ADD_NBR1,ADD_CODE2,ADD_NBR2,ADD_CODE3,ADD_NBR3,FREIGHT_NBR,OTHER_NBR,TOTAL_NBR,SELF_WGT,LOAD_WGT,GROSS_WGT,CNVT_LEN,NOTE from MARSHALLING
        where TRAIN_NO=fileHeadNewArr(i).TRAIN_NO and MQFILENAME=fileHeadNewArr(i).MQFILENAME;
    insert into car_marshalling_rpt_header(cars_id,RPT_ID,DUTY_UNIT,GROUP_NO,LOCO_NO,ORG_STN,DEST_STN,RPT_STN,ORG_TIME,RPT_TIME,DLV_TIME,AUTHOR,DUTY_STAFF,CONDUCTOR,COND_UNIT,DRIVER,RKSJ)
      select tmpNum,RPT_ID,DUTY_UNIT,GROUP_NO,LOCO_NO,ORG_STN,DEST_STN,RPT_STN,ORG_TIME,RPT_TIME,DLV_TIME,AUTHOR,DUTY_STAFF,CONDUCTOR,COND_UNIT,DRIVER,RKSJ from RPT_HEADER
        where TRAIN_NO=fileHeadNewArr(i).TRAIN_NO and MQFILENAME=fileHeadNewArr(i).MQFILENAME;
    commit;
  end loop;
  --
  i:=1;
  open marshallingHeadValidCur;
  loop
    fetch marshallingHeadValidCur into
      fileValidRecord.TRAIN_NO,fileValidRecord.SZORG_STN,fileValidRecord.ORG_YMD,fileValidRecord.valid_flag,fileValidRecord.files;
    exit when marshallingHeadValidCur%notfound;
    fileValidArr(i):=fileValidRecord;
    i:=i+1;
  end loop;
  close marshallingHeadValidCur;
  --
  j:=1;
  for i in 1..fileValidArr.count loop
    trainNOStr:=fileValidArr(i).TRAIN_NO;
    szOrgStnStr:=fileValidArr(i).SZORG_STN;
    if i=1 then
      lastTrainNOStr:=trainNOStr;
      lastSzOrgStnStr:=szOrgStnStr;
    end if;
    if lastTrainNOStr=trainNOStr and lastSzOrgStnStr=szOrgStnStr then
      fileValidRecord.TRAIN_NO:=fileValidArr(i).TRAIN_NO;
      fileValidRecord.SZORG_STN:=fileValidArr(i).SZORG_STN;
      fileValidRecord.ORG_YMD:=fileValidArr(i).ORG_YMD;
      fileValidRecord.valid_flag:=fileValidArr(i).valid_flag;
      fileValidRecord.files:=fileValidArr(i).files;
      trainFileValidArr(j):=fileValidRecord;
      arrLeng:=j;
      j:=j+1;
    else
      k:=1;
      if arrLeng>10 then
        k:=arrLeng-10;
        for j in 1..k loop
          update car_marshalling_head set valid_flag='1'
            where TRAIN_NO=trainFileValidArr(j).TRAIN_NO and SZORG_STN=trainFileValidArr(j).SZORG_STN and ORG_YMD=trainFileValidArr(j).ORG_YMD;
        end loop;
        commit;
        k:=k+1;
      end if;
      for j in k..arrLeng loop
        if trainFileValidArr(j).files>1 then
          select max(TO_DATE(SZORG_TIME,'yyyymmddhh24miss')) into tmpDate from car_marshalling_head
            where TRAIN_NO=trainFileValidArr(j).TRAIN_NO and SZORG_STN=trainFileValidArr(j).SZORG_STN and ORG_YMD=trainFileValidArr(j).ORG_YMD;
          update car_marshalling_head set valid_flag='1'
            where TRAIN_NO=trainFileValidArr(j).TRAIN_NO and SZORG_STN=trainFileValidArr(j).SZORG_STN and ORG_YMD=trainFileValidArr(j).ORG_YMD and TO_DATE(SZORG_TIME,'yyyymmddhh24miss')<tmpDate;
        end if;
      end loop;
      commit;
      ------
      j:=1;
      arrLeng:=0;
      fileValidRecord.TRAIN_NO:=fileValidArr(i).TRAIN_NO;
      fileValidRecord.SZORG_STN:=fileValidArr(i).SZORG_STN;
      fileValidRecord.ORG_YMD:=fileValidArr(i).ORG_YMD;
      fileValidRecord.valid_flag:=fileValidArr(i).valid_flag;
      fileValidRecord.files:=fileValidArr(i).files;
      trainFileValidArr(j):=fileValidRecord;
      arrLeng:=j;
      j:=j+1;
      lastTrainNOStr:=fileValidArr(i).TRAIN_NO;
      lastSzOrgStnStr:=fileValidArr(i).SZORG_STN;
    end if;
  end loop;
  --
  k:=1;
  if arrLeng>10 then
    k:=arrLeng-10;
    for j in 1..k loop
      update car_marshalling_head set valid_flag='1'
        where TRAIN_NO=trainFileValidArr(j).TRAIN_NO and SZORG_STN=trainFileValidArr(j).SZORG_STN and ORG_YMD=trainFileValidArr(j).ORG_YMD;
    end loop;
    commit;
    k:=k+1;
  end if;
  for j in k..arrLeng loop
    if trainFileValidArr(j).files>1 then
      select max(TO_DATE(SZORG_TIME,'yyyymmddhh24miss')) into tmpDate from car_marshalling_head
        where TRAIN_NO=trainFileValidArr(j).TRAIN_NO and SZORG_STN=trainFileValidArr(j).SZORG_STN and ORG_YMD=trainFileValidArr(j).ORG_YMD;
      update car_marshalling_head set valid_flag='1'
        where TRAIN_NO=trainFileValidArr(j).TRAIN_NO and SZORG_STN=trainFileValidArr(j).SZORG_STN and ORG_YMD=trainFileValidArr(j).ORG_YMD and TO_DATE(SZORG_TIME,'yyyymmddhh24miss')<tmpDate;
    end if;
  end loop;
  commit;
  --
  return true;
end synch_cars;


/

